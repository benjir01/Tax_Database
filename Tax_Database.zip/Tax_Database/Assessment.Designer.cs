﻿namespace Tax_Database
{
    partial class Assessment
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource1 = new Microsoft.Reporting.WinForms.ReportDataSource();
            this.Taxassesment_InfoBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.Tax_DatabaseDataSet = new Tax_Database.Tax_DatabaseDataSet();
            this.reportViewer1 = new Microsoft.Reporting.WinForms.ReportViewer();
            this.Taxassesment_InfoTableAdapter = new Tax_Database.Tax_DatabaseDataSetTableAdapters.Taxassesment_InfoTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.Taxassesment_InfoBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Tax_DatabaseDataSet)).BeginInit();
            this.SuspendLayout();
            // 
            // Taxassesment_InfoBindingSource
            // 
            this.Taxassesment_InfoBindingSource.DataMember = "Taxassesment_Info";
            this.Taxassesment_InfoBindingSource.DataSource = this.Tax_DatabaseDataSet;
            // 
            // Tax_DatabaseDataSet
            // 
            this.Tax_DatabaseDataSet.DataSetName = "Tax_DatabaseDataSet";
            this.Tax_DatabaseDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // reportViewer1
            // 
            reportDataSource1.Name = "DataSet1";
            reportDataSource1.Value = this.Taxassesment_InfoBindingSource;
            this.reportViewer1.LocalReport.DataSources.Add(reportDataSource1);
            this.reportViewer1.LocalReport.ReportEmbeddedResource = "Tax_Database.Report1.rdlc";
            this.reportViewer1.Location = new System.Drawing.Point(2, 12);
            this.reportViewer1.Name = "reportViewer1";
            this.reportViewer1.Size = new System.Drawing.Size(933, 575);
            this.reportViewer1.TabIndex = 0;
            // 
            // Taxassesment_InfoTableAdapter
            // 
            this.Taxassesment_InfoTableAdapter.ClearBeforeFill = true;
            // 
            // Assessment
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(939, 591);
            this.Controls.Add(this.reportViewer1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "Assessment";
            this.Text = "Assessment";
            this.Load += new System.EventHandler(this.Assessment_Load);
            ((System.ComponentModel.ISupportInitialize)(this.Taxassesment_InfoBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Tax_DatabaseDataSet)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Microsoft.Reporting.WinForms.ReportViewer reportViewer1;
        private System.Windows.Forms.BindingSource Taxassesment_InfoBindingSource;
        private Tax_DatabaseDataSet Tax_DatabaseDataSet;
        private Tax_DatabaseDataSetTableAdapters.Taxassesment_InfoTableAdapter Taxassesment_InfoTableAdapter;
    }
}