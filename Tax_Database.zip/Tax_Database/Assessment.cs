﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tax_Database
{
    public partial class Assessment : Form
    {
        public Assessment()
        {
            InitializeComponent();
        }

        private void Assessment_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'Tax_DatabaseDataSet.Taxassesment_Info' table. You can move, or remove it, as needed.
            this.Taxassesment_InfoTableAdapter.Fill(this.Tax_DatabaseDataSet.Taxassesment_Info);

            this.reportViewer1.RefreshReport();
        }
    }
}
