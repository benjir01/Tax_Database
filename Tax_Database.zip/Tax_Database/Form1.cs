﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace Tax_Database
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection(@"Data Source=.\SQLEXPRESS;Initial Catalog=Tax_Database;Integrated Security=True");
                SqlCommand cmd = new SqlCommand("select * From Log_Info Where UserName =@User and Password=@password ", con);
                con.Open();
                cmd.Parameters.AddWithValue("@User", textBox1.Text);
                cmd.Parameters.AddWithValue("@password", textBox2.Text);
                SqlDataReader dt = cmd.ExecuteReader();
                DataTable ds = new DataTable();
                SqlDataAdapter dw = new SqlDataAdapter(cmd);
                if (dt.HasRows == true)
                {

                    Landpage lanpage = new Landpage();
                    lanpage.Show();
                }
                else
                {
                    MessageBox.Show("Sorry Your UserName or Password Incorrect");
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
 
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                Application.Exit();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }
            finally
            {

            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                textBox1.Text = "";
                textBox2.Text = "";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
 
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Form2 from2 = new Form2();
            from2.Show();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Form12 from12 = new Form12();
            from12.Show();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            progressBar1.Value = Convert.ToInt32(progressBar1.Value) + 10;

            if (Convert.ToInt32(progressBar1.Value) > 90)
            {
                timer1.Enabled = false;
                Landpage form2 = new Landpage();
                form2.Show();
            }
            else
            {
                MessageBox.Show("Sorry Incorrect Your UserName or Password");
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
