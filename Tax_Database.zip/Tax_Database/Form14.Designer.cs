﻿namespace Tax_Database
{
    partial class Form14
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource2 = new Microsoft.Reporting.WinForms.ReportDataSource();
            this.reportViewer1 = new Microsoft.Reporting.WinForms.ReportViewer();
            this.fillByToolStrip = new System.Windows.Forms.ToolStrip();
            this.liecenceNoToolStripLabel = new System.Windows.Forms.ToolStripLabel();
            this.liecenceNoToolStripTextBox = new System.Windows.Forms.ToolStripTextBox();
            this.financialyearToolStripLabel = new System.Windows.Forms.ToolStripLabel();
            this.financialyearToolStripTextBox = new System.Windows.Forms.ToolStripTextBox();
            this.tradeNameToolStripLabel = new System.Windows.Forms.ToolStripLabel();
            this.tradeNameToolStripTextBox = new System.Windows.Forms.ToolStripTextBox();
            this.fillByToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.TradeLien_InfoBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.Tax_DatabaseDataSet11 = new Tax_Database.Tax_DatabaseDataSet11();
            this.TradeLien_InfoTableAdapter = new Tax_Database.Tax_DatabaseDataSet11TableAdapters.TradeLien_InfoTableAdapter();
            this.fillByToolStrip.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.TradeLien_InfoBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Tax_DatabaseDataSet11)).BeginInit();
            this.SuspendLayout();
            // 
            // reportViewer1
            // 
            reportDataSource2.Name = "DataSet1";
            reportDataSource2.Value = this.TradeLien_InfoBindingSource;
            this.reportViewer1.LocalReport.DataSources.Add(reportDataSource2);
            this.reportViewer1.LocalReport.ReportEmbeddedResource = "Tax_Database.Report15.rdlc";
            this.reportViewer1.Location = new System.Drawing.Point(12, 52);
            this.reportViewer1.Name = "reportViewer1";
            this.reportViewer1.Size = new System.Drawing.Size(610, 646);
            this.reportViewer1.TabIndex = 0;
            // 
            // fillByToolStrip
            // 
            this.fillByToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.liecenceNoToolStripLabel,
            this.liecenceNoToolStripTextBox,
            this.financialyearToolStripLabel,
            this.financialyearToolStripTextBox,
            this.tradeNameToolStripLabel,
            this.tradeNameToolStripTextBox,
            this.fillByToolStripButton});
            this.fillByToolStrip.Location = new System.Drawing.Point(0, 0);
            this.fillByToolStrip.Name = "fillByToolStrip";
            this.fillByToolStrip.Size = new System.Drawing.Size(642, 28);
            this.fillByToolStrip.TabIndex = 1;
            this.fillByToolStrip.Text = "fillByToolStrip";
            // 
            // liecenceNoToolStripLabel
            // 
            this.liecenceNoToolStripLabel.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.liecenceNoToolStripLabel.Name = "liecenceNoToolStripLabel";
            this.liecenceNoToolStripLabel.Size = new System.Drawing.Size(69, 25);
            this.liecenceNoToolStripLabel.Text = "লাইসেন্স নং";
            // 
            // liecenceNoToolStripTextBox
            // 
            this.liecenceNoToolStripTextBox.Name = "liecenceNoToolStripTextBox";
            this.liecenceNoToolStripTextBox.Size = new System.Drawing.Size(60, 25);
            // 
            // financialyearToolStripLabel
            // 
            this.financialyearToolStripLabel.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.financialyearToolStripLabel.Name = "financialyearToolStripLabel";
            this.financialyearToolStripLabel.Size = new System.Drawing.Size(52, 25);
            this.financialyearToolStripLabel.Text = "অর্থবছর";
            // 
            // financialyearToolStripTextBox
            // 
            this.financialyearToolStripTextBox.Name = "financialyearToolStripTextBox";
            this.financialyearToolStripTextBox.Size = new System.Drawing.Size(80, 25);
            // 
            // tradeNameToolStripLabel
            // 
            this.tradeNameToolStripLabel.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tradeNameToolStripLabel.Name = "tradeNameToolStripLabel";
            this.tradeNameToolStripLabel.Size = new System.Drawing.Size(87, 25);
            this.tradeNameToolStripLabel.Text = "প্রতিষ্ঠানের নাম";
            // 
            // tradeNameToolStripTextBox
            // 
            this.tradeNameToolStripTextBox.Name = "tradeNameToolStripTextBox";
            this.tradeNameToolStripTextBox.Size = new System.Drawing.Size(170, 25);
            // 
            // fillByToolStripButton
            // 
            this.fillByToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.fillByToolStripButton.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fillByToolStripButton.Name = "fillByToolStripButton";
            this.fillByToolStripButton.Size = new System.Drawing.Size(64, 25);
            this.fillByToolStripButton.Text = "Submit";
            this.fillByToolStripButton.Click += new System.EventHandler(this.fillByToolStripButton_Click);
            // 
            // TradeLien_InfoBindingSource
            // 
            this.TradeLien_InfoBindingSource.DataMember = "TradeLien_Info";
            this.TradeLien_InfoBindingSource.DataSource = this.Tax_DatabaseDataSet11;
            // 
            // Tax_DatabaseDataSet11
            // 
            this.Tax_DatabaseDataSet11.DataSetName = "Tax_DatabaseDataSet11";
            this.Tax_DatabaseDataSet11.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // TradeLien_InfoTableAdapter
            // 
            this.TradeLien_InfoTableAdapter.ClearBeforeFill = true;
            // 
            // Form14
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(642, 718);
            this.Controls.Add(this.fillByToolStrip);
            this.Controls.Add(this.reportViewer1);
            this.Name = "Form14";
            this.Text = "Form14";
            this.Load += new System.EventHandler(this.Form14_Load);
            this.fillByToolStrip.ResumeLayout(false);
            this.fillByToolStrip.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.TradeLien_InfoBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Tax_DatabaseDataSet11)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Microsoft.Reporting.WinForms.ReportViewer reportViewer1;
        private System.Windows.Forms.BindingSource TradeLien_InfoBindingSource;
        private Tax_DatabaseDataSet11 Tax_DatabaseDataSet11;
        private Tax_DatabaseDataSet11TableAdapters.TradeLien_InfoTableAdapter TradeLien_InfoTableAdapter;
        private System.Windows.Forms.ToolStrip fillByToolStrip;
        private System.Windows.Forms.ToolStripLabel liecenceNoToolStripLabel;
        private System.Windows.Forms.ToolStripTextBox liecenceNoToolStripTextBox;
        private System.Windows.Forms.ToolStripLabel financialyearToolStripLabel;
        private System.Windows.Forms.ToolStripTextBox financialyearToolStripTextBox;
        private System.Windows.Forms.ToolStripLabel tradeNameToolStripLabel;
        private System.Windows.Forms.ToolStripTextBox tradeNameToolStripTextBox;
        private System.Windows.Forms.ToolStripButton fillByToolStripButton;
    }
}