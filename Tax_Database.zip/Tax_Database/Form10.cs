﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tax_Database
{
    public partial class Form10 : Form
    {
        public Form10()
        {
            InitializeComponent();
        }

        private void Form10_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'Tax_DatabaseDataSet7.TaxRegisterNonholding' table. You can move, or remove it, as needed.
            //this.TaxRegisterNonholdingTableAdapter.Fill(this.Tax_DatabaseDataSet7.TaxRegisterNonholding);

            //this.reportViewer1.RefreshReport();
        }

        private void fillByToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.TaxRegisterNonholdingTableAdapter.FillBy(this.Tax_DatabaseDataSet7.TaxRegisterNonholding, new System.Nullable<int>(((int)(System.Convert.ChangeType(liecenceNoToolStripTextBox.Text, typeof(int))))), financyearToolStripTextBox.Text);
                this.reportViewer1.RefreshReport();
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }
    }
}
