﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace Tax_Database
{
    public partial class Form12 : Form
    {
        public Form12()
        {
            InitializeComponent();
        }
        SqlConnection mcon = new SqlConnection(@"Data Source=.\SQLEXPRESS;Initial Catalog=Tax_Database;Integrated Security=True");
        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                SqlDataAdapter ASC = new SqlDataAdapter("Select COUNT(*) FROM Log_Info Where UserName= '" + textBox1.Text + "' AND Password = '" + textBox2.Text + "'", mcon);

                DataTable ds = new DataTable();

                ASC.Fill(ds);

                errorProvider1.Clear();
                if (ds.Rows[0][0].ToString() == "1")
                {
                    if (textBox3.Text == textBox4.Text)
                    {
                        SqlDataAdapter bb = new SqlDataAdapter("Update Log_Info  set  Password= '" + textBox3.Text + "'  Where UserName= '" + textBox1.Text + "' AND Password= '" + textBox2.Text + "'", mcon);
                        DataTable fs = new DataTable();

                        bb.Fill(fs);
                        MessageBox.Show("Your  Password Change Successfully ", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        errorProvider1.SetError(textBox3, "Unmatch Password");
                        errorProvider1.SetError(textBox4, "Unmatch Password");
                    }


                }
                else
                {
                    errorProvider1.SetError(textBox1, "Incorrect UserName");
                    errorProvider1.SetError(textBox2, "Incorrect Password");

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
 
            }
        }
    }
}
