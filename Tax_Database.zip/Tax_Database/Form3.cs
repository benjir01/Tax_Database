﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tax_Database
{
    public partial class Landpage : Form
    {
        public Landpage()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form7 from = new Form7();
            from.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form8 from8 = new Form8();
            from8.Show();

        }

        private void button4_Click(object sender, EventArgs e)
        {
            Form5 from5 = new Form5();
            from5.Show();
        }

        private void button11_Click(object sender, EventArgs e)
        {
            Registers registar = new Registers();
            registar.Show();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            Assessment assesment = new Assessment();
            assesment.Show();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            RegisterSearch register = new RegisterSearch();
            register.Show();
        }

        private void button12_Click(object sender, EventArgs e)
        {
            Assesmentsearch assesment = new Assesmentsearch();
            assesment.Show();
        }

        private void button13_Click(object sender, EventArgs e)
        {
            Form4 form4 = new Form4();
            form4.Show();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            label4.Text = (DateTime.Now.Hour + ":" + DateTime.Now.Minute + ":" + DateTime.Now.Second).ToString(); 
        }

        private void Landpage_Load(object sender, EventArgs e)
        {
            timer1.Start();
        }

        private void button14_Click(object sender, EventArgs e)
        {
            Form16 from16 = new Form16();
            from16.Show();
        }
    }
}
