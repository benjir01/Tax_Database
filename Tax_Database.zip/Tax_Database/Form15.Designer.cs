﻿namespace Tax_Database
{
    partial class Form15
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource1 = new Microsoft.Reporting.WinForms.ReportDataSource();
            this.TradeLien_InfoBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.Tax_DatabaseDataSet12 = new Tax_Database.Tax_DatabaseDataSet12();
            this.reportViewer1 = new Microsoft.Reporting.WinForms.ReportViewer();
            this.fillByToolStrip = new System.Windows.Forms.ToolStrip();
            this.liecenceNoToolStripLabel = new System.Windows.Forms.ToolStripLabel();
            this.liecenceNoToolStripTextBox = new System.Windows.Forms.ToolStripTextBox();
            this.financialyearToolStripLabel = new System.Windows.Forms.ToolStripLabel();
            this.financialyearToolStripTextBox = new System.Windows.Forms.ToolStripTextBox();
            this.tradeTypeToolStripLabel = new System.Windows.Forms.ToolStripLabel();
            this.tradeTypeToolStripTextBox = new System.Windows.Forms.ToolStripTextBox();
            this.fillByToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.TradeLien_InfoTableAdapter = new Tax_Database.Tax_DatabaseDataSet12TableAdapters.TradeLien_InfoTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.TradeLien_InfoBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Tax_DatabaseDataSet12)).BeginInit();
            this.fillByToolStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // TradeLien_InfoBindingSource
            // 
            this.TradeLien_InfoBindingSource.DataMember = "TradeLien_Info";
            this.TradeLien_InfoBindingSource.DataSource = this.Tax_DatabaseDataSet12;
            // 
            // Tax_DatabaseDataSet12
            // 
            this.Tax_DatabaseDataSet12.DataSetName = "Tax_DatabaseDataSet12";
            this.Tax_DatabaseDataSet12.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // reportViewer1
            // 
            reportDataSource1.Name = "DataSet1";
            reportDataSource1.Value = this.TradeLien_InfoBindingSource;
            this.reportViewer1.LocalReport.DataSources.Add(reportDataSource1);
            this.reportViewer1.LocalReport.ReportEmbeddedResource = "Tax_Database.Report16.rdlc";
            this.reportViewer1.Location = new System.Drawing.Point(3, 34);
            this.reportViewer1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.reportViewer1.Name = "reportViewer1";
            this.reportViewer1.Size = new System.Drawing.Size(779, 704);
            this.reportViewer1.TabIndex = 0;
            // 
            // fillByToolStrip
            // 
            this.fillByToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.liecenceNoToolStripLabel,
            this.liecenceNoToolStripTextBox,
            this.financialyearToolStripLabel,
            this.financialyearToolStripTextBox,
            this.tradeTypeToolStripLabel,
            this.tradeTypeToolStripTextBox,
            this.fillByToolStripButton});
            this.fillByToolStrip.Location = new System.Drawing.Point(0, 0);
            this.fillByToolStrip.Name = "fillByToolStrip";
            this.fillByToolStrip.Size = new System.Drawing.Size(809, 27);
            this.fillByToolStrip.TabIndex = 1;
            this.fillByToolStrip.Text = "fillByToolStrip";
            // 
            // liecenceNoToolStripLabel
            // 
            this.liecenceNoToolStripLabel.Name = "liecenceNoToolStripLabel";
            this.liecenceNoToolStripLabel.Size = new System.Drawing.Size(89, 24);
            this.liecenceNoToolStripLabel.Text = "LiecenceNo:";
            this.liecenceNoToolStripLabel.Click += new System.EventHandler(this.liecenceNoToolStripLabel_Click);
            // 
            // liecenceNoToolStripTextBox
            // 
            this.liecenceNoToolStripTextBox.Name = "liecenceNoToolStripTextBox";
            this.liecenceNoToolStripTextBox.Size = new System.Drawing.Size(132, 27);
            // 
            // financialyearToolStripLabel
            // 
            this.financialyearToolStripLabel.Name = "financialyearToolStripLabel";
            this.financialyearToolStripLabel.Size = new System.Drawing.Size(98, 24);
            this.financialyearToolStripLabel.Text = "Financialyear:";
            // 
            // financialyearToolStripTextBox
            // 
            this.financialyearToolStripTextBox.Name = "financialyearToolStripTextBox";
            this.financialyearToolStripTextBox.Size = new System.Drawing.Size(132, 27);
            // 
            // tradeTypeToolStripLabel
            // 
            this.tradeTypeToolStripLabel.Name = "tradeTypeToolStripLabel";
            this.tradeTypeToolStripLabel.Size = new System.Drawing.Size(82, 24);
            this.tradeTypeToolStripLabel.Text = "TradeType:";
            // 
            // tradeTypeToolStripTextBox
            // 
            this.tradeTypeToolStripTextBox.Name = "tradeTypeToolStripTextBox";
            this.tradeTypeToolStripTextBox.Size = new System.Drawing.Size(132, 27);
            // 
            // fillByToolStripButton
            // 
            this.fillByToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.fillByToolStripButton.Name = "fillByToolStripButton";
            this.fillByToolStripButton.Size = new System.Drawing.Size(48, 24);
            this.fillByToolStripButton.Text = "FillBy";
            this.fillByToolStripButton.Click += new System.EventHandler(this.fillByToolStripButton_Click);
            // 
            // TradeLien_InfoTableAdapter
            // 
            this.TradeLien_InfoTableAdapter.ClearBeforeFill = true;
            // 
            // Form15
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(809, 763);
            this.Controls.Add(this.fillByToolStrip);
            this.Controls.Add(this.reportViewer1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "Form15";
            this.Text = "Form15";
            this.Load += new System.EventHandler(this.Form15_Load);
            ((System.ComponentModel.ISupportInitialize)(this.TradeLien_InfoBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Tax_DatabaseDataSet12)).EndInit();
            this.fillByToolStrip.ResumeLayout(false);
            this.fillByToolStrip.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Microsoft.Reporting.WinForms.ReportViewer reportViewer1;
        private System.Windows.Forms.BindingSource TradeLien_InfoBindingSource;
        private Tax_DatabaseDataSet12 Tax_DatabaseDataSet12;
        private Tax_DatabaseDataSet12TableAdapters.TradeLien_InfoTableAdapter TradeLien_InfoTableAdapter;
        private System.Windows.Forms.ToolStrip fillByToolStrip;
        private System.Windows.Forms.ToolStripLabel liecenceNoToolStripLabel;
        private System.Windows.Forms.ToolStripTextBox liecenceNoToolStripTextBox;
        private System.Windows.Forms.ToolStripLabel financialyearToolStripLabel;
        private System.Windows.Forms.ToolStripTextBox financialyearToolStripTextBox;
        private System.Windows.Forms.ToolStripLabel tradeTypeToolStripLabel;
        private System.Windows.Forms.ToolStripTextBox tradeTypeToolStripTextBox;
        private System.Windows.Forms.ToolStripButton fillByToolStripButton;
    }
}