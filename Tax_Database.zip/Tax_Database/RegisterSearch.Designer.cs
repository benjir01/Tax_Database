﻿namespace Tax_Database
{
    partial class RegisterSearch
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource1 = new Microsoft.Reporting.WinForms.ReportDataSource();
            this.TaxRegister_InfoBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.Tax_DatabaseDataSet3 = new Tax_Database.Tax_DatabaseDataSet3();
            this.reportViewer1 = new Microsoft.Reporting.WinForms.ReportViewer();
            this.fillByToolStrip = new System.Windows.Forms.ToolStrip();
            this.holdingNoToolStripLabel = new System.Windows.Forms.ToolStripLabel();
            this.holdingNoToolStripTextBox = new System.Windows.Forms.ToolStripTextBox();
            this.fillByToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.TaxRegister_InfoTableAdapter = new Tax_Database.Tax_DatabaseDataSet3TableAdapters.TaxRegister_InfoTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.TaxRegister_InfoBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Tax_DatabaseDataSet3)).BeginInit();
            this.fillByToolStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // TaxRegister_InfoBindingSource
            // 
            this.TaxRegister_InfoBindingSource.DataMember = "TaxRegister_Info";
            this.TaxRegister_InfoBindingSource.DataSource = this.Tax_DatabaseDataSet3;
            // 
            // Tax_DatabaseDataSet3
            // 
            this.Tax_DatabaseDataSet3.DataSetName = "Tax_DatabaseDataSet3";
            this.Tax_DatabaseDataSet3.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // reportViewer1
            // 
            this.reportViewer1.DocumentMapWidth = 19;
            reportDataSource1.Name = "DataSet1";
            reportDataSource1.Value = this.TaxRegister_InfoBindingSource;
            this.reportViewer1.LocalReport.DataSources.Add(reportDataSource1);
            this.reportViewer1.LocalReport.ReportEmbeddedResource = "Tax_Database.Report4.rdlc";
            this.reportViewer1.Location = new System.Drawing.Point(12, 46);
            this.reportViewer1.Name = "reportViewer1";
            this.reportViewer1.Size = new System.Drawing.Size(999, 538);
            this.reportViewer1.TabIndex = 0;
            // 
            // fillByToolStrip
            // 
            this.fillByToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.holdingNoToolStripLabel,
            this.holdingNoToolStripTextBox,
            this.fillByToolStripButton});
            this.fillByToolStrip.Location = new System.Drawing.Point(0, 0);
            this.fillByToolStrip.Name = "fillByToolStrip";
            this.fillByToolStrip.Size = new System.Drawing.Size(1031, 28);
            this.fillByToolStrip.TabIndex = 1;
            this.fillByToolStrip.Text = "fillByToolStrip";
            // 
            // holdingNoToolStripLabel
            // 
            this.holdingNoToolStripLabel.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.holdingNoToolStripLabel.Name = "holdingNoToolStripLabel";
            this.holdingNoToolStripLabel.Size = new System.Drawing.Size(63, 25);
            this.holdingNoToolStripLabel.Text = "হোল্ডিং নং";
            // 
            // holdingNoToolStripTextBox
            // 
            this.holdingNoToolStripTextBox.Font = new System.Drawing.Font("SutonnyMJ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.holdingNoToolStripTextBox.Name = "holdingNoToolStripTextBox";
            this.holdingNoToolStripTextBox.Size = new System.Drawing.Size(100, 28);
            // 
            // fillByToolStripButton
            // 
            this.fillByToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.fillByToolStripButton.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fillByToolStripButton.Name = "fillByToolStripButton";
            this.fillByToolStripButton.Size = new System.Drawing.Size(64, 25);
            this.fillByToolStripButton.Text = "Submit";
            this.fillByToolStripButton.Click += new System.EventHandler(this.fillByToolStripButton_Click);
            // 
            // TaxRegister_InfoTableAdapter
            // 
            this.TaxRegister_InfoTableAdapter.ClearBeforeFill = true;
            // 
            // RegisterSearch
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1031, 604);
            this.Controls.Add(this.fillByToolStrip);
            this.Controls.Add(this.reportViewer1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "RegisterSearch";
            this.Text = "RegisterSearch";
            this.Load += new System.EventHandler(this.RegisterSearch_Load);
            ((System.ComponentModel.ISupportInitialize)(this.TaxRegister_InfoBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Tax_DatabaseDataSet3)).EndInit();
            this.fillByToolStrip.ResumeLayout(false);
            this.fillByToolStrip.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Microsoft.Reporting.WinForms.ReportViewer reportViewer1;
        private System.Windows.Forms.BindingSource TaxRegister_InfoBindingSource;
        private Tax_DatabaseDataSet3 Tax_DatabaseDataSet3;
        private Tax_DatabaseDataSet3TableAdapters.TaxRegister_InfoTableAdapter TaxRegister_InfoTableAdapter;
        private System.Windows.Forms.ToolStrip fillByToolStrip;
        private System.Windows.Forms.ToolStripLabel holdingNoToolStripLabel;
        private System.Windows.Forms.ToolStripTextBox holdingNoToolStripTextBox;
        private System.Windows.Forms.ToolStripButton fillByToolStripButton;
    }
}