﻿namespace Tax_Database
{
    partial class Form9
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource1 = new Microsoft.Reporting.WinForms.ReportDataSource();
            this.reportViewer1 = new Microsoft.Reporting.WinForms.ReportViewer();
            this.fillByToolStrip = new System.Windows.Forms.ToolStrip();
            this.nameToolStripLabel = new System.Windows.Forms.ToolStripLabel();
            this.nameToolStripTextBox = new System.Windows.Forms.ToolStripTextBox();
            this.secttionToolStripLabel = new System.Windows.Forms.ToolStripLabel();
            this.secttionToolStripTextBox = new System.Windows.Forms.ToolStripTextBox();
            this.fillByToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.NoneHoldingAssesmentBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.Tax_DatabaseDataSet6 = new Tax_Database.Tax_DatabaseDataSet6();
            this.NoneHoldingAssesmentTableAdapter = new Tax_Database.Tax_DatabaseDataSet6TableAdapters.NoneHoldingAssesmentTableAdapter();
            this.fillByToolStrip.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.NoneHoldingAssesmentBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Tax_DatabaseDataSet6)).BeginInit();
            this.SuspendLayout();
            // 
            // reportViewer1
            // 
            reportDataSource1.Name = "DataSet1";
            reportDataSource1.Value = this.NoneHoldingAssesmentBindingSource;
            this.reportViewer1.LocalReport.DataSources.Add(reportDataSource1);
            this.reportViewer1.LocalReport.ReportEmbeddedResource = "Tax_Database.Report9.rdlc";
            this.reportViewer1.Location = new System.Drawing.Point(3, 53);
            this.reportViewer1.Name = "reportViewer1";
            this.reportViewer1.Size = new System.Drawing.Size(1051, 522);
            this.reportViewer1.TabIndex = 0;
            // 
            // fillByToolStrip
            // 
            this.fillByToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.nameToolStripLabel,
            this.nameToolStripTextBox,
            this.secttionToolStripLabel,
            this.secttionToolStripTextBox,
            this.fillByToolStripButton});
            this.fillByToolStrip.Location = new System.Drawing.Point(0, 0);
            this.fillByToolStrip.Name = "fillByToolStrip";
            this.fillByToolStrip.Size = new System.Drawing.Size(1074, 25);
            this.fillByToolStrip.TabIndex = 1;
            this.fillByToolStrip.Text = "fillByToolStrip";
            // 
            // nameToolStripLabel
            // 
            this.nameToolStripLabel.Name = "nameToolStripLabel";
            this.nameToolStripLabel.Size = new System.Drawing.Size(42, 22);
            this.nameToolStripLabel.Text = "Name:";
            // 
            // nameToolStripTextBox
            // 
            this.nameToolStripTextBox.Name = "nameToolStripTextBox";
            this.nameToolStripTextBox.Size = new System.Drawing.Size(100, 25);
            // 
            // secttionToolStripLabel
            // 
            this.secttionToolStripLabel.Name = "secttionToolStripLabel";
            this.secttionToolStripLabel.Size = new System.Drawing.Size(53, 22);
            this.secttionToolStripLabel.Text = "Secttion:";
            // 
            // secttionToolStripTextBox
            // 
            this.secttionToolStripTextBox.Name = "secttionToolStripTextBox";
            this.secttionToolStripTextBox.Size = new System.Drawing.Size(100, 25);
            // 
            // fillByToolStripButton
            // 
            this.fillByToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.fillByToolStripButton.Name = "fillByToolStripButton";
            this.fillByToolStripButton.Size = new System.Drawing.Size(39, 22);
            this.fillByToolStripButton.Text = "FillBy";
            this.fillByToolStripButton.Click += new System.EventHandler(this.fillByToolStripButton_Click);
            // 
            // NoneHoldingAssesmentBindingSource
            // 
            this.NoneHoldingAssesmentBindingSource.DataMember = "NoneHoldingAssesment";
            this.NoneHoldingAssesmentBindingSource.DataSource = this.Tax_DatabaseDataSet6;
            // 
            // Tax_DatabaseDataSet6
            // 
            this.Tax_DatabaseDataSet6.DataSetName = "Tax_DatabaseDataSet6";
            this.Tax_DatabaseDataSet6.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // NoneHoldingAssesmentTableAdapter
            // 
            this.NoneHoldingAssesmentTableAdapter.ClearBeforeFill = true;
            // 
            // Form9
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1074, 595);
            this.Controls.Add(this.fillByToolStrip);
            this.Controls.Add(this.reportViewer1);
            this.Name = "Form9";
            this.Text = "Form9";
            this.Load += new System.EventHandler(this.Form9_Load);
            this.fillByToolStrip.ResumeLayout(false);
            this.fillByToolStrip.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.NoneHoldingAssesmentBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Tax_DatabaseDataSet6)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Microsoft.Reporting.WinForms.ReportViewer reportViewer1;
        private System.Windows.Forms.BindingSource NoneHoldingAssesmentBindingSource;
        private Tax_DatabaseDataSet6 Tax_DatabaseDataSet6;
        private Tax_DatabaseDataSet6TableAdapters.NoneHoldingAssesmentTableAdapter NoneHoldingAssesmentTableAdapter;
        private System.Windows.Forms.ToolStrip fillByToolStrip;
        private System.Windows.Forms.ToolStripLabel nameToolStripLabel;
        private System.Windows.Forms.ToolStripTextBox nameToolStripTextBox;
        private System.Windows.Forms.ToolStripLabel secttionToolStripLabel;
        private System.Windows.Forms.ToolStripTextBox secttionToolStripTextBox;
        private System.Windows.Forms.ToolStripButton fillByToolStripButton;
    }
}