﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tax_Database
{
    public partial class Registers : Form
    {
        public Registers()
        {
            InitializeComponent();
        }

        private void Register_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'Tax_DatabaseDataSet2.TaxRegister_Info' table. You can move, or remove it, as needed.
           // this.TaxRegister_InfoTableAdapter.Fill(this.Tax_DatabaseDataSet2.TaxRegister_Info);

           // this.reportViewer1.RefreshReport();
        }

        private void fillByToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.TaxRegister_InfoTableAdapter.FillBy(this.Tax_DatabaseDataSet2.TaxRegister_Info, new System.Nullable<int>(((int)(System.Convert.ChangeType(holdingNoToolStripTextBox.Text, typeof(int))))), financialyearToolStripTextBox.Text);
                this.reportViewer1.RefreshReport();
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }
    }
}
