﻿namespace Tax_Database
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.FirstNametxt = new System.Windows.Forms.TextBox();
            this.lastnametxt = new System.Windows.Forms.TextBox();
            this.usernametxt = new System.Windows.Forms.TextBox();
            this.passwordtxtr = new System.Windows.Forms.TextBox();
            this.mobiletxt = new System.Windows.Forms.TextBox();
            this.emailtxt = new System.Windows.Forms.TextBox();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.sqlConnection1 = new System.Data.SqlClient.SqlConnection();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(61, 116);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(118, 38);
            this.button1.TabIndex = 0;
            this.button1.Text = "FirstName";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(61, 178);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(118, 38);
            this.button2.TabIndex = 1;
            this.button2.Text = "LastName";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(61, 241);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(118, 38);
            this.button3.TabIndex = 2;
            this.button3.Text = "UserName";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(385, 116);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(118, 38);
            this.button4.TabIndex = 3;
            this.button4.Text = "Password";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(385, 171);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(118, 38);
            this.button5.TabIndex = 4;
            this.button5.Text = "Mobile Number";
            this.button5.UseVisualStyleBackColor = true;
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(385, 235);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(118, 38);
            this.button6.TabIndex = 5;
            this.button6.Text = "Email";
            this.button6.UseVisualStyleBackColor = true;
            // 
            // FirstNametxt
            // 
            this.FirstNametxt.Location = new System.Drawing.Point(206, 116);
            this.FirstNametxt.Multiline = true;
            this.FirstNametxt.Name = "FirstNametxt";
            this.FirstNametxt.Size = new System.Drawing.Size(159, 38);
            this.FirstNametxt.TabIndex = 6;
            this.FirstNametxt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.FirstNametxt_KeyDown);
            // 
            // lastnametxt
            // 
            this.lastnametxt.Location = new System.Drawing.Point(206, 178);
            this.lastnametxt.Multiline = true;
            this.lastnametxt.Name = "lastnametxt";
            this.lastnametxt.Size = new System.Drawing.Size(159, 38);
            this.lastnametxt.TabIndex = 7;
            this.lastnametxt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.lastnametxt_KeyDown);
            // 
            // usernametxt
            // 
            this.usernametxt.Location = new System.Drawing.Point(206, 241);
            this.usernametxt.Multiline = true;
            this.usernametxt.Name = "usernametxt";
            this.usernametxt.Size = new System.Drawing.Size(159, 38);
            this.usernametxt.TabIndex = 8;
            this.usernametxt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.usernametxt_KeyDown);
            // 
            // passwordtxtr
            // 
            this.passwordtxtr.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.passwordtxtr.Location = new System.Drawing.Point(530, 116);
            this.passwordtxtr.Multiline = true;
            this.passwordtxtr.Name = "passwordtxtr";
            this.passwordtxtr.PasswordChar = '*';
            this.passwordtxtr.Size = new System.Drawing.Size(159, 38);
            this.passwordtxtr.TabIndex = 9;
            this.passwordtxtr.KeyDown += new System.Windows.Forms.KeyEventHandler(this.passwordtxtr_KeyDown);
            // 
            // mobiletxt
            // 
            this.mobiletxt.Location = new System.Drawing.Point(530, 171);
            this.mobiletxt.Multiline = true;
            this.mobiletxt.Name = "mobiletxt";
            this.mobiletxt.Size = new System.Drawing.Size(159, 38);
            this.mobiletxt.TabIndex = 10;
            this.mobiletxt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.mobiletxt_KeyDown);
            // 
            // emailtxt
            // 
            this.emailtxt.Location = new System.Drawing.Point(530, 235);
            this.emailtxt.Multiline = true;
            this.emailtxt.Name = "emailtxt";
            this.emailtxt.Size = new System.Drawing.Size(159, 38);
            this.emailtxt.TabIndex = 11;
            this.emailtxt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.emailtxt_KeyDown);
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(206, 327);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(102, 40);
            this.button7.TabIndex = 12;
            this.button7.Text = "Submit";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(330, 327);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(102, 40);
            this.button8.TabIndex = 13;
            this.button8.Text = "Exit";
            this.button8.UseVisualStyleBackColor = true;
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(451, 327);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(102, 40);
            this.button9.TabIndex = 14;
            this.button9.Text = "Clear";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.DarkKhaki;
            this.panel1.Location = new System.Drawing.Point(37, 63);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(687, 321);
            this.panel1.TabIndex = 15;
            // 
            // sqlConnection1
            // 
            this.sqlConnection1.ConnectionString = "Data Source=.\\SQLEXPRESS;Initial Catalog=Tax_Database;Integrated Security=True";
            this.sqlConnection1.FireInfoMessageEventOnUserErrors = false;
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(773, 535);
            this.Controls.Add(this.button9);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.emailtxt);
            this.Controls.Add(this.mobiletxt);
            this.Controls.Add(this.passwordtxtr);
            this.Controls.Add(this.usernametxt);
            this.Controls.Add(this.lastnametxt);
            this.Controls.Add(this.FirstNametxt);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "Form2";
            this.Text = "ইউনিয়ন পরিষদ";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.TextBox FirstNametxt;
        private System.Windows.Forms.TextBox lastnametxt;
        private System.Windows.Forms.TextBox usernametxt;
        private System.Windows.Forms.TextBox passwordtxtr;
        private System.Windows.Forms.TextBox mobiletxt;
        private System.Windows.Forms.TextBox emailtxt;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Panel panel1;
        private System.Data.SqlClient.SqlConnection sqlConnection1;
    }
}