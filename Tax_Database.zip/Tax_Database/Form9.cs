﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tax_Database
{
    public partial class Form9 : Form
    {
        public Form9()
        {
            InitializeComponent();
        }

        private void Form9_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'Tax_DatabaseDataSet6.NoneHoldingAssesment' table. You can move, or remove it, as needed.
            this.NoneHoldingAssesmentTableAdapter.Fill(this.Tax_DatabaseDataSet6.NoneHoldingAssesment);

            this.reportViewer1.RefreshReport();
        }

        private void fillByToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.NoneHoldingAssesmentTableAdapter.FillBy(this.Tax_DatabaseDataSet6.NoneHoldingAssesment, nameToolStripTextBox.Text, secttionToolStripTextBox.Text);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }
    }
}
