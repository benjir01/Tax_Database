﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tax_Database
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void Form4_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'Tax_DatabaseDataSet4.TaxRegister_Info' table. You can move, or remove it, as needed.
            this.TaxRegister_InfoTableAdapter.Fill(this.Tax_DatabaseDataSet4.TaxRegister_Info);
            // TODO: This line of code loads data into the 'Tax_DatabaseDataSet.Taxassesment_Info' table. You can move, or remove it, as needed.
            this.Taxassesment_InfoTableAdapter.Fill(this.Tax_DatabaseDataSet.Taxassesment_Info);

            this.reportViewer1.RefreshReport();
            this.reportViewer2.RefreshReport();
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }
    }
}
