﻿namespace Tax_Database
{
    partial class Form7
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.button66 = new System.Windows.Forms.Button();
            this.textBox53 = new System.Windows.Forms.TextBox();
            this.button6 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.button59 = new System.Windows.Forms.Button();
            this.button58 = new System.Windows.Forms.Button();
            this.button57 = new System.Windows.Forms.Button();
            this.button56 = new System.Windows.Forms.Button();
            this.button55 = new System.Windows.Forms.Button();
            this.button54 = new System.Windows.Forms.Button();
            this.button53 = new System.Windows.Forms.Button();
            this.button33 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.yearlytax = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.yealyevualationtxt = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.TaxDorontxt = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtmobile = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtnid = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtvillage = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtfather = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.nametxt = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txthold = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.panel7 = new System.Windows.Forms.Panel();
            this.panel8 = new System.Windows.Forms.Panel();
            this.homestlyetxt = new System.Windows.Forms.ComboBox();
            this.wordnotxt = new System.Windows.Forms.ComboBox();
            this.button75 = new System.Windows.Forms.Button();
            this.button74 = new System.Windows.Forms.Button();
            this.button73 = new System.Windows.Forms.Button();
            this.button72 = new System.Windows.Forms.Button();
            this.button71 = new System.Windows.Forms.Button();
            this.button70 = new System.Windows.Forms.Button();
            this.button69 = new System.Windows.Forms.Button();
            this.button68 = new System.Windows.Forms.Button();
            this.button67 = new System.Windows.Forms.Button();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.button65 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            this.button16 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.taxyearlytxt = new System.Windows.Forms.TextBox();
            this.button52 = new System.Windows.Forms.Button();
            this.button51 = new System.Windows.Forms.Button();
            this.button50 = new System.Windows.Forms.Button();
            this.button49 = new System.Windows.Forms.Button();
            this.button48 = new System.Windows.Forms.Button();
            this.button47 = new System.Windows.Forms.Button();
            this.textBox16 = new System.Windows.Forms.TextBox();
            this.button20 = new System.Windows.Forms.Button();
            this.button21 = new System.Windows.Forms.Button();
            this.evulationyearly = new System.Windows.Forms.TextBox();
            this.textBox18 = new System.Windows.Forms.TextBox();
            this.textBox19 = new System.Windows.Forms.TextBox();
            this.sectiontax = new System.Windows.Forms.ComboBox();
            this.mobiletxt = new System.Windows.Forms.TextBox();
            this.nidtxt = new System.Windows.Forms.TextBox();
            this.villegetxt = new System.Windows.Forms.TextBox();
            this.fathertxt = new System.Windows.Forms.TextBox();
            this.taxholdertxt = new System.Windows.Forms.TextBox();
            this.holdingnametxt = new System.Windows.Forms.TextBox();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.homestyletxt = new System.Windows.Forms.ComboBox();
            this.weardtxtno = new System.Windows.Forms.ComboBox();
            this.button76 = new System.Windows.Forms.Button();
            this.button77 = new System.Windows.Forms.Button();
            this.button78 = new System.Windows.Forms.Button();
            this.button79 = new System.Windows.Forms.Button();
            this.button80 = new System.Windows.Forms.Button();
            this.button81 = new System.Windows.Forms.Button();
            this.button82 = new System.Windows.Forms.Button();
            this.button83 = new System.Windows.Forms.Button();
            this.button84 = new System.Windows.Forms.Button();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.button63 = new System.Windows.Forms.Button();
            this.button17 = new System.Windows.Forms.Button();
            this.button18 = new System.Windows.Forms.Button();
            this.button19 = new System.Windows.Forms.Button();
            this.button23 = new System.Windows.Forms.Button();
            this.taxyeartxt = new System.Windows.Forms.TextBox();
            this.textBox50 = new System.Windows.Forms.TextBox();
            this.button40 = new System.Windows.Forms.Button();
            this.button39 = new System.Windows.Forms.Button();
            this.button38 = new System.Windows.Forms.Button();
            this.button37 = new System.Windows.Forms.Button();
            this.button36 = new System.Windows.Forms.Button();
            this.button35 = new System.Windows.Forms.Button();
            this.button32 = new System.Windows.Forms.Button();
            this.button31 = new System.Windows.Forms.Button();
            this.yearevualationtaxtxt = new System.Windows.Forms.TextBox();
            this.textBox42 = new System.Windows.Forms.TextBox();
            this.button27 = new System.Windows.Forms.Button();
            this.textBox43 = new System.Windows.Forms.TextBox();
            this.button28 = new System.Windows.Forms.Button();
            this.textBox44 = new System.Windows.Forms.TextBox();
            this.button29 = new System.Windows.Forms.Button();
            this.button30 = new System.Windows.Forms.Button();
            this.textBox45 = new System.Windows.Forms.TextBox();
            this.textBox46 = new System.Windows.Forms.TextBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.button34 = new System.Windows.Forms.Button();
            this.panel4 = new System.Windows.Forms.Panel();
            this.Homestyle = new System.Windows.Forms.ComboBox();
            this.wordno = new System.Windows.Forms.ComboBox();
            this.button85 = new System.Windows.Forms.Button();
            this.button86 = new System.Windows.Forms.Button();
            this.button87 = new System.Windows.Forms.Button();
            this.button88 = new System.Windows.Forms.Button();
            this.button89 = new System.Windows.Forms.Button();
            this.button90 = new System.Windows.Forms.Button();
            this.button91 = new System.Windows.Forms.Button();
            this.button92 = new System.Windows.Forms.Button();
            this.button93 = new System.Windows.Forms.Button();
            this.holdingtax = new System.Windows.Forms.TextBox();
            this.mobilenotxt = new System.Windows.Forms.TextBox();
            this.nidntxt = new System.Windows.Forms.TextBox();
            this.txttvillege = new System.Windows.Forms.TextBox();
            this.fathertxth = new System.Windows.Forms.TextBox();
            this.txtname = new System.Windows.Forms.TextBox();
            this.taxsection = new System.Windows.Forms.ComboBox();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.button42 = new System.Windows.Forms.Button();
            this.button41 = new System.Windows.Forms.Button();
            this.button25 = new System.Windows.Forms.Button();
            this.textBox31 = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.button64 = new System.Windows.Forms.Button();
            this.button62 = new System.Windows.Forms.Button();
            this.button61 = new System.Windows.Forms.Button();
            this.button60 = new System.Windows.Forms.Button();
            this.button45 = new System.Windows.Forms.Button();
            this.button26 = new System.Windows.Forms.Button();
            this.yearltaxtxt = new System.Windows.Forms.TextBox();
            this.button8 = new System.Windows.Forms.Button();
            this.button44 = new System.Windows.Forms.Button();
            this.textBox32 = new System.Windows.Forms.TextBox();
            this.textBox48 = new System.Windows.Forms.TextBox();
            this.button12 = new System.Windows.Forms.Button();
            this.button22 = new System.Windows.Forms.Button();
            this.avulationtaxyear = new System.Windows.Forms.TextBox();
            this.button46 = new System.Windows.Forms.Button();
            this.button43 = new System.Windows.Forms.Button();
            this.textBox29 = new System.Windows.Forms.TextBox();
            this.button24 = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.wardnotxt = new System.Windows.Forms.ComboBox();
            this.txthomestyle = new System.Windows.Forms.ComboBox();
            this.villegehtxt = new System.Windows.Forms.TextBox();
            this.nidholdertxt = new System.Windows.Forms.TextBox();
            this.fathertxtholder = new System.Windows.Forms.TextBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.mobiletxtdolf = new System.Windows.Forms.TextBox();
            this.button94 = new System.Windows.Forms.Button();
            this.button95 = new System.Windows.Forms.Button();
            this.holdingtxtho = new System.Windows.Forms.TextBox();
            this.nameholdertax = new System.Windows.Forms.TextBox();
            this.button96 = new System.Windows.Forms.Button();
            this.button97 = new System.Windows.Forms.Button();
            this.button98 = new System.Windows.Forms.Button();
            this.button99 = new System.Windows.Forms.Button();
            this.button100 = new System.Windows.Forms.Button();
            this.button101 = new System.Windows.Forms.Button();
            this.button102 = new System.Windows.Forms.Button();
            this.txtdoronholder = new System.Windows.Forms.ComboBox();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.panel8.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.panel6.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControl1.Location = new System.Drawing.Point(2, 3);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1081, 662);
            this.tabControl1.TabIndex = 3;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.button66);
            this.tabPage1.Controls.Add(this.textBox53);
            this.tabPage1.Controls.Add(this.button6);
            this.tabPage1.Controls.Add(this.button9);
            this.tabPage1.Controls.Add(this.button10);
            this.tabPage1.Controls.Add(this.button11);
            this.tabPage1.Controls.Add(this.button59);
            this.tabPage1.Controls.Add(this.button58);
            this.tabPage1.Controls.Add(this.button57);
            this.tabPage1.Controls.Add(this.button56);
            this.tabPage1.Controls.Add(this.button55);
            this.tabPage1.Controls.Add(this.button54);
            this.tabPage1.Controls.Add(this.button53);
            this.tabPage1.Controls.Add(this.button33);
            this.tabPage1.Controls.Add(this.button3);
            this.tabPage1.Controls.Add(this.textBox8);
            this.tabPage1.Controls.Add(this.yearlytax);
            this.tabPage1.Controls.Add(this.button1);
            this.tabPage1.Controls.Add(this.textBox5);
            this.tabPage1.Controls.Add(this.button2);
            this.tabPage1.Controls.Add(this.button5);
            this.tabPage1.Controls.Add(this.textBox9);
            this.tabPage1.Controls.Add(this.textBox10);
            this.tabPage1.Controls.Add(this.yealyevualationtxt);
            this.tabPage1.Controls.Add(this.label10);
            this.tabPage1.Controls.Add(this.TaxDorontxt);
            this.tabPage1.Controls.Add(this.label7);
            this.tabPage1.Controls.Add(this.txtmobile);
            this.tabPage1.Controls.Add(this.label6);
            this.tabPage1.Controls.Add(this.txtnid);
            this.tabPage1.Controls.Add(this.label5);
            this.tabPage1.Controls.Add(this.label4);
            this.tabPage1.Controls.Add(this.txtvillage);
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Controls.Add(this.txtfather);
            this.tabPage1.Controls.Add(this.label8);
            this.tabPage1.Controls.Add(this.nametxt);
            this.tabPage1.Controls.Add(this.label9);
            this.tabPage1.Controls.Add(this.txthold);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.panel7);
            this.tabPage1.Controls.Add(this.panel8);
            this.tabPage1.Location = new System.Drawing.Point(4, 29);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1073, 629);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "ভাড়া বাসা সুদসহ";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // button66
            // 
            this.button66.Location = new System.Drawing.Point(796, 405);
            this.button66.Name = "button66";
            this.button66.Size = new System.Drawing.Size(96, 36);
            this.button66.TabIndex = 220;
            this.button66.Text = "Clear";
            this.button66.UseVisualStyleBackColor = true;
            // 
            // textBox53
            // 
            this.textBox53.Font = new System.Drawing.Font("SutonnyMJ", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox53.Location = new System.Drawing.Point(572, 192);
            this.textBox53.Multiline = true;
            this.textBox53.Name = "textBox53";
            this.textBox53.Size = new System.Drawing.Size(94, 31);
            this.textBox53.TabIndex = 210;
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(316, 405);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(96, 36);
            this.button6.TabIndex = 206;
            this.button6.Text = "Submit";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(433, 405);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(93, 36);
            this.button9.TabIndex = 207;
            this.button9.Text = "Update";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // button10
            // 
            this.button10.Location = new System.Drawing.Point(555, 405);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(95, 36);
            this.button10.TabIndex = 208;
            this.button10.Text = "Delete";
            this.button10.UseVisualStyleBackColor = true;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // button11
            // 
            this.button11.Location = new System.Drawing.Point(672, 405);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(100, 36);
            this.button11.TabIndex = 209;
            this.button11.Text = "Search";
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // button59
            // 
            this.button59.Location = new System.Drawing.Point(672, 192);
            this.button59.Name = "button59";
            this.button59.Size = new System.Drawing.Size(139, 31);
            this.button59.TabIndex = 202;
            this.button59.Text = "%";
            this.button59.UseVisualStyleBackColor = true;
            // 
            // button58
            // 
            this.button58.Location = new System.Drawing.Point(491, 192);
            this.button58.Name = "button58";
            this.button58.Size = new System.Drawing.Size(75, 31);
            this.button58.TabIndex = 201;
            this.button58.Text = "এর";
            this.button58.UseVisualStyleBackColor = true;
            // 
            // button57
            // 
            this.button57.Location = new System.Drawing.Point(325, 189);
            this.button57.Name = "button57";
            this.button57.Size = new System.Drawing.Size(60, 34);
            this.button57.TabIndex = 200;
            this.button57.Text = "=";
            this.button57.UseVisualStyleBackColor = true;
            // 
            // button56
            // 
            this.button56.Location = new System.Drawing.Point(325, 128);
            this.button56.Name = "button56";
            this.button56.Size = new System.Drawing.Size(102, 34);
            this.button56.TabIndex = 199;
            this.button56.Text = "=";
            this.button56.UseVisualStyleBackColor = true;
            // 
            // button55
            // 
            this.button55.Location = new System.Drawing.Point(325, 79);
            this.button55.Name = "button55";
            this.button55.Size = new System.Drawing.Size(102, 30);
            this.button55.TabIndex = 198;
            this.button55.Text = "=";
            this.button55.UseVisualStyleBackColor = true;
            // 
            // button54
            // 
            this.button54.Location = new System.Drawing.Point(583, 26);
            this.button54.Name = "button54";
            this.button54.Size = new System.Drawing.Size(83, 33);
            this.button54.TabIndex = 197;
            this.button54.Text = "X";
            this.button54.UseVisualStyleBackColor = true;
            // 
            // button53
            // 
            this.button53.Location = new System.Drawing.Point(325, 26);
            this.button53.Name = "button53";
            this.button53.Size = new System.Drawing.Size(98, 33);
            this.button53.TabIndex = 196;
            this.button53.Text = "মাসিক ভাড়া";
            this.button53.UseVisualStyleBackColor = true;
            // 
            // button33
            // 
            this.button33.Location = new System.Drawing.Point(325, 250);
            this.button33.Name = "button33";
            this.button33.Size = new System.Drawing.Size(87, 31);
            this.button33.TabIndex = 204;
            this.button33.Text = "=";
            this.button33.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Location = new System.Drawing.Point(571, 250);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(140, 31);
            this.button3.TabIndex = 195;
            this.button3.Text = "বার্ষিক ধার্য ট্যাক্স";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // textBox8
            // 
            this.textBox8.Font = new System.Drawing.Font("SutonnyMJ", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox8.Location = new System.Drawing.Point(742, 126);
            this.textBox8.Multiline = true;
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(69, 36);
            this.textBox8.TabIndex = 193;
            // 
            // yearlytax
            // 
            this.yearlytax.Font = new System.Drawing.Font("SutonnyMJ", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.yearlytax.Location = new System.Drawing.Point(418, 250);
            this.yearlytax.Multiline = true;
            this.yearlytax.Name = "yearlytax";
            this.yearlytax.Size = new System.Drawing.Size(148, 31);
            this.yearlytax.TabIndex = 203;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(590, 124);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(146, 38);
            this.button1.TabIndex = 192;
            this.button1.Text = " - বার্ষিক সুদ";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // textBox5
            // 
            this.textBox5.Font = new System.Drawing.Font("SutonnyMJ", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox5.Location = new System.Drawing.Point(433, 79);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(142, 30);
            this.textBox5.TabIndex = 191;
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(590, 75);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(221, 34);
            this.button2.TabIndex = 190;
            this.button2.Text = "রক্ষণাবেক্ষণের জন্য ২ মাস বাদ";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // button5
            // 
            this.button5.Font = new System.Drawing.Font("SutonnyMJ", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.Location = new System.Drawing.Point(679, 26);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(132, 32);
            this.button5.TabIndex = 189;
            this.button5.Text = "১২ মাসের ভাড়া";
            this.button5.UseVisualStyleBackColor = true;
            // 
            // textBox9
            // 
            this.textBox9.Font = new System.Drawing.Font("SutonnyMJ", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox9.Location = new System.Drawing.Point(433, 128);
            this.textBox9.Multiline = true;
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(142, 34);
            this.textBox9.TabIndex = 188;
            // 
            // textBox10
            // 
            this.textBox10.Font = new System.Drawing.Font("SutonnyMJ", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox10.Location = new System.Drawing.Point(433, 26);
            this.textBox10.Multiline = true;
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(142, 30);
            this.textBox10.TabIndex = 187;
            this.textBox10.TextChanged += new System.EventHandler(this.textBox10_TextChanged);
            // 
            // yealyevualationtxt
            // 
            this.yealyevualationtxt.Font = new System.Drawing.Font("SutonnyMJ", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.yealyevualationtxt.Location = new System.Drawing.Point(391, 192);
            this.yealyevualationtxt.Multiline = true;
            this.yealyevualationtxt.Name = "yealyevualationtxt";
            this.yealyevualationtxt.Size = new System.Drawing.Size(94, 31);
            this.yealyevualationtxt.TabIndex = 186;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(45, 416);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(0, 25);
            this.label10.TabIndex = 79;
            // 
            // TaxDorontxt
            // 
            this.TaxDorontxt.Font = new System.Drawing.Font("SutonnyMJ", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TaxDorontxt.FormattingEnabled = true;
            this.TaxDorontxt.Items.AddRange(new object[] {
            "fvov evmv my`mn",
            "fvov evmv my`wewnb",
            "gvwjK wb‡R _v‡K my` wewnb",
            "gvwjK emevm K‡i my` mn"});
            this.TaxDorontxt.Location = new System.Drawing.Point(96, 418);
            this.TaxDorontxt.Name = "TaxDorontxt";
            this.TaxDorontxt.Size = new System.Drawing.Size(185, 34);
            this.TaxDorontxt.TabIndex = 78;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(-8, 361);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(0, 24);
            this.label7.TabIndex = 77;
            // 
            // txtmobile
            // 
            this.txtmobile.Font = new System.Drawing.Font("SutonnyMJ", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtmobile.Location = new System.Drawing.Point(96, 318);
            this.txtmobile.Name = "txtmobile";
            this.txtmobile.Size = new System.Drawing.Size(185, 30);
            this.txtmobile.TabIndex = 75;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(-8, 313);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(0, 24);
            this.label6.TabIndex = 74;
            // 
            // txtnid
            // 
            this.txtnid.Font = new System.Drawing.Font("SutonnyMJ", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtnid.Location = new System.Drawing.Point(96, 268);
            this.txtnid.Name = "txtnid";
            this.txtnid.Size = new System.Drawing.Size(185, 30);
            this.txtnid.TabIndex = 73;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(2, 266);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(0, 20);
            this.label5.TabIndex = 62;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("SutonnyMJ", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(29, 211);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(0, 23);
            this.label4.TabIndex = 71;
            // 
            // txtvillage
            // 
            this.txtvillage.Font = new System.Drawing.Font("SutonnyMJ", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtvillage.Location = new System.Drawing.Point(98, 170);
            this.txtvillage.Name = "txtvillage";
            this.txtvillage.Size = new System.Drawing.Size(185, 30);
            this.txtvillage.TabIndex = 70;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("SutonnyMJ", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(60, 165);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(0, 23);
            this.label3.TabIndex = 69;
            // 
            // txtfather
            // 
            this.txtfather.Font = new System.Drawing.Font("SutonnyMJ", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtfather.Location = new System.Drawing.Point(99, 124);
            this.txtfather.Name = "txtfather";
            this.txtfather.Size = new System.Drawing.Size(186, 30);
            this.txtfather.TabIndex = 68;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("SutonnyMJ", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(8, 122);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(0, 23);
            this.label8.TabIndex = 67;
            // 
            // nametxt
            // 
            this.nametxt.Font = new System.Drawing.Font("SutonnyMJ", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nametxt.Location = new System.Drawing.Point(99, 79);
            this.nametxt.Name = "nametxt";
            this.nametxt.Size = new System.Drawing.Size(188, 30);
            this.nametxt.TabIndex = 66;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("SutonnyMJ", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(54, 74);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(0, 23);
            this.label9.TabIndex = 65;
            // 
            // txthold
            // 
            this.txthold.Font = new System.Drawing.Font("SutonnyMJ", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txthold.Location = new System.Drawing.Point(99, 29);
            this.txthold.Name = "txthold";
            this.txthold.Size = new System.Drawing.Size(188, 30);
            this.txthold.TabIndex = 64;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("SutonnyMJ", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(6, 32);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(0, 23);
            this.label2.TabIndex = 63;
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel7.Location = new System.Drawing.Point(308, 18);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(639, 487);
            this.panel7.TabIndex = 221;
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.Silver;
            this.panel8.Controls.Add(this.homestlyetxt);
            this.panel8.Controls.Add(this.wordnotxt);
            this.panel8.Controls.Add(this.button75);
            this.panel8.Controls.Add(this.button74);
            this.panel8.Controls.Add(this.button73);
            this.panel8.Controls.Add(this.button72);
            this.panel8.Controls.Add(this.button71);
            this.panel8.Controls.Add(this.button70);
            this.panel8.Controls.Add(this.button69);
            this.panel8.Controls.Add(this.button68);
            this.panel8.Controls.Add(this.button67);
            this.panel8.Location = new System.Drawing.Point(-8, 18);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(306, 487);
            this.panel8.TabIndex = 0;
            // 
            // homestlyetxt
            // 
            this.homestlyetxt.Font = new System.Drawing.Font("SutonnyMJ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.homestlyetxt.FormattingEnabled = true;
            this.homestlyetxt.Items.AddRange(new object[] {
            "KuvPv evwo",
            "L‡oi evwo",
            "`vjvb evwo",
            "d¬vU evwo"});
            this.homestlyetxt.Location = new System.Drawing.Point(104, 350);
            this.homestlyetxt.Name = "homestlyetxt";
            this.homestlyetxt.Size = new System.Drawing.Size(185, 28);
            this.homestlyetxt.TabIndex = 0;
            // 
            // wordnotxt
            // 
            this.wordnotxt.Font = new System.Drawing.Font("SutonnyMJ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.wordnotxt.FormattingEnabled = true;
            this.wordnotxt.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10"});
            this.wordnotxt.Location = new System.Drawing.Point(104, 200);
            this.wordnotxt.Name = "wordnotxt";
            this.wordnotxt.Size = new System.Drawing.Size(185, 28);
            this.wordnotxt.TabIndex = 0;
            // 
            // button75
            // 
            this.button75.Location = new System.Drawing.Point(15, 398);
            this.button75.Name = "button75";
            this.button75.Size = new System.Drawing.Size(85, 35);
            this.button75.TabIndex = 220;
            this.button75.Text = "ধরণ";
            this.button75.UseVisualStyleBackColor = true;
            // 
            // button74
            // 
            this.button74.Location = new System.Drawing.Point(15, 348);
            this.button74.Name = "button74";
            this.button74.Size = new System.Drawing.Size(85, 30);
            this.button74.TabIndex = 219;
            this.button74.Text = "বাড়ির ধরণ";
            this.button74.UseVisualStyleBackColor = true;
            // 
            // button73
            // 
            this.button73.Location = new System.Drawing.Point(14, 299);
            this.button73.Name = "button73";
            this.button73.Size = new System.Drawing.Size(84, 31);
            this.button73.TabIndex = 218;
            this.button73.Text = "মোবাইল নং";
            this.button73.UseVisualStyleBackColor = true;
            // 
            // button72
            // 
            this.button72.Location = new System.Drawing.Point(14, 248);
            this.button72.Name = "button72";
            this.button72.Size = new System.Drawing.Size(86, 32);
            this.button72.TabIndex = 212;
            this.button72.Text = "এনআইডি নং";
            this.button72.UseVisualStyleBackColor = true;
            // 
            // button71
            // 
            this.button71.Location = new System.Drawing.Point(14, 198);
            this.button71.Name = "button71";
            this.button71.Size = new System.Drawing.Size(90, 30);
            this.button71.TabIndex = 217;
            this.button71.Text = "ওয়ার্ড নং";
            this.button71.UseVisualStyleBackColor = true;
            // 
            // button70
            // 
            this.button70.Location = new System.Drawing.Point(14, 152);
            this.button70.Name = "button70";
            this.button70.Size = new System.Drawing.Size(90, 30);
            this.button70.TabIndex = 216;
            this.button70.Text = "গ্রাম";
            this.button70.UseVisualStyleBackColor = true;
            // 
            // button69
            // 
            this.button69.Location = new System.Drawing.Point(15, 104);
            this.button69.Name = "button69";
            this.button69.Size = new System.Drawing.Size(89, 32);
            this.button69.TabIndex = 215;
            this.button69.Text = "পিতা/মাতা";
            this.button69.UseVisualStyleBackColor = true;
            // 
            // button68
            // 
            this.button68.Location = new System.Drawing.Point(15, 61);
            this.button68.Name = "button68";
            this.button68.Size = new System.Drawing.Size(89, 30);
            this.button68.TabIndex = 214;
            this.button68.Text = "নাম";
            this.button68.UseVisualStyleBackColor = true;
            // 
            // button67
            // 
            this.button67.Location = new System.Drawing.Point(15, 11);
            this.button67.Name = "button67";
            this.button67.Size = new System.Drawing.Size(89, 30);
            this.button67.TabIndex = 213;
            this.button67.Text = "হোল্ডিং নং";
            this.button67.UseVisualStyleBackColor = true;
            this.button67.Click += new System.EventHandler(this.button67_Click);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.button65);
            this.tabPage2.Controls.Add(this.button13);
            this.tabPage2.Controls.Add(this.button14);
            this.tabPage2.Controls.Add(this.button15);
            this.tabPage2.Controls.Add(this.button16);
            this.tabPage2.Controls.Add(this.button7);
            this.tabPage2.Controls.Add(this.button4);
            this.tabPage2.Controls.Add(this.taxyearlytxt);
            this.tabPage2.Controls.Add(this.button52);
            this.tabPage2.Controls.Add(this.button51);
            this.tabPage2.Controls.Add(this.button50);
            this.tabPage2.Controls.Add(this.button49);
            this.tabPage2.Controls.Add(this.button48);
            this.tabPage2.Controls.Add(this.button47);
            this.tabPage2.Controls.Add(this.textBox16);
            this.tabPage2.Controls.Add(this.button20);
            this.tabPage2.Controls.Add(this.button21);
            this.tabPage2.Controls.Add(this.evulationyearly);
            this.tabPage2.Controls.Add(this.textBox18);
            this.tabPage2.Controls.Add(this.textBox19);
            this.tabPage2.Controls.Add(this.sectiontax);
            this.tabPage2.Controls.Add(this.mobiletxt);
            this.tabPage2.Controls.Add(this.nidtxt);
            this.tabPage2.Controls.Add(this.villegetxt);
            this.tabPage2.Controls.Add(this.fathertxt);
            this.tabPage2.Controls.Add(this.taxholdertxt);
            this.tabPage2.Controls.Add(this.holdingnametxt);
            this.tabPage2.Controls.Add(this.panel5);
            this.tabPage2.Controls.Add(this.panel6);
            this.tabPage2.Location = new System.Drawing.Point(4, 29);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1073, 629);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "ভাড়া বাসা সুদবিহিন";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // button65
            // 
            this.button65.Location = new System.Drawing.Point(829, 415);
            this.button65.Name = "button65";
            this.button65.Size = new System.Drawing.Size(85, 37);
            this.button65.TabIndex = 219;
            this.button65.Text = "Clear";
            this.button65.UseVisualStyleBackColor = true;
            // 
            // button13
            // 
            this.button13.Location = new System.Drawing.Point(422, 415);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(87, 37);
            this.button13.TabIndex = 210;
            this.button13.Text = "Submit";
            this.button13.UseVisualStyleBackColor = true;
            this.button13.Click += new System.EventHandler(this.button13_Click);
            // 
            // button14
            // 
            this.button14.Location = new System.Drawing.Point(512, 415);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(87, 37);
            this.button14.TabIndex = 211;
            this.button14.Text = "Update";
            this.button14.UseVisualStyleBackColor = true;
            this.button14.Click += new System.EventHandler(this.button14_Click);
            // 
            // button15
            // 
            this.button15.Location = new System.Drawing.Point(629, 415);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(87, 37);
            this.button15.TabIndex = 212;
            this.button15.Text = "Delete";
            this.button15.UseVisualStyleBackColor = true;
            this.button15.Click += new System.EventHandler(this.button15_Click);
            // 
            // button16
            // 
            this.button16.Location = new System.Drawing.Point(739, 415);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(87, 37);
            this.button16.TabIndex = 213;
            this.button16.Text = "Search";
            this.button16.UseVisualStyleBackColor = true;
            this.button16.Click += new System.EventHandler(this.button16_Click);
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(683, 208);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(224, 32);
            this.button7.TabIndex = 165;
            this.button7.Text = " বার্ষিক ধার্ষ ট্যাক্স ";
            this.button7.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(414, 208);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(95, 30);
            this.button4.TabIndex = 164;
            this.button4.Text = "=";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // taxyearlytxt
            // 
            this.taxyearlytxt.Font = new System.Drawing.Font("SutonnyMJ", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.taxyearlytxt.Location = new System.Drawing.Point(515, 210);
            this.taxyearlytxt.Name = "taxyearlytxt";
            this.taxyearlytxt.Size = new System.Drawing.Size(148, 30);
            this.taxyearlytxt.TabIndex = 163;
            // 
            // button52
            // 
            this.button52.Location = new System.Drawing.Point(796, 154);
            this.button52.Name = "button52";
            this.button52.Size = new System.Drawing.Size(111, 30);
            this.button52.TabIndex = 162;
            this.button52.Text = "%";
            this.button52.UseVisualStyleBackColor = true;
            // 
            // button51
            // 
            this.button51.Location = new System.Drawing.Point(577, 154);
            this.button51.Name = "button51";
            this.button51.Size = new System.Drawing.Size(99, 30);
            this.button51.TabIndex = 161;
            this.button51.Text = "এর";
            this.button51.UseVisualStyleBackColor = true;
            // 
            // button50
            // 
            this.button50.Location = new System.Drawing.Point(831, 102);
            this.button50.Name = "button50";
            this.button50.Size = new System.Drawing.Size(76, 33);
            this.button50.TabIndex = 160;
            this.button50.Text = "=";
            this.button50.UseVisualStyleBackColor = true;
            // 
            // button49
            // 
            this.button49.Location = new System.Drawing.Point(414, 102);
            this.button49.Name = "button49";
            this.button49.Size = new System.Drawing.Size(95, 30);
            this.button49.TabIndex = 159;
            this.button49.Text = "=";
            this.button49.UseVisualStyleBackColor = true;
            // 
            // button48
            // 
            this.button48.Location = new System.Drawing.Point(643, 49);
            this.button48.Name = "button48";
            this.button48.Size = new System.Drawing.Size(76, 31);
            this.button48.TabIndex = 158;
            this.button48.Text = "X";
            this.button48.UseVisualStyleBackColor = true;
            // 
            // button47
            // 
            this.button47.Location = new System.Drawing.Point(409, 50);
            this.button47.Name = "button47";
            this.button47.Size = new System.Drawing.Size(100, 30);
            this.button47.TabIndex = 157;
            this.button47.Text = "মাসিক ভাড়া";
            this.button47.UseVisualStyleBackColor = true;
            // 
            // textBox16
            // 
            this.textBox16.Font = new System.Drawing.Font("SutonnyMJ", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox16.Location = new System.Drawing.Point(515, 102);
            this.textBox16.Multiline = true;
            this.textBox16.Name = "textBox16";
            this.textBox16.Size = new System.Drawing.Size(109, 30);
            this.textBox16.TabIndex = 156;
            // 
            // button20
            // 
            this.button20.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button20.Location = new System.Drawing.Point(630, 102);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(195, 33);
            this.button20.TabIndex = 155;
            this.button20.Text = "রক্ষণাবেক্ষণের জন্য ২ মাস বাদ";
            this.button20.UseVisualStyleBackColor = true;
            // 
            // button21
            // 
            this.button21.Font = new System.Drawing.Font("SutonnyMJ", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button21.Location = new System.Drawing.Point(725, 49);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(182, 31);
            this.button21.TabIndex = 154;
            this.button21.Text = "১২ মাসের ভাড়া";
            this.button21.UseVisualStyleBackColor = true;
            // 
            // evulationyearly
            // 
            this.evulationyearly.Font = new System.Drawing.Font("SutonnyMJ", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.evulationyearly.Location = new System.Drawing.Point(414, 154);
            this.evulationyearly.Name = "evulationyearly";
            this.evulationyearly.Size = new System.Drawing.Size(148, 30);
            this.evulationyearly.TabIndex = 153;
            // 
            // textBox18
            // 
            this.textBox18.Font = new System.Drawing.Font("SutonnyMJ", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox18.Location = new System.Drawing.Point(515, 50);
            this.textBox18.Multiline = true;
            this.textBox18.Name = "textBox18";
            this.textBox18.Size = new System.Drawing.Size(109, 30);
            this.textBox18.TabIndex = 152;
            this.textBox18.TextChanged += new System.EventHandler(this.textBox18_TextChanged);
            // 
            // textBox19
            // 
            this.textBox19.Font = new System.Drawing.Font("SutonnyMJ", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox19.Location = new System.Drawing.Point(698, 154);
            this.textBox19.Name = "textBox19";
            this.textBox19.Size = new System.Drawing.Size(92, 30);
            this.textBox19.TabIndex = 151;
            // 
            // sectiontax
            // 
            this.sectiontax.Font = new System.Drawing.Font("SutonnyMJ", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sectiontax.FormattingEnabled = true;
            this.sectiontax.Items.AddRange(new object[] {
            "fvov evmv my`mn",
            "fvov evmv my`wewnb",
            "gvwjK wb‡R _v‡K my` wewnb",
            "gvwjK emevm K‡i my` mn"});
            this.sectiontax.Location = new System.Drawing.Point(141, 438);
            this.sectiontax.Name = "sectiontax";
            this.sectiontax.Size = new System.Drawing.Size(185, 34);
            this.sectiontax.TabIndex = 96;
            // 
            // mobiletxt
            // 
            this.mobiletxt.Font = new System.Drawing.Font("SutonnyMJ", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mobiletxt.Location = new System.Drawing.Point(141, 338);
            this.mobiletxt.Name = "mobiletxt";
            this.mobiletxt.Size = new System.Drawing.Size(185, 30);
            this.mobiletxt.TabIndex = 93;
            // 
            // nidtxt
            // 
            this.nidtxt.Font = new System.Drawing.Font("SutonnyMJ", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nidtxt.Location = new System.Drawing.Point(141, 288);
            this.nidtxt.Name = "nidtxt";
            this.nidtxt.Size = new System.Drawing.Size(185, 30);
            this.nidtxt.TabIndex = 91;
            // 
            // villegetxt
            // 
            this.villegetxt.Font = new System.Drawing.Font("SutonnyMJ", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.villegetxt.Location = new System.Drawing.Point(143, 190);
            this.villegetxt.Name = "villegetxt";
            this.villegetxt.Size = new System.Drawing.Size(185, 30);
            this.villegetxt.TabIndex = 88;
            // 
            // fathertxt
            // 
            this.fathertxt.Font = new System.Drawing.Font("SutonnyMJ", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fathertxt.Location = new System.Drawing.Point(144, 144);
            this.fathertxt.Name = "fathertxt";
            this.fathertxt.Size = new System.Drawing.Size(186, 30);
            this.fathertxt.TabIndex = 86;
            // 
            // taxholdertxt
            // 
            this.taxholdertxt.Font = new System.Drawing.Font("SutonnyMJ", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.taxholdertxt.Location = new System.Drawing.Point(144, 99);
            this.taxholdertxt.Name = "taxholdertxt";
            this.taxholdertxt.Size = new System.Drawing.Size(188, 30);
            this.taxholdertxt.TabIndex = 84;
            // 
            // holdingnametxt
            // 
            this.holdingnametxt.Font = new System.Drawing.Font("SutonnyMJ", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.holdingnametxt.Location = new System.Drawing.Point(144, 49);
            this.holdingnametxt.Name = "holdingnametxt";
            this.holdingnametxt.Size = new System.Drawing.Size(188, 30);
            this.holdingnametxt.TabIndex = 82;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.MediumAquamarine;
            this.panel5.Location = new System.Drawing.Point(367, 29);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(582, 479);
            this.panel5.TabIndex = 220;
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.Gainsboro;
            this.panel6.Controls.Add(this.homestyletxt);
            this.panel6.Controls.Add(this.weardtxtno);
            this.panel6.Controls.Add(this.button76);
            this.panel6.Controls.Add(this.button77);
            this.panel6.Controls.Add(this.button78);
            this.panel6.Controls.Add(this.button79);
            this.panel6.Controls.Add(this.button80);
            this.panel6.Controls.Add(this.button81);
            this.panel6.Controls.Add(this.button82);
            this.panel6.Controls.Add(this.button83);
            this.panel6.Controls.Add(this.button84);
            this.panel6.Location = new System.Drawing.Point(-9, 29);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(370, 479);
            this.panel6.TabIndex = 221;
            // 
            // homestyletxt
            // 
            this.homestyletxt.Font = new System.Drawing.Font("SutonnyMJ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.homestyletxt.FormattingEnabled = true;
            this.homestyletxt.Items.AddRange(new object[] {
            "KuvPv evwo",
            "L‡oi evwo",
            "`vjvb evwo",
            "d¬vU evwo"});
            this.homestyletxt.Location = new System.Drawing.Point(150, 358);
            this.homestyletxt.Name = "homestyletxt";
            this.homestyletxt.Size = new System.Drawing.Size(187, 28);
            this.homestyletxt.TabIndex = 231;
            // 
            // weardtxtno
            // 
            this.weardtxtno.Font = new System.Drawing.Font("SutonnyMJ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.weardtxtno.FormattingEnabled = true;
            this.weardtxtno.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10"});
            this.weardtxtno.Location = new System.Drawing.Point(153, 206);
            this.weardtxtno.Name = "weardtxtno";
            this.weardtxtno.Size = new System.Drawing.Size(182, 28);
            this.weardtxtno.TabIndex = 230;
            // 
            // button76
            // 
            this.button76.Location = new System.Drawing.Point(58, 406);
            this.button76.Name = "button76";
            this.button76.Size = new System.Drawing.Size(85, 35);
            this.button76.TabIndex = 229;
            this.button76.Text = "ধরণ";
            this.button76.UseVisualStyleBackColor = true;
            // 
            // button77
            // 
            this.button77.Location = new System.Drawing.Point(58, 356);
            this.button77.Name = "button77";
            this.button77.Size = new System.Drawing.Size(85, 30);
            this.button77.TabIndex = 228;
            this.button77.Text = "বাড়ির ধরণ";
            this.button77.UseVisualStyleBackColor = true;
            // 
            // button78
            // 
            this.button78.Location = new System.Drawing.Point(57, 307);
            this.button78.Name = "button78";
            this.button78.Size = new System.Drawing.Size(84, 31);
            this.button78.TabIndex = 227;
            this.button78.Text = "মোবাইল নং";
            this.button78.UseVisualStyleBackColor = true;
            // 
            // button79
            // 
            this.button79.Location = new System.Drawing.Point(57, 256);
            this.button79.Name = "button79";
            this.button79.Size = new System.Drawing.Size(86, 32);
            this.button79.TabIndex = 221;
            this.button79.Text = "এনআইডি নং";
            this.button79.UseVisualStyleBackColor = true;
            // 
            // button80
            // 
            this.button80.Location = new System.Drawing.Point(57, 206);
            this.button80.Name = "button80";
            this.button80.Size = new System.Drawing.Size(90, 30);
            this.button80.TabIndex = 226;
            this.button80.Text = "ওয়ার্ড নং";
            this.button80.UseVisualStyleBackColor = true;
            // 
            // button81
            // 
            this.button81.Location = new System.Drawing.Point(57, 160);
            this.button81.Name = "button81";
            this.button81.Size = new System.Drawing.Size(90, 30);
            this.button81.TabIndex = 225;
            this.button81.Text = "গ্রাম";
            this.button81.UseVisualStyleBackColor = true;
            // 
            // button82
            // 
            this.button82.Location = new System.Drawing.Point(58, 112);
            this.button82.Name = "button82";
            this.button82.Size = new System.Drawing.Size(89, 32);
            this.button82.TabIndex = 224;
            this.button82.Text = "পিতা/মাতা";
            this.button82.UseVisualStyleBackColor = true;
            // 
            // button83
            // 
            this.button83.Location = new System.Drawing.Point(58, 69);
            this.button83.Name = "button83";
            this.button83.Size = new System.Drawing.Size(89, 30);
            this.button83.TabIndex = 223;
            this.button83.Text = "নাম";
            this.button83.UseVisualStyleBackColor = true;
            // 
            // button84
            // 
            this.button84.Location = new System.Drawing.Point(58, 19);
            this.button84.Name = "button84";
            this.button84.Size = new System.Drawing.Size(89, 30);
            this.button84.TabIndex = 222;
            this.button84.Text = "হোল্ডিং নং";
            this.button84.UseVisualStyleBackColor = true;
            this.button84.Click += new System.EventHandler(this.button84_Click);
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.Color.Gray;
            this.tabPage3.Controls.Add(this.button63);
            this.tabPage3.Controls.Add(this.button17);
            this.tabPage3.Controls.Add(this.button18);
            this.tabPage3.Controls.Add(this.button19);
            this.tabPage3.Controls.Add(this.button23);
            this.tabPage3.Controls.Add(this.taxyeartxt);
            this.tabPage3.Controls.Add(this.textBox50);
            this.tabPage3.Controls.Add(this.button40);
            this.tabPage3.Controls.Add(this.button39);
            this.tabPage3.Controls.Add(this.button38);
            this.tabPage3.Controls.Add(this.button37);
            this.tabPage3.Controls.Add(this.button36);
            this.tabPage3.Controls.Add(this.button35);
            this.tabPage3.Controls.Add(this.button32);
            this.tabPage3.Controls.Add(this.button31);
            this.tabPage3.Controls.Add(this.yearevualationtaxtxt);
            this.tabPage3.Controls.Add(this.textBox42);
            this.tabPage3.Controls.Add(this.button27);
            this.tabPage3.Controls.Add(this.textBox43);
            this.tabPage3.Controls.Add(this.button28);
            this.tabPage3.Controls.Add(this.textBox44);
            this.tabPage3.Controls.Add(this.button29);
            this.tabPage3.Controls.Add(this.button30);
            this.tabPage3.Controls.Add(this.textBox45);
            this.tabPage3.Controls.Add(this.textBox46);
            this.tabPage3.Controls.Add(this.panel3);
            this.tabPage3.Controls.Add(this.panel4);
            this.tabPage3.Location = new System.Drawing.Point(4, 29);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(1073, 629);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "মালিক বসবাস করে সুদ সহ";
            // 
            // button63
            // 
            this.button63.Location = new System.Drawing.Point(736, 443);
            this.button63.Name = "button63";
            this.button63.Size = new System.Drawing.Size(82, 37);
            this.button63.TabIndex = 218;
            this.button63.Text = "Clear";
            this.button63.UseVisualStyleBackColor = true;
            // 
            // button17
            // 
            this.button17.Location = new System.Drawing.Point(372, 445);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(84, 37);
            this.button17.TabIndex = 214;
            this.button17.Text = "Submit";
            this.button17.UseVisualStyleBackColor = true;
            this.button17.Click += new System.EventHandler(this.button17_Click);
            // 
            // button18
            // 
            this.button18.Location = new System.Drawing.Point(462, 444);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(84, 38);
            this.button18.TabIndex = 215;
            this.button18.Text = "Update";
            this.button18.UseVisualStyleBackColor = true;
            this.button18.Click += new System.EventHandler(this.button18_Click);
            // 
            // button19
            // 
            this.button19.Location = new System.Drawing.Point(551, 444);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(84, 37);
            this.button19.TabIndex = 216;
            this.button19.Text = "Delete";
            this.button19.UseVisualStyleBackColor = true;
            this.button19.Click += new System.EventHandler(this.button19_Click);
            // 
            // button23
            // 
            this.button23.Location = new System.Drawing.Point(644, 445);
            this.button23.Name = "button23";
            this.button23.Size = new System.Drawing.Size(84, 37);
            this.button23.TabIndex = 217;
            this.button23.Text = "Search";
            this.button23.UseVisualStyleBackColor = true;
            this.button23.Click += new System.EventHandler(this.button23_Click);
            // 
            // taxyeartxt
            // 
            this.taxyeartxt.Font = new System.Drawing.Font("SutonnyMJ", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.taxyeartxt.Location = new System.Drawing.Point(683, 315);
            this.taxyeartxt.Multiline = true;
            this.taxyeartxt.Name = "taxyeartxt";
            this.taxyeartxt.Size = new System.Drawing.Size(123, 33);
            this.taxyeartxt.TabIndex = 213;
            // 
            // textBox50
            // 
            this.textBox50.Font = new System.Drawing.Font("SutonnyMJ", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox50.Location = new System.Drawing.Point(436, 264);
            this.textBox50.Multiline = true;
            this.textBox50.Name = "textBox50";
            this.textBox50.Size = new System.Drawing.Size(148, 33);
            this.textBox50.TabIndex = 212;
            // 
            // button40
            // 
            this.button40.Location = new System.Drawing.Point(513, 314);
            this.button40.Name = "button40";
            this.button40.Size = new System.Drawing.Size(164, 37);
            this.button40.TabIndex = 211;
            this.button40.Text = "বাৎসিক ধার্য ট্যাক্স";
            this.button40.UseVisualStyleBackColor = true;
            // 
            // button39
            // 
            this.button39.Location = new System.Drawing.Point(358, 264);
            this.button39.Name = "button39";
            this.button39.Size = new System.Drawing.Size(72, 37);
            this.button39.TabIndex = 210;
            this.button39.Text = "=";
            this.button39.UseVisualStyleBackColor = true;
            // 
            // button38
            // 
            this.button38.Location = new System.Drawing.Point(436, 319);
            this.button38.Name = "button38";
            this.button38.Size = new System.Drawing.Size(71, 32);
            this.button38.TabIndex = 209;
            this.button38.Text = "%";
            this.button38.UseVisualStyleBackColor = true;
            // 
            // button37
            // 
            this.button37.Location = new System.Drawing.Point(719, 262);
            this.button37.Name = "button37";
            this.button37.Size = new System.Drawing.Size(87, 35);
            this.button37.TabIndex = 208;
            this.button37.Text = "এর ";
            this.button37.UseVisualStyleBackColor = true;
            // 
            // button36
            // 
            this.button36.Location = new System.Drawing.Point(358, 109);
            this.button36.Name = "button36";
            this.button36.Size = new System.Drawing.Size(72, 30);
            this.button36.TabIndex = 207;
            this.button36.Text = "=";
            this.button36.UseVisualStyleBackColor = true;
            // 
            // button35
            // 
            this.button35.Location = new System.Drawing.Point(590, 52);
            this.button35.Name = "button35";
            this.button35.Size = new System.Drawing.Size(61, 32);
            this.button35.TabIndex = 206;
            this.button35.Text = "x";
            this.button35.UseVisualStyleBackColor = true;
            // 
            // button32
            // 
            this.button32.Location = new System.Drawing.Point(357, 208);
            this.button32.Name = "button32";
            this.button32.Size = new System.Drawing.Size(73, 33);
            this.button32.TabIndex = 204;
            this.button32.Text = "=";
            this.button32.UseVisualStyleBackColor = true;
            // 
            // button31
            // 
            this.button31.Location = new System.Drawing.Point(358, 158);
            this.button31.Name = "button31";
            this.button31.Size = new System.Drawing.Size(72, 30);
            this.button31.TabIndex = 203;
            this.button31.Text = "=";
            this.button31.UseVisualStyleBackColor = true;
            // 
            // yearevualationtaxtxt
            // 
            this.yearevualationtaxtxt.Font = new System.Drawing.Font("SutonnyMJ", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.yearevualationtaxtxt.Location = new System.Drawing.Point(596, 267);
            this.yearevualationtaxtxt.Name = "yearevualationtaxtxt";
            this.yearevualationtaxtxt.Size = new System.Drawing.Size(110, 30);
            this.yearevualationtaxtxt.TabIndex = 202;
            // 
            // textBox42
            // 
            this.textBox42.Font = new System.Drawing.Font("SutonnyMJ", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox42.Location = new System.Drawing.Point(358, 321);
            this.textBox42.Name = "textBox42";
            this.textBox42.Size = new System.Drawing.Size(72, 30);
            this.textBox42.TabIndex = 201;
            // 
            // button27
            // 
            this.button27.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button27.Location = new System.Drawing.Point(593, 209);
            this.button27.Name = "button27";
            this.button27.Size = new System.Drawing.Size(213, 30);
            this.button27.TabIndex = 200;
            this.button27.Text = "- বার্ষিক সুদ";
            this.button27.UseVisualStyleBackColor = true;
            // 
            // textBox43
            // 
            this.textBox43.Font = new System.Drawing.Font("SutonnyMJ", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox43.Location = new System.Drawing.Point(436, 208);
            this.textBox43.Multiline = true;
            this.textBox43.Name = "textBox43";
            this.textBox43.Size = new System.Drawing.Size(148, 33);
            this.textBox43.TabIndex = 199;
            // 
            // button28
            // 
            this.button28.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button28.Location = new System.Drawing.Point(593, 162);
            this.button28.Name = "button28";
            this.button28.Size = new System.Drawing.Size(213, 32);
            this.button28.TabIndex = 198;
            this.button28.Text = "১/৪ অংশ বাদ";
            this.button28.UseVisualStyleBackColor = true;
            // 
            // textBox44
            // 
            this.textBox44.Font = new System.Drawing.Font("SutonnyMJ", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox44.Location = new System.Drawing.Point(436, 109);
            this.textBox44.Name = "textBox44";
            this.textBox44.Size = new System.Drawing.Size(148, 30);
            this.textBox44.TabIndex = 197;
            // 
            // button29
            // 
            this.button29.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button29.Location = new System.Drawing.Point(590, 105);
            this.button29.Name = "button29";
            this.button29.Size = new System.Drawing.Size(216, 32);
            this.button29.TabIndex = 196;
            this.button29.Text = "রক্ষণাবেক্ষণের জন্য ২ মাস বাদ";
            this.button29.UseVisualStyleBackColor = true;
            // 
            // button30
            // 
            this.button30.Font = new System.Drawing.Font("SutonnyMJ", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button30.Location = new System.Drawing.Point(655, 52);
            this.button30.Name = "button30";
            this.button30.Size = new System.Drawing.Size(149, 32);
            this.button30.TabIndex = 195;
            this.button30.Text = "১২ মাসের ভাড়া";
            this.button30.UseVisualStyleBackColor = true;
            // 
            // textBox45
            // 
            this.textBox45.Font = new System.Drawing.Font("SutonnyMJ", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox45.Location = new System.Drawing.Point(436, 162);
            this.textBox45.Name = "textBox45";
            this.textBox45.Size = new System.Drawing.Size(148, 30);
            this.textBox45.TabIndex = 194;
            // 
            // textBox46
            // 
            this.textBox46.Font = new System.Drawing.Font("SutonnyMJ", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox46.Location = new System.Drawing.Point(436, 54);
            this.textBox46.Name = "textBox46";
            this.textBox46.Size = new System.Drawing.Size(148, 30);
            this.textBox46.TabIndex = 193;
            this.textBox46.TextChanged += new System.EventHandler(this.textBox46_TextChanged);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.panel3.Controls.Add(this.button34);
            this.panel3.Location = new System.Drawing.Point(338, 30);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(509, 474);
            this.panel3.TabIndex = 219;
            // 
            // button34
            // 
            this.button34.Location = new System.Drawing.Point(21, 24);
            this.button34.Name = "button34";
            this.button34.Size = new System.Drawing.Size(71, 32);
            this.button34.TabIndex = 205;
            this.button34.Text = "মাসিকভাড়া";
            this.button34.UseVisualStyleBackColor = true;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.Teal;
            this.panel4.Controls.Add(this.Homestyle);
            this.panel4.Controls.Add(this.wordno);
            this.panel4.Controls.Add(this.button85);
            this.panel4.Controls.Add(this.button86);
            this.panel4.Controls.Add(this.button87);
            this.panel4.Controls.Add(this.button88);
            this.panel4.Controls.Add(this.button89);
            this.panel4.Controls.Add(this.button90);
            this.panel4.Controls.Add(this.button91);
            this.panel4.Controls.Add(this.button92);
            this.panel4.Controls.Add(this.button93);
            this.panel4.Controls.Add(this.holdingtax);
            this.panel4.Controls.Add(this.mobilenotxt);
            this.panel4.Controls.Add(this.nidntxt);
            this.panel4.Controls.Add(this.txttvillege);
            this.panel4.Controls.Add(this.fathertxth);
            this.panel4.Controls.Add(this.txtname);
            this.panel4.Controls.Add(this.taxsection);
            this.panel4.Location = new System.Drawing.Point(3, 27);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(319, 474);
            this.panel4.TabIndex = 220;
            // 
            // Homestyle
            // 
            this.Homestyle.Font = new System.Drawing.Font("SutonnyMJ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Homestyle.FormattingEnabled = true;
            this.Homestyle.Items.AddRange(new object[] {
            "KuvPv evwo",
            "L‡oi evwo",
            "`vjvb evwo",
            "d¬vU evwo"});
            this.Homestyle.Location = new System.Drawing.Point(104, 365);
            this.Homestyle.Name = "Homestyle";
            this.Homestyle.Size = new System.Drawing.Size(182, 28);
            this.Homestyle.TabIndex = 231;
            // 
            // wordno
            // 
            this.wordno.Font = new System.Drawing.Font("SutonnyMJ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.wordno.FormattingEnabled = true;
            this.wordno.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10"});
            this.wordno.Location = new System.Drawing.Point(104, 242);
            this.wordno.Name = "wordno";
            this.wordno.Size = new System.Drawing.Size(182, 28);
            this.wordno.TabIndex = 230;
            // 
            // button85
            // 
            this.button85.Location = new System.Drawing.Point(17, 401);
            this.button85.Name = "button85";
            this.button85.Size = new System.Drawing.Size(85, 35);
            this.button85.TabIndex = 229;
            this.button85.Text = "ধরণ";
            this.button85.UseVisualStyleBackColor = true;
            // 
            // button86
            // 
            this.button86.Location = new System.Drawing.Point(18, 365);
            this.button86.Name = "button86";
            this.button86.Size = new System.Drawing.Size(85, 30);
            this.button86.TabIndex = 228;
            this.button86.Text = "বাড়ির ধরণ";
            this.button86.UseVisualStyleBackColor = true;
            // 
            // button87
            // 
            this.button87.Location = new System.Drawing.Point(19, 324);
            this.button87.Name = "button87";
            this.button87.Size = new System.Drawing.Size(84, 31);
            this.button87.TabIndex = 227;
            this.button87.Text = "মোবাইল নং";
            this.button87.UseVisualStyleBackColor = true;
            // 
            // button88
            // 
            this.button88.Location = new System.Drawing.Point(19, 284);
            this.button88.Name = "button88";
            this.button88.Size = new System.Drawing.Size(83, 32);
            this.button88.TabIndex = 221;
            this.button88.Text = "এনআইডি নং";
            this.button88.UseVisualStyleBackColor = true;
            // 
            // button89
            // 
            this.button89.Location = new System.Drawing.Point(17, 242);
            this.button89.Name = "button89";
            this.button89.Size = new System.Drawing.Size(86, 30);
            this.button89.TabIndex = 226;
            this.button89.Text = "ওয়ার্ড নং";
            this.button89.UseVisualStyleBackColor = true;
            // 
            // button90
            // 
            this.button90.Location = new System.Drawing.Point(17, 205);
            this.button90.Name = "button90";
            this.button90.Size = new System.Drawing.Size(84, 30);
            this.button90.TabIndex = 225;
            this.button90.Text = "গ্রাম";
            this.button90.UseVisualStyleBackColor = true;
            // 
            // button91
            // 
            this.button91.Location = new System.Drawing.Point(16, 167);
            this.button91.Name = "button91";
            this.button91.Size = new System.Drawing.Size(85, 32);
            this.button91.TabIndex = 224;
            this.button91.Text = "পিতা/মাতা";
            this.button91.UseVisualStyleBackColor = true;
            // 
            // button92
            // 
            this.button92.Location = new System.Drawing.Point(15, 131);
            this.button92.Name = "button92";
            this.button92.Size = new System.Drawing.Size(86, 30);
            this.button92.TabIndex = 223;
            this.button92.Text = "নাম";
            this.button92.UseVisualStyleBackColor = true;
            // 
            // button93
            // 
            this.button93.Location = new System.Drawing.Point(17, 95);
            this.button93.Name = "button93";
            this.button93.Size = new System.Drawing.Size(83, 30);
            this.button93.TabIndex = 222;
            this.button93.Text = "হোল্ডিং নং";
            this.button93.UseVisualStyleBackColor = true;
            this.button93.Click += new System.EventHandler(this.button93_Click);
            // 
            // holdingtax
            // 
            this.holdingtax.Font = new System.Drawing.Font("SutonnyMJ", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.holdingtax.Location = new System.Drawing.Point(104, 95);
            this.holdingtax.Name = "holdingtax";
            this.holdingtax.Size = new System.Drawing.Size(182, 30);
            this.holdingtax.TabIndex = 64;
            // 
            // mobilenotxt
            // 
            this.mobilenotxt.Font = new System.Drawing.Font("SutonnyMJ", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mobilenotxt.Location = new System.Drawing.Point(105, 325);
            this.mobilenotxt.Name = "mobilenotxt";
            this.mobilenotxt.Size = new System.Drawing.Size(181, 30);
            this.mobilenotxt.TabIndex = 75;
            // 
            // nidntxt
            // 
            this.nidntxt.Font = new System.Drawing.Font("SutonnyMJ", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nidntxt.Location = new System.Drawing.Point(104, 283);
            this.nidntxt.Name = "nidntxt";
            this.nidntxt.Size = new System.Drawing.Size(182, 30);
            this.nidntxt.TabIndex = 73;
            // 
            // txttvillege
            // 
            this.txttvillege.Font = new System.Drawing.Font("SutonnyMJ", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txttvillege.Location = new System.Drawing.Point(104, 203);
            this.txttvillege.Name = "txttvillege";
            this.txttvillege.Size = new System.Drawing.Size(182, 30);
            this.txttvillege.TabIndex = 70;
            // 
            // fathertxth
            // 
            this.fathertxth.Font = new System.Drawing.Font("SutonnyMJ", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fathertxth.Location = new System.Drawing.Point(103, 169);
            this.fathertxth.Name = "fathertxth";
            this.fathertxth.Size = new System.Drawing.Size(183, 30);
            this.fathertxth.TabIndex = 68;
            // 
            // txtname
            // 
            this.txtname.Font = new System.Drawing.Font("SutonnyMJ", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtname.Location = new System.Drawing.Point(103, 131);
            this.txtname.Name = "txtname";
            this.txtname.Size = new System.Drawing.Size(183, 30);
            this.txtname.TabIndex = 66;
            // 
            // taxsection
            // 
            this.taxsection.Font = new System.Drawing.Font("SutonnyMJ", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.taxsection.FormattingEnabled = true;
            this.taxsection.Items.AddRange(new object[] {
            "fvov evmv my`mn",
            "fvov evmv my`wewnb",
            "gvwjK wb‡R _v‡K my` wewnb",
            "gvwjK emevm K‡i my` mn"});
            this.taxsection.Location = new System.Drawing.Point(104, 402);
            this.taxsection.Name = "taxsection";
            this.taxsection.Size = new System.Drawing.Size(182, 34);
            this.taxsection.TabIndex = 78;
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.button42);
            this.tabPage4.Controls.Add(this.button41);
            this.tabPage4.Controls.Add(this.button25);
            this.tabPage4.Controls.Add(this.textBox31);
            this.tabPage4.Controls.Add(this.panel1);
            this.tabPage4.Controls.Add(this.panel2);
            this.tabPage4.Controls.Add(this.txtdoronholder);
            this.tabPage4.Location = new System.Drawing.Point(4, 29);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(1073, 629);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "মালিক নিজে থাকে সুদ বিহিন";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // button42
            // 
            this.button42.Location = new System.Drawing.Point(637, 65);
            this.button42.Name = "button42";
            this.button42.Size = new System.Drawing.Size(44, 34);
            this.button42.TabIndex = 169;
            this.button42.Text = "X";
            this.button42.UseVisualStyleBackColor = true;
            // 
            // button41
            // 
            this.button41.Location = new System.Drawing.Point(392, 65);
            this.button41.Name = "button41";
            this.button41.Size = new System.Drawing.Size(120, 35);
            this.button41.TabIndex = 168;
            this.button41.Text = "মাসিক ভাড়া";
            this.button41.UseVisualStyleBackColor = true;
            // 
            // button25
            // 
            this.button25.Font = new System.Drawing.Font("SutonnyMJ", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button25.Location = new System.Drawing.Point(687, 65);
            this.button25.Name = "button25";
            this.button25.Size = new System.Drawing.Size(222, 36);
            this.button25.TabIndex = 164;
            this.button25.Text = "১২ মাসের ভাড়া";
            this.button25.UseVisualStyleBackColor = true;
            // 
            // textBox31
            // 
            this.textBox31.Font = new System.Drawing.Font("SutonnyMJ", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox31.Location = new System.Drawing.Point(518, 65);
            this.textBox31.Multiline = true;
            this.textBox31.Name = "textBox31";
            this.textBox31.Size = new System.Drawing.Size(113, 32);
            this.textBox31.TabIndex = 162;
            this.textBox31.TextChanged += new System.EventHandler(this.textBox31_TextChanged);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.panel1.Controls.Add(this.button64);
            this.panel1.Controls.Add(this.button62);
            this.panel1.Controls.Add(this.button61);
            this.panel1.Controls.Add(this.button60);
            this.panel1.Controls.Add(this.button45);
            this.panel1.Controls.Add(this.button26);
            this.panel1.Controls.Add(this.yearltaxtxt);
            this.panel1.Controls.Add(this.button8);
            this.panel1.Controls.Add(this.button44);
            this.panel1.Controls.Add(this.textBox32);
            this.panel1.Controls.Add(this.textBox48);
            this.panel1.Controls.Add(this.button12);
            this.panel1.Controls.Add(this.button22);
            this.panel1.Controls.Add(this.avulationtaxyear);
            this.panel1.Controls.Add(this.button46);
            this.panel1.Controls.Add(this.button43);
            this.panel1.Controls.Add(this.textBox29);
            this.panel1.Controls.Add(this.button24);
            this.panel1.Location = new System.Drawing.Point(360, 45);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(914, 483);
            this.panel1.TabIndex = 220;
            // 
            // button64
            // 
            this.button64.Location = new System.Drawing.Point(462, 409);
            this.button64.Name = "button64";
            this.button64.Size = new System.Drawing.Size(87, 37);
            this.button64.TabIndex = 219;
            this.button64.Text = "Clear";
            this.button64.UseVisualStyleBackColor = true;
            // 
            // button62
            // 
            this.button62.Location = new System.Drawing.Point(32, 210);
            this.button62.Name = "button62";
            this.button62.Size = new System.Drawing.Size(37, 30);
            this.button62.TabIndex = 218;
            this.button62.Text = "=";
            this.button62.UseVisualStyleBackColor = true;
            // 
            // button61
            // 
            this.button61.Location = new System.Drawing.Point(343, 409);
            this.button61.Name = "button61";
            this.button61.Size = new System.Drawing.Size(102, 37);
            this.button61.TabIndex = 217;
            this.button61.Text = "Search";
            this.button61.UseVisualStyleBackColor = true;
            this.button61.Click += new System.EventHandler(this.button61_Click);
            // 
            // button60
            // 
            this.button60.Location = new System.Drawing.Point(235, 409);
            this.button60.Name = "button60";
            this.button60.Size = new System.Drawing.Size(102, 37);
            this.button60.TabIndex = 216;
            this.button60.Text = "Delete";
            this.button60.UseVisualStyleBackColor = true;
            this.button60.Click += new System.EventHandler(this.button60_Click);
            // 
            // button45
            // 
            this.button45.Location = new System.Drawing.Point(127, 409);
            this.button45.Name = "button45";
            this.button45.Size = new System.Drawing.Size(102, 37);
            this.button45.TabIndex = 215;
            this.button45.Text = "Update";
            this.button45.UseVisualStyleBackColor = true;
            this.button45.Click += new System.EventHandler(this.button45_Click);
            // 
            // button26
            // 
            this.button26.Location = new System.Drawing.Point(19, 409);
            this.button26.Name = "button26";
            this.button26.Size = new System.Drawing.Size(102, 37);
            this.button26.TabIndex = 214;
            this.button26.Text = "Submit";
            this.button26.UseVisualStyleBackColor = true;
            this.button26.Click += new System.EventHandler(this.button26_Click);
            // 
            // yearltaxtxt
            // 
            this.yearltaxtxt.Font = new System.Drawing.Font("SutonnyMJ", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.yearltaxtxt.Location = new System.Drawing.Point(75, 210);
            this.yearltaxtxt.Name = "yearltaxtxt";
            this.yearltaxtxt.Size = new System.Drawing.Size(138, 30);
            this.yearltaxtxt.TabIndex = 193;
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(219, 210);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(181, 33);
            this.button8.TabIndex = 194;
            this.button8.Text = "বার্ষিক ট্যাক্স";
            this.button8.UseVisualStyleBackColor = true;
            // 
            // button44
            // 
            this.button44.Location = new System.Drawing.Point(394, 79);
            this.button44.Name = "button44";
            this.button44.Size = new System.Drawing.Size(37, 31);
            this.button44.TabIndex = 171;
            this.button44.Text = "=";
            this.button44.UseVisualStyleBackColor = true;
            // 
            // textBox32
            // 
            this.textBox32.Font = new System.Drawing.Font("SutonnyMJ", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox32.Location = new System.Drawing.Point(437, 81);
            this.textBox32.Name = "textBox32";
            this.textBox32.Size = new System.Drawing.Size(112, 30);
            this.textBox32.TabIndex = 161;
            // 
            // textBox48
            // 
            this.textBox48.BackColor = System.Drawing.Color.White;
            this.textBox48.Font = new System.Drawing.Font("SutonnyMJ", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox48.ForeColor = System.Drawing.Color.Black;
            this.textBox48.Location = new System.Drawing.Point(394, 141);
            this.textBox48.Name = "textBox48";
            this.textBox48.Size = new System.Drawing.Size(76, 30);
            this.textBox48.TabIndex = 192;
            // 
            // button12
            // 
            this.button12.Location = new System.Drawing.Point(293, 141);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(99, 30);
            this.button12.TabIndex = 195;
            this.button12.Text = "এর";
            this.button12.UseVisualStyleBackColor = true;
            // 
            // button22
            // 
            this.button22.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button22.Location = new System.Drawing.Point(32, 141);
            this.button22.Name = "button22";
            this.button22.Size = new System.Drawing.Size(132, 30);
            this.button22.TabIndex = 167;
            this.button22.Text = "১/৪ বাদ";
            this.button22.UseVisualStyleBackColor = true;
            // 
            // avulationtaxyear
            // 
            this.avulationtaxyear.Font = new System.Drawing.Font("SutonnyMJ", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.avulationtaxyear.Location = new System.Drawing.Point(170, 141);
            this.avulationtaxyear.Name = "avulationtaxyear";
            this.avulationtaxyear.Size = new System.Drawing.Size(120, 30);
            this.avulationtaxyear.TabIndex = 191;
            // 
            // button46
            // 
            this.button46.Location = new System.Drawing.Point(476, 141);
            this.button46.Name = "button46";
            this.button46.Size = new System.Drawing.Size(73, 31);
            this.button46.TabIndex = 172;
            this.button46.Text = "%";
            this.button46.UseVisualStyleBackColor = true;
            // 
            // button43
            // 
            this.button43.Location = new System.Drawing.Point(32, 76);
            this.button43.Name = "button43";
            this.button43.Size = new System.Drawing.Size(48, 32);
            this.button43.TabIndex = 170;
            this.button43.Text = "=";
            this.button43.UseVisualStyleBackColor = true;
            // 
            // textBox29
            // 
            this.textBox29.Font = new System.Drawing.Font("SutonnyMJ", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox29.Location = new System.Drawing.Point(80, 77);
            this.textBox29.Multiline = true;
            this.textBox29.Name = "textBox29";
            this.textBox29.Size = new System.Drawing.Size(121, 31);
            this.textBox29.TabIndex = 166;
            // 
            // button24
            // 
            this.button24.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button24.Location = new System.Drawing.Point(202, 77);
            this.button24.Name = "button24";
            this.button24.Size = new System.Drawing.Size(190, 32);
            this.button24.TabIndex = 165;
            this.button24.Text = "রক্ষণাবেক্ষণের জন্য ২ মাস বাদ";
            this.button24.UseVisualStyleBackColor = true;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.AliceBlue;
            this.panel2.Controls.Add(this.wardnotxt);
            this.panel2.Controls.Add(this.txthomestyle);
            this.panel2.Controls.Add(this.villegehtxt);
            this.panel2.Controls.Add(this.nidholdertxt);
            this.panel2.Controls.Add(this.fathertxtholder);
            this.panel2.Controls.Add(this.comboBox1);
            this.panel2.Controls.Add(this.mobiletxtdolf);
            this.panel2.Controls.Add(this.button94);
            this.panel2.Controls.Add(this.button95);
            this.panel2.Controls.Add(this.holdingtxtho);
            this.panel2.Controls.Add(this.nameholdertax);
            this.panel2.Controls.Add(this.button96);
            this.panel2.Controls.Add(this.button97);
            this.panel2.Controls.Add(this.button98);
            this.panel2.Controls.Add(this.button99);
            this.panel2.Controls.Add(this.button100);
            this.panel2.Controls.Add(this.button101);
            this.panel2.Controls.Add(this.button102);
            this.panel2.Location = new System.Drawing.Point(3, 45);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(338, 483);
            this.panel2.TabIndex = 221;
            // 
            // wardnotxt
            // 
            this.wardnotxt.Font = new System.Drawing.Font("SutonnyMJ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.wardnotxt.FormattingEnabled = true;
            this.wardnotxt.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10"});
            this.wardnotxt.Location = new System.Drawing.Point(124, 172);
            this.wardnotxt.Name = "wardnotxt";
            this.wardnotxt.Size = new System.Drawing.Size(188, 28);
            this.wardnotxt.TabIndex = 232;
            // 
            // txthomestyle
            // 
            this.txthomestyle.Font = new System.Drawing.Font("SutonnyMJ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txthomestyle.FormattingEnabled = true;
            this.txthomestyle.Items.AddRange(new object[] {
            "KuvPv evwo",
            "L‡oi evwo",
            "`vjvb evwo",
            "d¬vU evwo"});
            this.txthomestyle.Location = new System.Drawing.Point(123, 296);
            this.txthomestyle.Name = "txthomestyle";
            this.txthomestyle.Size = new System.Drawing.Size(186, 28);
            this.txthomestyle.TabIndex = 231;
            // 
            // villegehtxt
            // 
            this.villegehtxt.Font = new System.Drawing.Font("SutonnyMJ", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.villegehtxt.Location = new System.Drawing.Point(125, 136);
            this.villegehtxt.Name = "villegehtxt";
            this.villegehtxt.Size = new System.Drawing.Size(185, 30);
            this.villegehtxt.TabIndex = 181;
            // 
            // nidholdertxt
            // 
            this.nidholdertxt.Font = new System.Drawing.Font("SutonnyMJ", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nidholdertxt.Location = new System.Drawing.Point(125, 217);
            this.nidholdertxt.Name = "nidholdertxt";
            this.nidholdertxt.Size = new System.Drawing.Size(185, 30);
            this.nidholdertxt.TabIndex = 184;
            // 
            // fathertxtholder
            // 
            this.fathertxtholder.Font = new System.Drawing.Font("SutonnyMJ", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fathertxtholder.Location = new System.Drawing.Point(125, 95);
            this.fathertxtholder.Name = "fathertxtholder";
            this.fathertxtholder.Size = new System.Drawing.Size(186, 30);
            this.fathertxtholder.TabIndex = 179;
            // 
            // comboBox1
            // 
            this.comboBox1.Font = new System.Drawing.Font("SutonnyMJ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "fvov evmv my`mn",
            "fvov evmv my`wewnb",
            "gvwjK wb‡R _v‡K my` wewnb",
            "gvwjK emevm K‡i my` mn"});
            this.comboBox1.Location = new System.Drawing.Point(124, 338);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(184, 28);
            this.comboBox1.TabIndex = 230;
            // 
            // mobiletxtdolf
            // 
            this.mobiletxtdolf.Font = new System.Drawing.Font("SutonnyMJ", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mobiletxtdolf.Location = new System.Drawing.Point(125, 255);
            this.mobiletxtdolf.Name = "mobiletxtdolf";
            this.mobiletxtdolf.Size = new System.Drawing.Size(185, 30);
            this.mobiletxtdolf.TabIndex = 186;
            // 
            // button94
            // 
            this.button94.Location = new System.Drawing.Point(28, 337);
            this.button94.Name = "button94";
            this.button94.Size = new System.Drawing.Size(90, 28);
            this.button94.TabIndex = 229;
            this.button94.Text = "ধরণ";
            this.button94.UseVisualStyleBackColor = true;
            // 
            // button95
            // 
            this.button95.Location = new System.Drawing.Point(29, 296);
            this.button95.Name = "button95";
            this.button95.Size = new System.Drawing.Size(87, 30);
            this.button95.TabIndex = 228;
            this.button95.Text = "বাড়ির ধরণ";
            this.button95.UseVisualStyleBackColor = true;
            // 
            // holdingtxtho
            // 
            this.holdingtxtho.Font = new System.Drawing.Font("SutonnyMJ", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.holdingtxtho.Location = new System.Drawing.Point(124, 23);
            this.holdingtxtho.Name = "holdingtxtho";
            this.holdingtxtho.Size = new System.Drawing.Size(188, 30);
            this.holdingtxtho.TabIndex = 175;
            // 
            // nameholdertax
            // 
            this.nameholdertax.Font = new System.Drawing.Font("SutonnyMJ", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nameholdertax.Location = new System.Drawing.Point(124, 59);
            this.nameholdertax.Name = "nameholdertax";
            this.nameholdertax.Size = new System.Drawing.Size(188, 30);
            this.nameholdertax.TabIndex = 177;
            // 
            // button96
            // 
            this.button96.Location = new System.Drawing.Point(28, 254);
            this.button96.Name = "button96";
            this.button96.Size = new System.Drawing.Size(87, 31);
            this.button96.TabIndex = 227;
            this.button96.Text = "মোবাইল নং";
            this.button96.UseVisualStyleBackColor = true;
            // 
            // button97
            // 
            this.button97.Location = new System.Drawing.Point(28, 214);
            this.button97.Name = "button97";
            this.button97.Size = new System.Drawing.Size(89, 32);
            this.button97.TabIndex = 221;
            this.button97.Text = "এনআইডি নং";
            this.button97.UseVisualStyleBackColor = true;
            // 
            // button98
            // 
            this.button98.Location = new System.Drawing.Point(28, 176);
            this.button98.Name = "button98";
            this.button98.Size = new System.Drawing.Size(90, 30);
            this.button98.TabIndex = 226;
            this.button98.Text = "ওয়ার্ড নং";
            this.button98.UseVisualStyleBackColor = true;
            // 
            // button99
            // 
            this.button99.Location = new System.Drawing.Point(28, 137);
            this.button99.Name = "button99";
            this.button99.Size = new System.Drawing.Size(90, 30);
            this.button99.TabIndex = 225;
            this.button99.Text = "গ্রাম";
            this.button99.UseVisualStyleBackColor = true;
            // 
            // button100
            // 
            this.button100.Location = new System.Drawing.Point(29, 95);
            this.button100.Name = "button100";
            this.button100.Size = new System.Drawing.Size(89, 32);
            this.button100.TabIndex = 224;
            this.button100.Text = "পিতা/মাতা";
            this.button100.UseVisualStyleBackColor = true;
            // 
            // button101
            // 
            this.button101.Location = new System.Drawing.Point(29, 59);
            this.button101.Name = "button101";
            this.button101.Size = new System.Drawing.Size(89, 30);
            this.button101.TabIndex = 223;
            this.button101.Text = "নাম";
            this.button101.UseVisualStyleBackColor = true;
            // 
            // button102
            // 
            this.button102.Location = new System.Drawing.Point(28, 22);
            this.button102.Name = "button102";
            this.button102.Size = new System.Drawing.Size(89, 30);
            this.button102.TabIndex = 222;
            this.button102.Text = "হোল্ডিং নং";
            this.button102.UseVisualStyleBackColor = true;
            this.button102.Click += new System.EventHandler(this.button102_Click);
            // 
            // txtdoronholder
            // 
            this.txtdoronholder.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtdoronholder.FormattingEnabled = true;
            this.txtdoronholder.Items.AddRange(new object[] {
            "ভাড়া বাসা সুদসহ",
            "ভাড়া বাসা সুদবিহিন",
            "মালিক নিজে থাকে সুদ বিহিন",
            "মালিক বসবাস করে সুদ সহ"});
            this.txtdoronholder.Location = new System.Drawing.Point(125, 460);
            this.txtdoronholder.Name = "txtdoronholder";
            this.txtdoronholder.Size = new System.Drawing.Size(185, 33);
            this.txtdoronholder.TabIndex = 189;
            // 
            // Form7
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1085, 563);
            this.Controls.Add(this.tabControl1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "Form7";
            this.Text = "Form7";
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Button button66;
        private System.Windows.Forms.TextBox textBox53;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button59;
        private System.Windows.Forms.Button button58;
        private System.Windows.Forms.Button button57;
        private System.Windows.Forms.Button button56;
        private System.Windows.Forms.Button button55;
        private System.Windows.Forms.Button button54;
        private System.Windows.Forms.Button button53;
        private System.Windows.Forms.Button button33;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.TextBox yearlytax;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.TextBox yealyevualationtxt;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ComboBox TaxDorontxt;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtmobile;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtnid;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtvillage;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtfather;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox nametxt;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txthold;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.ComboBox homestlyetxt;
        private System.Windows.Forms.ComboBox wordnotxt;
        private System.Windows.Forms.Button button75;
        private System.Windows.Forms.Button button74;
        private System.Windows.Forms.Button button73;
        private System.Windows.Forms.Button button72;
        private System.Windows.Forms.Button button71;
        private System.Windows.Forms.Button button70;
        private System.Windows.Forms.Button button69;
        private System.Windows.Forms.Button button68;
        private System.Windows.Forms.Button button67;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Button button65;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.TextBox taxyearlytxt;
        private System.Windows.Forms.Button button52;
        private System.Windows.Forms.Button button51;
        private System.Windows.Forms.Button button50;
        private System.Windows.Forms.Button button49;
        private System.Windows.Forms.Button button48;
        private System.Windows.Forms.Button button47;
        private System.Windows.Forms.TextBox textBox16;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.TextBox evulationyearly;
        private System.Windows.Forms.TextBox textBox18;
        private System.Windows.Forms.TextBox textBox19;
        private System.Windows.Forms.ComboBox sectiontax;
        private System.Windows.Forms.TextBox mobiletxt;
        private System.Windows.Forms.TextBox nidtxt;
        private System.Windows.Forms.TextBox villegetxt;
        private System.Windows.Forms.TextBox fathertxt;
        private System.Windows.Forms.TextBox taxholdertxt;
        private System.Windows.Forms.TextBox holdingnametxt;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.ComboBox homestyletxt;
        private System.Windows.Forms.ComboBox weardtxtno;
        private System.Windows.Forms.Button button76;
        private System.Windows.Forms.Button button77;
        private System.Windows.Forms.Button button78;
        private System.Windows.Forms.Button button79;
        private System.Windows.Forms.Button button80;
        private System.Windows.Forms.Button button81;
        private System.Windows.Forms.Button button82;
        private System.Windows.Forms.Button button83;
        private System.Windows.Forms.Button button84;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.Button button63;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.Button button23;
        private System.Windows.Forms.TextBox taxyeartxt;
        private System.Windows.Forms.TextBox textBox50;
        private System.Windows.Forms.Button button40;
        private System.Windows.Forms.Button button39;
        private System.Windows.Forms.Button button38;
        private System.Windows.Forms.Button button37;
        private System.Windows.Forms.Button button36;
        private System.Windows.Forms.Button button35;
        private System.Windows.Forms.Button button32;
        private System.Windows.Forms.Button button31;
        private System.Windows.Forms.TextBox yearevualationtaxtxt;
        private System.Windows.Forms.TextBox textBox42;
        private System.Windows.Forms.Button button27;
        private System.Windows.Forms.TextBox textBox43;
        private System.Windows.Forms.Button button28;
        private System.Windows.Forms.TextBox textBox44;
        private System.Windows.Forms.Button button29;
        private System.Windows.Forms.Button button30;
        private System.Windows.Forms.TextBox textBox45;
        private System.Windows.Forms.TextBox textBox46;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button button34;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.ComboBox Homestyle;
        private System.Windows.Forms.ComboBox wordno;
        private System.Windows.Forms.Button button85;
        private System.Windows.Forms.Button button86;
        private System.Windows.Forms.Button button87;
        private System.Windows.Forms.Button button88;
        private System.Windows.Forms.Button button89;
        private System.Windows.Forms.Button button90;
        private System.Windows.Forms.Button button91;
        private System.Windows.Forms.Button button92;
        private System.Windows.Forms.Button button93;
        private System.Windows.Forms.TextBox holdingtax;
        private System.Windows.Forms.TextBox mobilenotxt;
        private System.Windows.Forms.TextBox nidntxt;
        private System.Windows.Forms.TextBox txttvillege;
        private System.Windows.Forms.TextBox fathertxth;
        private System.Windows.Forms.TextBox txtname;
        private System.Windows.Forms.ComboBox taxsection;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.Button button42;
        private System.Windows.Forms.Button button41;
        private System.Windows.Forms.Button button25;
        private System.Windows.Forms.TextBox textBox31;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button button64;
        private System.Windows.Forms.Button button62;
        private System.Windows.Forms.Button button61;
        private System.Windows.Forms.Button button60;
        private System.Windows.Forms.Button button45;
        private System.Windows.Forms.Button button26;
        private System.Windows.Forms.TextBox yearltaxtxt;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button44;
        private System.Windows.Forms.TextBox textBox32;
        private System.Windows.Forms.TextBox textBox48;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button22;
        private System.Windows.Forms.TextBox avulationtaxyear;
        private System.Windows.Forms.Button button46;
        private System.Windows.Forms.Button button43;
        private System.Windows.Forms.TextBox textBox29;
        private System.Windows.Forms.Button button24;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.ComboBox wardnotxt;
        private System.Windows.Forms.ComboBox txthomestyle;
        private System.Windows.Forms.TextBox villegehtxt;
        private System.Windows.Forms.TextBox nidholdertxt;
        private System.Windows.Forms.TextBox fathertxtholder;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.TextBox mobiletxtdolf;
        private System.Windows.Forms.Button button94;
        private System.Windows.Forms.Button button95;
        private System.Windows.Forms.TextBox holdingtxtho;
        private System.Windows.Forms.TextBox nameholdertax;
        private System.Windows.Forms.Button button96;
        private System.Windows.Forms.Button button97;
        private System.Windows.Forms.Button button98;
        private System.Windows.Forms.Button button99;
        private System.Windows.Forms.Button button100;
        private System.Windows.Forms.Button button101;
        private System.Windows.Forms.Button button102;
        private System.Windows.Forms.ComboBox txtdoronholder;
    }
}