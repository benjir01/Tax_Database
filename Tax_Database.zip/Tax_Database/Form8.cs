﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace Tax_Database
{
    public partial class Form8 : Form
    {
        SqlConnection mcon = new SqlConnection(@"Data Source=.\SQLEXPRESS;Initial Catalog=Tax_Database;Integrated Security=True");
        SqlCommand mcd;
        string q;
        public Form8()
        {
            InitializeComponent();
        }

        private void button11_Click(object sender, EventArgs e)
        {
            try
            {
                string q = "Insert Into NoneHoldingAssesment (LiecenceNo,Name,Father,Villege,Post,Subdist,Tradetype,Secttion,Value,Fixtax) Values('" + liecenceNotxt.Text + "','" + Nametxt.Text + "','" + fathertxt.Text + "','" + villegetxt.Text + "','" + posttxt.Text + "','" + upjelatxt.Text + "','" + tradetypetxt.Text + "','" + tradenametxt.Text + "','" + pojytxt.Text + "','" + fixtaxtxt.Text + "' ) ";
                ExecuteQuiry(q);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally {
            }
        }
        public void Opencon()
        {
            try
            {
                if (mcon.State == ConnectionState.Closed)
                {
                    mcon.Open();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }
            finally
            {
 
            }
        }
        public void Closencon()
        {
            try
            {
                if (mcon.State == ConnectionState.Open)
                {
                    mcon.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
 
            }
        }

        public void ExecuteQuiry(string q)
        {
            try
            {
                mcon.Open();
                mcd = new SqlCommand(q, mcon);
                if (mcd.ExecuteNonQuery() == 1)
                {
                    MessageBox.Show("Quiry SuccessFully Executed");
                }
                else
                {
                    MessageBox.Show("Quiry Not Executed");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                mcon.Close();
            }
        }

        private void button12_Click(object sender, EventArgs e)
        {
            try
            {
                DialogResult result = MessageBox.Show("Are you Sure you want to Update", "Exit", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                {
                    string q = "update  NoneHoldingAssesment set Name= '" + Nametxt.Text + "', Father= '" + fathertxt.Text + "', Villege = '" + villegetxt.Text + "',Post = '" + posttxt.Text + "',Subdist = '" + upjelatxt.Text + "',Tradetype = '" + tradetypetxt.Text + "', Secttion = '" + tradenametxt.Text + "', Value = '" + pojytxt.Text + "' ,  Fixtax = '" + fixtaxtxt.Text + "' ,   Where LiecenceNo = '" + liecenceNotxt.Text + "'";
                    ExecuteQuiry(q);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }
            finally
            {
 
            }
        }

        private void button13_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Are You Sure You Want To Delete", "Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                string q = "Delete From NoneHoldingAssesment Where LiecenceNo = '" + liecenceNotxt.Text + "'";
                ExecuteQuiry(q);
            }
        }

        private void button14_Click(object sender, EventArgs e)
        {
            mcon.Open();
            q = "select * from  NoneHoldingAssesment where LiecenceNo ='" + liecenceNotxt.Text.Trim() + "'";
            mcd = new SqlCommand(q, mcon);
            SqlDataReader reader = mcd.ExecuteReader();

            if (reader.Read())
            {
                Nametxt.Text = reader["Name"].ToString();
                fathertxt.Text = reader["Father"].ToString();
                villegetxt.Text = reader["Villege"].ToString();
                posttxt.Text = reader["Post"].ToString();
                upjelatxt.Text = reader["Subdist"].ToString();
                tradetypetxt.Text = reader["Tradetype"].ToString();
                tradenametxt.Text = reader["Secttion"].ToString();
                pojytxt.Text = reader["Value"].ToString();
                fixtaxtxt.Text = reader["Fixtax"].ToString();

            }
            else
            {
                MessageBox.Show("Sorry Data Not Finded");
            }


            mcon.Close();
            reader.Close();
        }

        private void button27_Click(object sender, EventArgs e)
        {
            string q = "Insert Into TaxRegisterNonholding (LiecenceNo,Name,Father,Villege,Post,Subdist,Tradetype,Secttion,CollectDate,Value,Financyear,Amount) Values('" + leincenotxt.Text + "','" + txtnametxt.Text + "','" + fathertxtt.Text + "','" + villegetxtr.Text + "','" + posttxtr.Text + "','" + subdistxt.Text + "','" + typetxttrade.Text + "','" + tadenametxt.Text + "','" + collecttxtdate.Text + "','" + fixctaxtxtt.Text + "', '" + financialtxt.Text + "','" + moneyamounttxt.Text + "' ) ";
            ExecuteQuiry(q);
        }

        private void button28_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Are you Sure you want to Update", "Exit", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                string q = "update  TaxRegisterNonholding set Name= '" + txtnametxt.Text + "', Father= '" + fathertxtt.Text + "', Villege = '" + villegetxtr.Text + "',Post = '" + posttxtr.Text + "',Subdist = '" + subdistxt.Text + "',Tradetype = '" + typetxttrade.Text + "', Secttion = '" + tadenametxt.Text + "', CollectDate = '" + collecttxtdate.Text + "' ,  Value = '" + fixctaxtxtt.Text + "' ,     Financyear='" + financialtxt.Text + "',   Amount='" + moneyamounttxt.Text + "'   Where LiecenceNo = '" + leincenotxt.Text + "'";
                ExecuteQuiry(q);
            }
        }

        private void button29_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Are You Sure You Want To Delete", "Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                string q = "Delete From TaxRegisterNonholding Where LiecenceNo = '" + leincenotxt.Text + "'";
                ExecuteQuiry(q);
            }
        }

        private void button30_Click(object sender, EventArgs e)
        {
            mcon.Open();
            q = "select * from TaxRegisterNonholding where LiecenceNo ='" + leincenotxt.Text.Trim() + "'";
            mcd = new SqlCommand(q, mcon);
            SqlDataReader reader = mcd.ExecuteReader();

            if (reader.Read())
            {
                txtnametxt.Text = reader["Name"].ToString();
                fathertxtt.Text = reader["Father"].ToString();
                villegetxtr.Text = reader["Villege"].ToString();
                posttxtr.Text = reader["Post"].ToString();
                subdistxt.Text = reader["Subdist"].ToString();
                typetxttrade.Text = reader["Tradetype"].ToString();
                tadenametxt.Text = reader["Secttion"].ToString();
                //collecttxtdate.Text = reader["CollectDate"].ToString();
                fixctaxtxtt.Text = reader["Value"].ToString();
                financialtxt.Text = reader["Financyear"].ToString();
                moneyamounttxt.Text = reader["Amount"].ToString();

            }
            else
            {
                MessageBox.Show("Sorry Data Not Finded");
            }


            mcon.Close();
            reader.Close();
        }

        private void button47_Click(object sender, EventArgs e)
        {
            string q = "Insert Into TradeLien_Info (LiecenceNo, Financialyear, RegistrationDate,TradeName,PropiterName,Father,TVillege,TPost,MVillage,MPost2,MSubdist,TradeType,Validity,Money,Inword,TradeNameto) Values('" + liencetxt.Text + "','" + jelatxctxman.Text + "','" + registationdatetxt.Text + "','" + tradenametxtl.Text + "','" + propaitortxt.Text + "','" + fathattxt.Text + "','" + locationtxt.Text + "','" + posttxtb.Text + "','" + tradernametxt.Text + "','" + postmantxt.Text + "', '" + upojelatxtman.Text + "','" + businesstypetxt.Text + "','" + validitytxt.Text + "', '" + amounttakatxt.Text + "','" + txtinwardtxt.Text + "','" + tadenametxtlien.Text + "' )";
            ExecuteQuiry(q);
        }

        private void button48_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Are you Sure you want to Update", "Exit", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                string q = "update  TradeLien_Info set  Financialyear='" + jelatxctxman.Text + "',RegistrationDate= '" + registationdatetxt.Text + "', TradeName= '" + tradenametxtl.Text + "', PropiterName = '" + propaitortxt.Text + "',Father = '" + fathattxt.Text + "',TVillege = '" + locationtxt.Text + "',TPost = '" + posttxtb.Text + "', MVillage = '" + tradernametxt.Text + "', MPost2 = '" + postmantxt.Text + "' ,  MSubdist = '" + upojelatxtman.Text + "' ,  TradeType='" + businesstypetxt.Text + "',  Validity='" + validitytxt.Text + "', Money='" + amounttakatxt.Text + "', Inword='" + txtinwardtxt.Text + "', TradeNameto='" + tadenametxtlien.Text + "' Where LiecenceNo = '" + leincenotxt.Text + "'";
                ExecuteQuiry(q);
            }
        }

        private void button49_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Are You Sure You Want To Delete", "Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                string q = "Delete From TradeLien_Info Where LiecenceNo = '" + liencetxt.Text + "'";
                ExecuteQuiry(q);
            }
        }

        private void button50_Click(object sender, EventArgs e)
        {
            mcon.Open();
            q = "select * from TradeLien_Info where LiecenceNo ='" + liencetxt.Text.Trim() + "'";
            mcd = new SqlCommand(q, mcon);
            SqlDataReader reader = mcd.ExecuteReader();

            if (reader.Read())
            {



                jelatxctxman.Text = reader["Financialyear"].ToString();
                registationdatetxt.Text = reader["RegistrationDate"].ToString();
                tradenametxtl.Text = reader["TradeName"].ToString();
                propaitortxt.Text = reader["PropiterName"].ToString();
                fathattxt.Text = reader["Father"].ToString();
                locationtxt.Text = reader["TVillege"].ToString();
                posttxtb.Text = reader["TPost"].ToString();
                tradernametxt.Text = reader["MVillage"].ToString();
                postmantxt.Text = reader["MPost2"].ToString();
                upojelatxtman.Text = reader["MSubdist"].ToString();
                businesstypetxt.Text = reader["TradeType"].ToString();
                validitytxt.Text = reader["Validity"].ToString();
                amounttakatxt.Text = reader["Money"].ToString();
                txtinwardtxt.Text = reader["Inword"].ToString();
                tadenametxtlien.Text = reader["TradeNameto"].ToString();



            }
            else
            {
                MessageBox.Show("Sorry Data Not Finded");
            }


            mcon.Close();
            reader.Close();
        }

        private void tadenametxtlien_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
