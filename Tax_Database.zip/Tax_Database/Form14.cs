﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tax_Database
{
    public partial class Form14 : Form
    {
        public Form14()
        {
            InitializeComponent();
        }

        private void Form14_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'Tax_DatabaseDataSet11.TradeLien_Info' table. You can move, or remove it, as needed.
            this.TradeLien_InfoTableAdapter.Fill(this.Tax_DatabaseDataSet11.TradeLien_Info);

            this.reportViewer1.RefreshReport();
        }

        private void fillByToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.TradeLien_InfoTableAdapter.FillBy(this.Tax_DatabaseDataSet11.TradeLien_Info, ((int)(System.Convert.ChangeType(liecenceNoToolStripTextBox.Text, typeof(int)))), financialyearToolStripTextBox.Text, tradeNameToolStripTextBox.Text);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }
    }
}
