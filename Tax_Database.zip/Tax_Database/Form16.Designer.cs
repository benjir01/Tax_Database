﻿namespace Tax_Database
{
    partial class Form16
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource1 = new Microsoft.Reporting.WinForms.ReportDataSource();
            this.TradeLien_InfoBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.Tax_DatabaseDataSet12 = new Tax_Database.Tax_DatabaseDataSet12();
            this.reportViewer1 = new Microsoft.Reporting.WinForms.ReportViewer();
            this.TradeLien_InfoTableAdapter = new Tax_Database.Tax_DatabaseDataSet12TableAdapters.TradeLien_InfoTableAdapter();
            this.fillBy1ToolStrip = new System.Windows.Forms.ToolStrip();
            this.liecenceNoToolStripLabel = new System.Windows.Forms.ToolStripLabel();
            this.liecenceNoToolStripTextBox = new System.Windows.Forms.ToolStripTextBox();
            this.financialyearToolStripLabel = new System.Windows.Forms.ToolStripLabel();
            this.financialyearToolStripTextBox = new System.Windows.Forms.ToolStripTextBox();
            this.tradeTypeToolStripLabel = new System.Windows.Forms.ToolStripLabel();
            this.tradeTypeToolStripTextBox = new System.Windows.Forms.ToolStripTextBox();
            this.fillBy1ToolStripButton = new System.Windows.Forms.ToolStripButton();
            ((System.ComponentModel.ISupportInitialize)(this.TradeLien_InfoBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Tax_DatabaseDataSet12)).BeginInit();
            this.fillBy1ToolStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // TradeLien_InfoBindingSource
            // 
            this.TradeLien_InfoBindingSource.DataMember = "TradeLien_Info";
            this.TradeLien_InfoBindingSource.DataSource = this.Tax_DatabaseDataSet12;
            // 
            // Tax_DatabaseDataSet12
            // 
            this.Tax_DatabaseDataSet12.DataSetName = "Tax_DatabaseDataSet12";
            this.Tax_DatabaseDataSet12.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // reportViewer1
            // 
            this.reportViewer1.DocumentMapWidth = 35;
            reportDataSource1.Name = "DataSet1";
            reportDataSource1.Value = this.TradeLien_InfoBindingSource;
            this.reportViewer1.LocalReport.DataSources.Add(reportDataSource1);
            this.reportViewer1.LocalReport.ReportEmbeddedResource = "Tax_Database.Report17.rdlc";
            this.reportViewer1.Location = new System.Drawing.Point(12, 57);
            this.reportViewer1.Name = "reportViewer1";
            this.reportViewer1.Size = new System.Drawing.Size(650, 563);
            this.reportViewer1.TabIndex = 0;
            // 
            // TradeLien_InfoTableAdapter
            // 
            this.TradeLien_InfoTableAdapter.ClearBeforeFill = true;
            // 
            // fillBy1ToolStrip
            // 
            this.fillBy1ToolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.liecenceNoToolStripLabel,
            this.liecenceNoToolStripTextBox,
            this.financialyearToolStripLabel,
            this.financialyearToolStripTextBox,
            this.tradeTypeToolStripLabel,
            this.tradeTypeToolStripTextBox,
            this.fillBy1ToolStripButton});
            this.fillBy1ToolStrip.Location = new System.Drawing.Point(0, 0);
            this.fillBy1ToolStrip.Name = "fillBy1ToolStrip";
            this.fillBy1ToolStrip.Size = new System.Drawing.Size(684, 25);
            this.fillBy1ToolStrip.TabIndex = 1;
            this.fillBy1ToolStrip.Text = "fillBy1ToolStrip";
            // 
            // liecenceNoToolStripLabel
            // 
            this.liecenceNoToolStripLabel.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.liecenceNoToolStripLabel.Name = "liecenceNoToolStripLabel";
            this.liecenceNoToolStripLabel.Size = new System.Drawing.Size(69, 22);
            this.liecenceNoToolStripLabel.Text = "লাইসেন্স নং";
            // 
            // liecenceNoToolStripTextBox
            // 
            this.liecenceNoToolStripTextBox.Name = "liecenceNoToolStripTextBox";
            this.liecenceNoToolStripTextBox.Size = new System.Drawing.Size(100, 25);
            // 
            // financialyearToolStripLabel
            // 
            this.financialyearToolStripLabel.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.financialyearToolStripLabel.Name = "financialyearToolStripLabel";
            this.financialyearToolStripLabel.Size = new System.Drawing.Size(52, 22);
            this.financialyearToolStripLabel.Text = "অর্থবছর";
            // 
            // financialyearToolStripTextBox
            // 
            this.financialyearToolStripTextBox.Name = "financialyearToolStripTextBox";
            this.financialyearToolStripTextBox.Size = new System.Drawing.Size(100, 25);
            // 
            // tradeTypeToolStripLabel
            // 
            this.tradeTypeToolStripLabel.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tradeTypeToolStripLabel.Name = "tradeTypeToolStripLabel";
            this.tradeTypeToolStripLabel.Size = new System.Drawing.Size(79, 22);
            this.tradeTypeToolStripLabel.Text = "ব্যবসার ধরণ";
            // 
            // tradeTypeToolStripTextBox
            // 
            this.tradeTypeToolStripTextBox.Name = "tradeTypeToolStripTextBox";
            this.tradeTypeToolStripTextBox.Size = new System.Drawing.Size(100, 25);
            // 
            // fillBy1ToolStripButton
            // 
            this.fillBy1ToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.fillBy1ToolStripButton.Name = "fillBy1ToolStripButton";
            this.fillBy1ToolStripButton.Size = new System.Drawing.Size(49, 22);
            this.fillBy1ToolStripButton.Text = "Submit";
            this.fillBy1ToolStripButton.Click += new System.EventHandler(this.fillBy1ToolStripButton_Click);
            // 
            // Form16
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(684, 640);
            this.Controls.Add(this.fillBy1ToolStrip);
            this.Controls.Add(this.reportViewer1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "Form16";
            this.Text = "Form16";
            this.Load += new System.EventHandler(this.Form16_Load);
            ((System.ComponentModel.ISupportInitialize)(this.TradeLien_InfoBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Tax_DatabaseDataSet12)).EndInit();
            this.fillBy1ToolStrip.ResumeLayout(false);
            this.fillBy1ToolStrip.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Microsoft.Reporting.WinForms.ReportViewer reportViewer1;
        private System.Windows.Forms.BindingSource TradeLien_InfoBindingSource;
        private Tax_DatabaseDataSet12 Tax_DatabaseDataSet12;
        private Tax_DatabaseDataSet12TableAdapters.TradeLien_InfoTableAdapter TradeLien_InfoTableAdapter;
        private System.Windows.Forms.ToolStrip fillBy1ToolStrip;
        private System.Windows.Forms.ToolStripLabel liecenceNoToolStripLabel;
        private System.Windows.Forms.ToolStripTextBox liecenceNoToolStripTextBox;
        private System.Windows.Forms.ToolStripLabel financialyearToolStripLabel;
        private System.Windows.Forms.ToolStripTextBox financialyearToolStripTextBox;
        private System.Windows.Forms.ToolStripLabel tradeTypeToolStripLabel;
        private System.Windows.Forms.ToolStripTextBox tradeTypeToolStripTextBox;
        private System.Windows.Forms.ToolStripButton fillBy1ToolStripButton;
    }
}