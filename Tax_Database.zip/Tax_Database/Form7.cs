﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace Tax_Database
{
    public partial class Form7 : Form
    {
        SqlConnection mcon = new SqlConnection(@"Data Source=.\SQLEXPRESS;Initial Catalog=Tax_Database;Integrated Security=True");
        SqlCommand mcd;
        string q;
        public Form7()
        {
            InitializeComponent();
        }

        private void textBox10_TextChanged(object sender, EventArgs e)
        {
            try
            {
                int A = 12, B, C;
                B = int.Parse(textBox10.Text);
                C = B * A;
                textBox5.Text = Convert.ToString(C);

                int g1 = 2, h5, k6, j3, m1;

                h5 = int.Parse(textBox10.Text);

                k6 = h5 * g1;

                j3 = int.Parse(textBox5.Text);

                m1 = j3 - k6;
                textBox9.Text = Convert.ToString(m1);

                int Sum, minus, Dial;

                Sum = int.Parse(textBox9.Text);
                minus = int.Parse(textBox8.Text);

                Dial = Sum - minus;
                yealyevualationtxt.Text = Convert.ToString(Dial);

                int originalprice = 0;
                double discout, givenprice = 0;

                originalprice = int.Parse(yealyevualationtxt.Text);
                discout = double.Parse(textBox53.Text);

                givenprice = originalprice * (discout / 100);

                yearlytax.Text = givenprice.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {

            }
        }

        private void textBox18_TextChanged(object sender, EventArgs e)
        {
            try
            {
                int b2 = 12, b3, b5;

                b3 = int.Parse(textBox18.Text);

                b5 = b3 * b2;

                textBox16.Text = Convert.ToString(b5);
                int g1 = 2, h5, k6, j3, m1;

                h5 = int.Parse(textBox18.Text);

                k6 = h5 * g1;

                j3 = int.Parse(textBox16.Text);

                m1 = j3 - k6;
                evulationyearly.Text = Convert.ToString(m1);

                int originalprice = 0;
                double discout, givenprice = 0;

                originalprice = int.Parse(evulationyearly.Text);
                discout = double.Parse(textBox19.Text);

                givenprice = originalprice * (discout / 100);

                taxyearlytxt.Text = givenprice.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {

            }
        }

        private void textBox46_TextChanged(object sender, EventArgs e)
        {
            try
            {
                int b2 = 12, b3, b5;

                b3 = int.Parse(textBox46.Text);

                b5 = b3 * b2;

                textBox44.Text = Convert.ToString(b5);

                int g1 = 2, h5, k6, j3, m1;

                h5 = int.Parse(textBox46.Text);

                k6 = g1 * h5;

                j3 = int.Parse(textBox44.Text);

                m1 = j3 - k6;
                textBox45.Text = Convert.ToString(m1);

                int hs = 4, hg, kf = 3, kn;

                hg = int.Parse(textBox45.Text);

                hg = hg / hs;

                kn = hg * kf;

                textBox43.Text = Convert.ToString(kn);

                int Sum, minus, Dial;

                Sum = int.Parse(textBox43.Text);
                minus = int.Parse(textBox50.Text);

                Dial = Sum - minus;
                yearevualationtaxtxt.Text = Convert.ToString(Dial);

                int originalprice = 0;
                double discout, givenprice = 0;

                originalprice = int.Parse(yearevualationtaxtxt.Text);
                discout = double.Parse(textBox42.Text);

                givenprice = originalprice * (discout / 100);

                taxyeartxt.Text = givenprice.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {

            }
        }

        private void textBox31_TextChanged(object sender, EventArgs e)
        {
             try
                {
                int b2 = 12, b3, b5;

                b3 = int.Parse(textBox31.Text);

                b5 = b3 * b2;

                textBox29.Text = Convert.ToString(b5);

                int g1 = 2, h5, k6, j3, m1;

                h5 = int.Parse(textBox31.Text);

                k6 = g1 * h5;

                j3 = int.Parse(textBox29.Text);

                m1 = j3 - k6;
                textBox32.Text = Convert.ToString(m1);

                int hs = 4, hg, kf = 3, fr, kn;

                hg = int.Parse(textBox32.Text);

                fr = hg / hs;

                kn = fr * kf;

                avulationtaxyear.Text = Convert.ToString(kn);

                int originalprice = 0;
                double discout, givenprice = 0;

                originalprice = int.Parse(avulationtaxyear.Text);
                discout = double.Parse(textBox48.Text);

                givenprice = originalprice * (discout / 100);

                yearltaxtxt.Text = givenprice.ToString();
             }
             
             catch (Exception ex)
             {
                 MessageBox.Show(ex.Message);
             }
            finally 
             {

             }
        }
       
    

        private void button6_Click(object sender, EventArgs e)
        {
            try
            {
                string q = "Insert Into Taxassesment_Info (Holding,Name,Fathername,Villege,WardNo,Nid,MobileNo,HomeStyle,Taxsection,Yearlyevualtion,Yearlytax) Values('" + txthold.Text + "','" + nametxt.Text + "','" + txtfather.Text + "','" + txtvillage.Text + "','" + wordnotxt.Text + "','" + txtnid.Text + "','" + txtmobile.Text + "','" + homestyletxt.Text + "','" + TaxDorontxt.Text + "','" + yealyevualationtxt.Text + "', '" + yearlytax.Text + "' ) ";
                ExecuteQuiry(q);
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
 
            }
        }
        public void Opencon()
        {
            try
            {
                if (mcon.State == ConnectionState.Closed)
                {
                    mcon.Open();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
 
            }
        }
        public void Closencon()
        {
            try
            {
                if (mcon.State == ConnectionState.Open)
                {
                    mcon.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
 
            }
        }

        public void ExecuteQuiry(string q)
        {
            try
            {
                mcon.Open();
                mcd = new SqlCommand(q, mcon);
                if (mcd.ExecuteNonQuery() == 1)
                {
                    MessageBox.Show("Quiry SuccessFully Executed");
                }
                else
                {
                    MessageBox.Show("Quiry Not Executed");
                }
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
                mcon.Close();
            }
        }

        private void button13_Click(object sender, EventArgs e)
        {
            try
            {
                string q = "Insert Into Taxassesment_Info (Holding,Name,Fathername,Villege,WardNo,Nid,MobileNo,HomeStyle,Taxsection,Yearlyevualtion,Yearlytax) Values('" + holdingnametxt.Text + "','" + taxholdertxt.Text + "','" + fathertxt.Text + "','" + villegetxt.Text + "','" + weardtxtno.Text + "','" + nidtxt.Text + "','" + mobiletxt.Text + "','" + homestyletxt.Text + "','" + sectiontax.Text + "','" + evulationyearly.Text + "', '" + taxyearlytxt.Text + "' ) ";
                ExecuteQuiry(q);
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
 
            }
        }

        private void button17_Click(object sender, EventArgs e)
        {
            try
            {
                string q = "Insert Into Taxassesment_Info (Holding,Name,Fathername,Villege,WardNo,Nid,MobileNo,HomeStyle,Taxsection,Yearlyevualtion,Yearlytax) Values('" + holdingtax.Text + "','" + txtname.Text + "','" + fathertxth.Text + "','" + txttvillege.Text + "','" + wordno.Text + "','" + nidntxt.Text + "','" + mobilenotxt.Text + "','" + Homestyle.Text + "','" + taxsection.Text + "','" + yearevualationtaxtxt.Text + "', '" + taxyeartxt.Text + "' ) ";
                ExecuteQuiry(q);
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);

            }
            finally
            {
 
            }
        }

        private void button26_Click(object sender, EventArgs e)
        {
            try
            {
                string q = "Insert Into Taxassesment_Info (Holding,Name,Fathername,Villege,WardNo,Nid,MobileNo,HomeStyle,Taxsection,Yearlyevualtion,Yearlytax) Values('" + holdingtxtho.Text + "','" + nameholdertax.Text + "','" + fathertxtholder.Text + "','" + villegehtxt.Text + "','" + wardnotxt.Text + "','" + nidholdertxt.Text + "','" + mobiletxtdolf.Text + "','" + txthomestyle.Text + "','" + comboBox1.Text + "','" + avulationtaxyear.Text + "', '" + yearltaxtxt.Text + "' ) ";
                ExecuteQuiry(q);
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
 
            }
        }

        private void button19_Click(object sender, EventArgs e)
        {
            try
            {
                DialogResult result = MessageBox.Show("Are You Sure You Want To Delete", "Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                {
                    string q = "Delete From Taxassesment_Info Where Holding = '" + holdingtax.Text + "'";
                    ExecuteQuiry(q);
                }
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
 
            }
        }

        private void button60_Click(object sender, EventArgs e)
        {
            try
            {
                DialogResult result = MessageBox.Show("Are You Sure You Want To Delete", "Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                {
                    string q = "Delete From Taxassesment_Info Where Holding = '" + holdingtxtho.Text + "'";
                    ExecuteQuiry(q);
                }
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
 
            }
        }

        private void button15_Click(object sender, EventArgs e)
        {
            try
            {
                DialogResult result = MessageBox.Show("Are You Sure You Want To Delete", "Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                {
                    string q = "Delete From Taxassesment_Info Where Holding = '" + holdingnametxt.Text + "'";
                    ExecuteQuiry(q);
                }
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
 
            }
        }

        private void button10_Click(object sender, EventArgs e)
        {
            try
            {
                DialogResult result = MessageBox.Show("Are You Sure You Want To Delete", "Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                {
                    string q = "Delete From Taxassesment_Info Where Holding = '" + txthold.Text + "'";
                    ExecuteQuiry(q);
                }
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
 
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            try
            {
                DialogResult result = MessageBox.Show("Are you Sure you want to Update", "Exit", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                {
                    string q = "update  Taxassesment_Info set Name= '" + nametxt.Text + "', Fathername= '" + txtfather.Text + "', Villege = '" + txtvillage.Text + "',WardNo = '" + wordnotxt.Text + "',Nid = '" + txtnid.Text + "',MobileNo = '" + txtmobile.Text + "', HomeStyle = '" + homestlyetxt.Text + "', Taxsection = '" + TaxDorontxt.Text + "' ,  Yearlyevualtion = '" + yealyevualationtxt.Text + "' ,  Yearlytax = '" + yearlytax.Text + "'    Where Holding = '" + txthold.Text + "'";
                    ExecuteQuiry(q);
                }
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
 
            }
        }

        private void button14_Click(object sender, EventArgs e)
        {
            try
            {

                DialogResult result = MessageBox.Show("Are you Sure you want to Update", "Exit", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                {
                    string q = "update  Taxassesment_Info set Name= '" + taxholdertxt.Text + "', Fathername= '" + fathertxt.Text + "', Villege = '" + villegetxt.Text + "',WardNo = '" + weardtxtno.Text + "',Nid = '" + nidtxt.Text + "',MobileNo = '" + mobiletxt.Text + "', HomeStyle = '" + homestyletxt.Text + "', Taxsection = '" + sectiontax.Text + "' ,  Yearlyevualtion = '" + evulationyearly.Text + "' ,  Yearlytax = '" + taxyearlytxt.Text + "'    Where Holding = '" + holdingnametxt.Text + "'";
                    ExecuteQuiry(q);
                }
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
 
            }
        }

        private void button18_Click(object sender, EventArgs e)
        {
            try
            {
                DialogResult result = MessageBox.Show("Are you Sure you want to Update", "Exit", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                {
                    try
                    {
                        string q = "update  Taxassesment_Info set Name= '" + txtname.Text + "', Fathername= '" + fathertxth.Text + "', Villege = '" + txttvillege.Text + "',WardNo = '" + wordno.Text + "',Nid = '" + nidntxt.Text + "',MobileNo = '" + mobilenotxt.Text + "', HomeStyle = '" + Homestyle.Text + "', Taxsection = '" + taxsection.Text + "' ,  Yearlyevualtion = '" + yearevualationtaxtxt.Text + "' ,  Yearlytax = '" + taxyeartxt.Text + "'    Where Holding = '" + holdingtax.Text + "'";
                        try
                        {
                            ExecuteQuiry(q);
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show(ex.Message);
                        }
                        finally
                        {
 
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                    finally
                    {
 
                    }
                }
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
 
            }
        }

        private void button45_Click(object sender, EventArgs e)
        {
            try
            {

                DialogResult result = MessageBox.Show("Are you Sure you want to Update", "Exit", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                {
                    string q = "update  Taxassesment_Info set Name= '" + nameholdertax.Text + "', Fathername= '" + fathertxtholder.Text + "', Villege = '" + villegehtxt.Text + "',WardNo = '" + wardnotxt.Text + "',Nid = '" + nidholdertxt.Text + "',MobileNo = '" + mobiletxtdolf.Text + "', HomeStyle = '" + txthomestyle.Text + "', Taxsection = '" + comboBox1.Text + "' ,  Yearlyevualtion = '" + avulationtaxyear.Text + "' ,  Yearlytax = '" + yearltaxtxt.Text + "'   Where Holding = '" + holdingtxtho.Text + "'";
                    ExecuteQuiry(q);
                }
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            finally
            {
 
            }
        }

        private void button16_Click(object sender, EventArgs e)
        {
            try
            {
                mcon.Open();
                q = "select * from Taxassesment_Info where Holding ='" + holdingnametxt.Text.Trim() + "'";
                mcd = new SqlCommand(q, mcon);
                SqlDataReader reader = mcd.ExecuteReader();

                if (reader.Read())
                {
                    try
                    {
                        taxholdertxt.Text = reader["Name"].ToString();
                        fathertxt.Text = reader["Fathername"].ToString();
                        villegetxt.Text = reader["Villege"].ToString();
                        weardtxtno.Text = reader["WardNo"].ToString();
                        nidtxt.Text = reader["Nid"].ToString();
                        mobiletxt.Text = reader["MobileNo"].ToString();
                        homestyletxt.Text = reader["HomeStyle"].ToString();
                        sectiontax.Text = reader["Taxsection"].ToString();
                        evulationyearly.Text = reader["Yearlyevualtion"].ToString();
                        taxyearlytxt.Text = reader["Yearlytax"].ToString();

                        //MessageBox.Show("Yes Your Data Correct");
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                    }
                    finally
                    {
 
                    }

                }
                else
                {
                    MessageBox.Show("Sorry Data Not Finded");
                }


                mcon.Close();
                reader.Close();
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);

            }
            finally
            {
                
            }

        }

        private void button11_Click(object sender, EventArgs e)
        {
            try
            {
                mcon.Open();
                q = "select * from Taxassesment_Info where Holding ='" + txthold.Text.Trim() + "'";
                mcd = new SqlCommand(q, mcon);
                SqlDataReader reader = mcd.ExecuteReader();

                if (reader.Read())
                {
                    nametxt.Text = reader["Name"].ToString();
                    txtfather.Text = reader["Fathername"].ToString();
                    txtvillage.Text = reader["Villege"].ToString();
                    wordnotxt.Text = reader["WardNo"].ToString();
                    txtnid.Text = reader["Nid"].ToString();
                    txtmobile.Text = reader["MobileNo"].ToString();
                    homestlyetxt.Text = reader["HomeStyle"].ToString();
                    TaxDorontxt.Text = reader["Taxsection"].ToString();
                    yealyevualationtxt.Text = reader["Yearlyevualtion"].ToString();
                    yearlytax.Text = reader["Yearlytax"].ToString();

                    //MessageBox.Show("Yes Your Data Correct");
                }
                else
                {
                    MessageBox.Show("Sorry Data Not Finded");
                }


                mcon.Close();
                reader.Close();
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);

            }
            finally 
            {
 
            }
        }

        private void button23_Click(object sender, EventArgs e)
        {
            try
            {

                mcon.Open();
                q = "select * from Taxassesment_Info where Holding ='" + holdingtax.Text.Trim() + "'";
                mcd = new SqlCommand(q, mcon);
                SqlDataReader reader = mcd.ExecuteReader();

                if (reader.Read())
                {
                    txtname.Text = reader["Name"].ToString();
                    fathertxth.Text = reader["Fathername"].ToString();
                    txttvillege.Text = reader["Villege"].ToString();
                    wordno.Text = reader["WardNo"].ToString();
                    nidtxt.Text = reader["Nid"].ToString();
                    mobilenotxt.Text = reader["MobileNo"].ToString();
                    Homestyle.Text = reader["HomeStyle"].ToString();
                    taxsection.Text = reader["Taxsection"].ToString();
                    yearevualationtaxtxt.Text = reader["Yearlyevualtion"].ToString();
                    taxyeartxt.Text = reader["Yearlytax"].ToString();

                    //MessageBox.Show("Yes Your Data Correct");
                }
                else
                {
                    MessageBox.Show("Sorry Data Not Finded");
                }


                mcon.Close();
                reader.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally{

            }
        }

        private void button61_Click(object sender, EventArgs e)
        {
           
            mcon.Open();
            q = "select * from Taxassesment_Info where Holding ='" + holdingtxtho.Text.Trim() + "'";
            mcd = new SqlCommand(q, mcon);
            SqlDataReader reader = mcd.ExecuteReader();

            if (reader.Read())
            {
                nameholdertax.Text = reader["Name"].ToString();
                fathertxtholder.Text = reader["Fathername"].ToString();
                villegehtxt.Text = reader["Villege"].ToString();
                wardnotxt.Text = reader["WardNo"].ToString();
                nidholdertxt.Text = reader["Nid"].ToString();
                mobiletxtdolf.Text = reader["MobileNo"].ToString();
                txthomestyle.Text = reader["HomeStyle"].ToString();
                comboBox1.Text = reader["Taxsection"].ToString();
                avulationtaxyear.Text = reader["Yearlyevualtion"].ToString();
                yearltaxtxt.Text = reader["Yearlytax"].ToString();

                //MessageBox.Show("Yes Your Data Correct");


            }
            else
            {
                MessageBox.Show("Sorry Data Not Finded");
            }


            mcon.Close();
            reader.Close();
        }

        private void button67_Click(object sender, EventArgs e)
        {
            mcon.Open();
            q = "select * from People_Info where Holding ='" + txthold.Text.Trim() + "'";
            mcd = new SqlCommand(q, mcon);
            SqlDataReader reader = mcd.ExecuteReader();

            if (reader.Read())
            {
                nametxt.Text = reader["Name"].ToString();
                txtfather.Text = reader["Father"].ToString();
                txtvillage.Text = reader["Villege"].ToString();
                wordnotxt.Text = reader["WardNo"].ToString();
                txtnid.Text = reader["NidNo"].ToString();
                txtmobile.Text = reader["MobileNo"].ToString();

                //MessageBox.Show("Yes Your Data Correct");


            }
            else
            {
                MessageBox.Show("Sorry Data Not Finded");
            }
            mcon.Close();
            reader.Close();
        }

        private void button84_Click(object sender, EventArgs e)
        {
            mcon.Open();
            q = "select * from People_Info where Holding ='" + holdingnametxt.Text.Trim() + "'";
            mcd = new SqlCommand(q, mcon);
            SqlDataReader reader = mcd.ExecuteReader();

            if (reader.Read())
            {
                taxholdertxt.Text = reader["Name"].ToString();
                fathertxt.Text = reader["Father"].ToString();
                villegetxt.Text = reader["Villege"].ToString();
                weardtxtno.Text = reader["WardNo"].ToString();
                nidtxt.Text = reader["NidNo"].ToString();
                mobiletxt.Text = reader["MobileNo"].ToString();

                //MessageBox.Show("Yes Your Data Correct");


            }
            else
            {
                MessageBox.Show("Sorry Data Not Finded");
            }


            mcon.Close();
            reader.Close();


        }

        private void button93_Click(object sender, EventArgs e)
        {
            mcon.Open();
            q = "select * from People_Info where Holding ='" + holdingtax.Text.Trim() + "'";
            mcd = new SqlCommand(q, mcon);
            SqlDataReader reader = mcd.ExecuteReader();

            if (reader.Read())
            {
                txtname.Text = reader["Name"].ToString();
                fathertxth.Text = reader["Father"].ToString();
                txttvillege.Text = reader["Villege"].ToString();
                wordno.Text = reader["WardNo"].ToString();
                nidtxt.Text = reader["NidNo"].ToString();
                mobilenotxt.Text = reader["MobileNo"].ToString();


                //MessageBox.Show("Yes Your Data Correct");

            }
            else
            {
                MessageBox.Show("Sorry Data Not Finded");
            }


            mcon.Close();
            reader.Close();
        }

        private void button102_Click(object sender, EventArgs e)
        {
            mcon.Open();
            q = "select * from People_Info where Holding ='" + holdingtxtho.Text.Trim() + "'";
            mcd = new SqlCommand(q, mcon);
            SqlDataReader reader = mcd.ExecuteReader();

            if (reader.Read())
            {
                nameholdertax.Text = reader["Name"].ToString();
                fathertxtholder.Text = reader["Father"].ToString();
                villegehtxt.Text = reader["Villege"].ToString();
                wardnotxt.Text = reader["WardNo"].ToString();
                nidholdertxt.Text = reader["NidNo"].ToString();
                mobiletxtdolf.Text = reader["MobileNo"].ToString();

                //MessageBox.Show("Yes Your Data Correct");


            }
               
        else
            {
                MessageBox.Show("Sorry Data Not Finded");
            }


            mcon.Close();
            reader.Close();
        }
    }
  }
