﻿namespace Tax_Database
{
    partial class Form8
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.button14 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.fixtaxtxt = new System.Windows.Forms.TextBox();
            this.pojytxt = new System.Windows.Forms.TextBox();
            this.tradenametxt = new System.Windows.Forms.TextBox();
            this.tradetypetxt = new System.Windows.Forms.ComboBox();
            this.upjelatxt = new System.Windows.Forms.TextBox();
            this.posttxt = new System.Windows.Forms.TextBox();
            this.villegetxt = new System.Windows.Forms.TextBox();
            this.fathertxt = new System.Windows.Forms.TextBox();
            this.Nametxt = new System.Windows.Forms.TextBox();
            this.liecenceNotxt = new System.Windows.Forms.TextBox();
            this.button10 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.button30 = new System.Windows.Forms.Button();
            this.button29 = new System.Windows.Forms.Button();
            this.button28 = new System.Windows.Forms.Button();
            this.button27 = new System.Windows.Forms.Button();
            this.collecttxtdate = new System.Windows.Forms.DateTimePicker();
            this.tadenametxt = new System.Windows.Forms.ComboBox();
            this.typetxttrade = new System.Windows.Forms.ComboBox();
            this.moneyamounttxt = new System.Windows.Forms.TextBox();
            this.financialtxt = new System.Windows.Forms.TextBox();
            this.fixctaxtxtt = new System.Windows.Forms.TextBox();
            this.subdistxt = new System.Windows.Forms.TextBox();
            this.posttxtr = new System.Windows.Forms.TextBox();
            this.villegetxtr = new System.Windows.Forms.TextBox();
            this.fathertxtt = new System.Windows.Forms.TextBox();
            this.txtnametxt = new System.Windows.Forms.TextBox();
            this.leincenotxt = new System.Windows.Forms.TextBox();
            this.button26 = new System.Windows.Forms.Button();
            this.button25 = new System.Windows.Forms.Button();
            this.button24 = new System.Windows.Forms.Button();
            this.button23 = new System.Windows.Forms.Button();
            this.button22 = new System.Windows.Forms.Button();
            this.button21 = new System.Windows.Forms.Button();
            this.button20 = new System.Windows.Forms.Button();
            this.button19 = new System.Windows.Forms.Button();
            this.button18 = new System.Windows.Forms.Button();
            this.button17 = new System.Windows.Forms.Button();
            this.button16 = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.button50 = new System.Windows.Forms.Button();
            this.button49 = new System.Windows.Forms.Button();
            this.button48 = new System.Windows.Forms.Button();
            this.button47 = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.fathattxt = new System.Windows.Forms.TextBox();
            this.button46 = new System.Windows.Forms.Button();
            this.txtinwardtxt = new System.Windows.Forms.TextBox();
            this.tadenametxtlien = new System.Windows.Forms.ComboBox();
            this.button31 = new System.Windows.Forms.Button();
            this.liencetxt = new System.Windows.Forms.TextBox();
            this.registationdatetxt = new System.Windows.Forms.DateTimePicker();
            this.button32 = new System.Windows.Forms.Button();
            this.tradenametxtl = new System.Windows.Forms.TextBox();
            this.propaitortxt = new System.Windows.Forms.TextBox();
            this.button34 = new System.Windows.Forms.Button();
            this.locationtxt = new System.Windows.Forms.TextBox();
            this.posttxtb = new System.Windows.Forms.TextBox();
            this.button33 = new System.Windows.Forms.Button();
            this.tradernametxt = new System.Windows.Forms.TextBox();
            this.postmantxt = new System.Windows.Forms.TextBox();
            this.button36 = new System.Windows.Forms.Button();
            this.upojelatxtman = new System.Windows.Forms.TextBox();
            this.jelatxctxman = new System.Windows.Forms.TextBox();
            this.button35 = new System.Windows.Forms.Button();
            this.button38 = new System.Windows.Forms.Button();
            this.businesstypetxt = new System.Windows.Forms.ComboBox();
            this.validitytxt = new System.Windows.Forms.DateTimePicker();
            this.button45 = new System.Windows.Forms.Button();
            this.amounttakatxt = new System.Windows.Forms.TextBox();
            this.button37 = new System.Windows.Forms.Button();
            this.button43 = new System.Windows.Forms.Button();
            this.button44 = new System.Windows.Forms.Button();
            this.button40 = new System.Windows.Forms.Button();
            this.button39 = new System.Windows.Forms.Button();
            this.button41 = new System.Windows.Forms.Button();
            this.button42 = new System.Windows.Forms.Button();
            this.tabControl1.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControl1.Location = new System.Drawing.Point(-3, -2);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1073, 460);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.tabPage3.Controls.Add(this.button14);
            this.tabPage3.Controls.Add(this.button13);
            this.tabPage3.Controls.Add(this.button12);
            this.tabPage3.Controls.Add(this.button11);
            this.tabPage3.Controls.Add(this.fixtaxtxt);
            this.tabPage3.Controls.Add(this.pojytxt);
            this.tabPage3.Controls.Add(this.tradenametxt);
            this.tabPage3.Controls.Add(this.tradetypetxt);
            this.tabPage3.Controls.Add(this.upjelatxt);
            this.tabPage3.Controls.Add(this.posttxt);
            this.tabPage3.Controls.Add(this.villegetxt);
            this.tabPage3.Controls.Add(this.fathertxt);
            this.tabPage3.Controls.Add(this.Nametxt);
            this.tabPage3.Controls.Add(this.liecenceNotxt);
            this.tabPage3.Controls.Add(this.button10);
            this.tabPage3.Controls.Add(this.button7);
            this.tabPage3.Controls.Add(this.button8);
            this.tabPage3.Controls.Add(this.button9);
            this.tabPage3.Controls.Add(this.button4);
            this.tabPage3.Controls.Add(this.button5);
            this.tabPage3.Controls.Add(this.button6);
            this.tabPage3.Controls.Add(this.button3);
            this.tabPage3.Controls.Add(this.button2);
            this.tabPage3.Controls.Add(this.button1);
            this.tabPage3.Controls.Add(this.panel1);
            this.tabPage3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabPage3.Location = new System.Drawing.Point(4, 40);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(1065, 416);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "ননহোল্ডিং এসেসমেন্ট";
            // 
            // button14
            // 
            this.button14.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button14.Location = new System.Drawing.Point(590, 338);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(150, 40);
            this.button14.TabIndex = 23;
            this.button14.Text = "Search";
            this.button14.UseVisualStyleBackColor = true;
            this.button14.Click += new System.EventHandler(this.button14_Click);
            // 
            // button13
            // 
            this.button13.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button13.Location = new System.Drawing.Point(418, 338);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(150, 40);
            this.button13.TabIndex = 22;
            this.button13.Text = "Delete";
            this.button13.UseVisualStyleBackColor = true;
            this.button13.Click += new System.EventHandler(this.button13_Click);
            // 
            // button12
            // 
            this.button12.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button12.Location = new System.Drawing.Point(250, 338);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(150, 40);
            this.button12.TabIndex = 21;
            this.button12.Text = "Update";
            this.button12.UseVisualStyleBackColor = true;
            this.button12.Click += new System.EventHandler(this.button12_Click);
            // 
            // button11
            // 
            this.button11.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button11.Location = new System.Drawing.Point(75, 338);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(150, 40);
            this.button11.TabIndex = 20;
            this.button11.Text = "Submit";
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // fixtaxtxt
            // 
            this.fixtaxtxt.Font = new System.Drawing.Font("SutonnyMJ", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fixtaxtxt.Location = new System.Drawing.Point(156, 239);
            this.fixtaxtxt.Multiline = true;
            this.fixtaxtxt.Name = "fixtaxtxt";
            this.fixtaxtxt.Size = new System.Drawing.Size(233, 32);
            this.fixtaxtxt.TabIndex = 19;
            // 
            // pojytxt
            // 
            this.pojytxt.Font = new System.Drawing.Font("SutonnyMJ", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pojytxt.Location = new System.Drawing.Point(873, 176);
            this.pojytxt.Multiline = true;
            this.pojytxt.Name = "pojytxt";
            this.pojytxt.Size = new System.Drawing.Size(102, 32);
            this.pojytxt.TabIndex = 18;
            // 
            // tradenametxt
            // 
            this.tradenametxt.Font = new System.Drawing.Font("SutonnyMJ", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tradenametxt.Location = new System.Drawing.Point(525, 176);
            this.tradenametxt.Multiline = true;
            this.tradenametxt.Name = "tradenametxt";
            this.tradenametxt.Size = new System.Drawing.Size(218, 32);
            this.tradenametxt.TabIndex = 17;
            // 
            // tradetypetxt
            // 
            this.tradetypetxt.Font = new System.Drawing.Font("SutonnyMJ", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tradetypetxt.FormattingEnabled = true;
            this.tradetypetxt.Location = new System.Drawing.Point(157, 176);
            this.tradetypetxt.Name = "tradetypetxt";
            this.tradetypetxt.Size = new System.Drawing.Size(232, 30);
            this.tradetypetxt.TabIndex = 16;
            // 
            // upjelatxt
            // 
            this.upjelatxt.Font = new System.Drawing.Font("SutonnyMJ", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.upjelatxt.Location = new System.Drawing.Point(836, 116);
            this.upjelatxt.Multiline = true;
            this.upjelatxt.Name = "upjelatxt";
            this.upjelatxt.Size = new System.Drawing.Size(139, 32);
            this.upjelatxt.TabIndex = 15;
            // 
            // posttxt
            // 
            this.posttxt.Font = new System.Drawing.Font("SutonnyMJ", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.posttxt.Location = new System.Drawing.Point(521, 116);
            this.posttxt.Multiline = true;
            this.posttxt.Name = "posttxt";
            this.posttxt.Size = new System.Drawing.Size(222, 32);
            this.posttxt.TabIndex = 14;
            // 
            // villegetxt
            // 
            this.villegetxt.Font = new System.Drawing.Font("SutonnyMJ", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.villegetxt.Location = new System.Drawing.Point(156, 116);
            this.villegetxt.Multiline = true;
            this.villegetxt.Name = "villegetxt";
            this.villegetxt.Size = new System.Drawing.Size(233, 32);
            this.villegetxt.TabIndex = 13;
            // 
            // fathertxt
            // 
            this.fathertxt.Font = new System.Drawing.Font("SutonnyMJ", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fathertxt.Location = new System.Drawing.Point(699, 54);
            this.fathertxt.Multiline = true;
            this.fathertxt.Name = "fathertxt";
            this.fathertxt.Size = new System.Drawing.Size(276, 32);
            this.fathertxt.TabIndex = 12;
            // 
            // Nametxt
            // 
            this.Nametxt.Font = new System.Drawing.Font("SutonnyMJ", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Nametxt.Location = new System.Drawing.Point(367, 54);
            this.Nametxt.Multiline = true;
            this.Nametxt.Name = "Nametxt";
            this.Nametxt.Size = new System.Drawing.Size(181, 32);
            this.Nametxt.TabIndex = 11;
            // 
            // liecenceNotxt
            // 
            this.liecenceNotxt.Font = new System.Drawing.Font("SutonnyMJ", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.liecenceNotxt.Location = new System.Drawing.Point(156, 54);
            this.liecenceNotxt.Multiline = true;
            this.liecenceNotxt.Name = "liecenceNotxt";
            this.liecenceNotxt.Size = new System.Drawing.Size(113, 32);
            this.liecenceNotxt.TabIndex = 10;
            // 
            // button10
            // 
            this.button10.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button10.Location = new System.Drawing.Point(31, 239);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(123, 32);
            this.button10.TabIndex = 9;
            this.button10.Text = "ধার্ষকৃত ট্যাক্স";
            this.button10.UseVisualStyleBackColor = true;
            // 
            // button7
            // 
            this.button7.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button7.Location = new System.Drawing.Point(749, 176);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(118, 32);
            this.button7.TabIndex = 8;
            this.button7.Text = "ব্যবসার মুলধন";
            this.button7.UseVisualStyleBackColor = true;
            // 
            // button8
            // 
            this.button8.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button8.Location = new System.Drawing.Point(396, 176);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(123, 32);
            this.button8.TabIndex = 7;
            this.button8.Text = "ব্যবসার নাম";
            this.button8.UseVisualStyleBackColor = true;
            // 
            // button9
            // 
            this.button9.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button9.Location = new System.Drawing.Point(31, 176);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(123, 32);
            this.button9.TabIndex = 6;
            this.button9.Text = "ব্যবসার ধরণ";
            this.button9.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            this.button4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.Location = new System.Drawing.Point(749, 116);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(81, 32);
            this.button4.TabIndex = 5;
            this.button4.Text = "উপজেলা";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // button5
            // 
            this.button5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.Location = new System.Drawing.Point(396, 116);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(123, 32);
            this.button5.TabIndex = 4;
            this.button5.Text = "পোষ্ট";
            this.button5.UseVisualStyleBackColor = true;
            // 
            // button6
            // 
            this.button6.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button6.Location = new System.Drawing.Point(31, 116);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(123, 32);
            this.button6.TabIndex = 3;
            this.button6.Text = "গ্রাম";
            this.button6.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Location = new System.Drawing.Point(554, 54);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(139, 32);
            this.button3.TabIndex = 2;
            this.button3.Text = "পিতা/স্বামী";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(275, 54);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(91, 32);
            this.button2.TabIndex = 1;
            this.button2.Text = "নাম";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(31, 54);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(123, 32);
            this.button1.TabIndex = 0;
            this.button1.Text = "লাইসেন্স নং";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.CadetBlue;
            this.panel1.Location = new System.Drawing.Point(17, 37);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(976, 260);
            this.panel1.TabIndex = 24;
            // 
            // tabPage4
            // 
            this.tabPage4.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.tabPage4.Controls.Add(this.button30);
            this.tabPage4.Controls.Add(this.button29);
            this.tabPage4.Controls.Add(this.button28);
            this.tabPage4.Controls.Add(this.button27);
            this.tabPage4.Controls.Add(this.collecttxtdate);
            this.tabPage4.Controls.Add(this.tadenametxt);
            this.tabPage4.Controls.Add(this.typetxttrade);
            this.tabPage4.Controls.Add(this.moneyamounttxt);
            this.tabPage4.Controls.Add(this.financialtxt);
            this.tabPage4.Controls.Add(this.fixctaxtxtt);
            this.tabPage4.Controls.Add(this.subdistxt);
            this.tabPage4.Controls.Add(this.posttxtr);
            this.tabPage4.Controls.Add(this.villegetxtr);
            this.tabPage4.Controls.Add(this.fathertxtt);
            this.tabPage4.Controls.Add(this.txtnametxt);
            this.tabPage4.Controls.Add(this.leincenotxt);
            this.tabPage4.Controls.Add(this.button26);
            this.tabPage4.Controls.Add(this.button25);
            this.tabPage4.Controls.Add(this.button24);
            this.tabPage4.Controls.Add(this.button23);
            this.tabPage4.Controls.Add(this.button22);
            this.tabPage4.Controls.Add(this.button21);
            this.tabPage4.Controls.Add(this.button20);
            this.tabPage4.Controls.Add(this.button19);
            this.tabPage4.Controls.Add(this.button18);
            this.tabPage4.Controls.Add(this.button17);
            this.tabPage4.Controls.Add(this.button16);
            this.tabPage4.Controls.Add(this.button15);
            this.tabPage4.Controls.Add(this.panel2);
            this.tabPage4.Location = new System.Drawing.Point(4, 40);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(1065, 416);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "ট্যাক্স রেজিষ্টার";
            // 
            // button30
            // 
            this.button30.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button30.Location = new System.Drawing.Point(665, 338);
            this.button30.Name = "button30";
            this.button30.Size = new System.Drawing.Size(127, 39);
            this.button30.TabIndex = 27;
            this.button30.Text = "Search";
            this.button30.UseVisualStyleBackColor = true;
            this.button30.Click += new System.EventHandler(this.button30_Click);
            // 
            // button29
            // 
            this.button29.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button29.Location = new System.Drawing.Point(512, 338);
            this.button29.Name = "button29";
            this.button29.Size = new System.Drawing.Size(127, 39);
            this.button29.TabIndex = 26;
            this.button29.Text = "Delete";
            this.button29.UseVisualStyleBackColor = true;
            this.button29.Click += new System.EventHandler(this.button29_Click);
            // 
            // button28
            // 
            this.button28.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button28.Location = new System.Drawing.Point(365, 338);
            this.button28.Name = "button28";
            this.button28.Size = new System.Drawing.Size(127, 39);
            this.button28.TabIndex = 25;
            this.button28.Text = "Update";
            this.button28.UseVisualStyleBackColor = true;
            this.button28.Click += new System.EventHandler(this.button28_Click);
            // 
            // button27
            // 
            this.button27.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button27.Location = new System.Drawing.Point(198, 338);
            this.button27.Name = "button27";
            this.button27.Size = new System.Drawing.Size(127, 39);
            this.button27.TabIndex = 24;
            this.button27.Text = "Submit";
            this.button27.UseVisualStyleBackColor = true;
            this.button27.Click += new System.EventHandler(this.button27_Click);
            // 
            // collecttxtdate
            // 
            this.collecttxtdate.CalendarFont = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.collecttxtdate.CustomFormat = "yyy-mm-dd";
            this.collecttxtdate.Font = new System.Drawing.Font("SutonnyMJ", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.collecttxtdate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.collecttxtdate.Location = new System.Drawing.Point(798, 80);
            this.collecttxtdate.Name = "collecttxtdate";
            this.collecttxtdate.Size = new System.Drawing.Size(130, 30);
            this.collecttxtdate.TabIndex = 23;
            // 
            // tadenametxt
            // 
            this.tadenametxt.Font = new System.Drawing.Font("SutonnyMJ", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tadenametxt.FormattingEnabled = true;
            this.tadenametxt.Location = new System.Drawing.Point(489, 235);
            this.tadenametxt.Name = "tadenametxt";
            this.tadenametxt.Size = new System.Drawing.Size(130, 30);
            this.tadenametxt.TabIndex = 22;
            // 
            // typetxttrade
            // 
            this.typetxttrade.Font = new System.Drawing.Font("SutonnyMJ", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.typetxttrade.FormattingEnabled = true;
            this.typetxttrade.Location = new System.Drawing.Point(489, 181);
            this.typetxttrade.Name = "typetxttrade";
            this.typetxttrade.Size = new System.Drawing.Size(130, 30);
            this.typetxttrade.TabIndex = 21;
            // 
            // moneyamounttxt
            // 
            this.moneyamounttxt.Font = new System.Drawing.Font("SutonnyMJ", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.moneyamounttxt.Location = new System.Drawing.Point(798, 239);
            this.moneyamounttxt.Name = "moneyamounttxt";
            this.moneyamounttxt.Size = new System.Drawing.Size(130, 30);
            this.moneyamounttxt.TabIndex = 20;
            // 
            // financialtxt
            // 
            this.financialtxt.Font = new System.Drawing.Font("SutonnyMJ", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.financialtxt.Location = new System.Drawing.Point(798, 185);
            this.financialtxt.Name = "financialtxt";
            this.financialtxt.Size = new System.Drawing.Size(130, 30);
            this.financialtxt.TabIndex = 19;
            // 
            // fixctaxtxtt
            // 
            this.fixctaxtxtt.Font = new System.Drawing.Font("SutonnyMJ", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fixctaxtxtt.Location = new System.Drawing.Point(798, 135);
            this.fixctaxtxtt.Name = "fixctaxtxtt";
            this.fixctaxtxtt.Size = new System.Drawing.Size(130, 30);
            this.fixctaxtxtt.TabIndex = 18;
            // 
            // subdistxt
            // 
            this.subdistxt.Font = new System.Drawing.Font("SutonnyMJ", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.subdistxt.Location = new System.Drawing.Point(489, 128);
            this.subdistxt.Name = "subdistxt";
            this.subdistxt.Size = new System.Drawing.Size(130, 30);
            this.subdistxt.TabIndex = 17;
            // 
            // posttxtr
            // 
            this.posttxtr.Font = new System.Drawing.Font("SutonnyMJ", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.posttxtr.Location = new System.Drawing.Point(489, 80);
            this.posttxtr.Name = "posttxtr";
            this.posttxtr.Size = new System.Drawing.Size(130, 30);
            this.posttxtr.TabIndex = 16;
            // 
            // villegetxtr
            // 
            this.villegetxtr.Font = new System.Drawing.Font("SutonnyMJ", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.villegetxtr.Location = new System.Drawing.Point(218, 241);
            this.villegetxtr.Name = "villegetxtr";
            this.villegetxtr.Size = new System.Drawing.Size(130, 30);
            this.villegetxtr.TabIndex = 15;
            // 
            // fathertxtt
            // 
            this.fathertxtt.Font = new System.Drawing.Font("SutonnyMJ", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fathertxtt.Location = new System.Drawing.Point(218, 181);
            this.fathertxtt.Name = "fathertxtt";
            this.fathertxtt.Size = new System.Drawing.Size(130, 30);
            this.fathertxtt.TabIndex = 14;
            // 
            // txtnametxt
            // 
            this.txtnametxt.Font = new System.Drawing.Font("SutonnyMJ", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtnametxt.Location = new System.Drawing.Point(218, 128);
            this.txtnametxt.Name = "txtnametxt";
            this.txtnametxt.Size = new System.Drawing.Size(130, 30);
            this.txtnametxt.TabIndex = 13;
            // 
            // leincenotxt
            // 
            this.leincenotxt.Font = new System.Drawing.Font("SutonnyMJ", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.leincenotxt.Location = new System.Drawing.Point(218, 80);
            this.leincenotxt.Name = "leincenotxt";
            this.leincenotxt.Size = new System.Drawing.Size(130, 30);
            this.leincenotxt.TabIndex = 12;
            // 
            // button26
            // 
            this.button26.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button26.Location = new System.Drawing.Point(663, 236);
            this.button26.Name = "button26";
            this.button26.Size = new System.Drawing.Size(129, 31);
            this.button26.TabIndex = 11;
            this.button26.Text = "টাকার পরিমান";
            this.button26.UseVisualStyleBackColor = true;
            // 
            // button25
            // 
            this.button25.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button25.Location = new System.Drawing.Point(663, 183);
            this.button25.Name = "button25";
            this.button25.Size = new System.Drawing.Size(129, 31);
            this.button25.TabIndex = 10;
            this.button25.Text = "অর্থবছর";
            this.button25.UseVisualStyleBackColor = true;
            // 
            // button24
            // 
            this.button24.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button24.Location = new System.Drawing.Point(663, 133);
            this.button24.Name = "button24";
            this.button24.Size = new System.Drawing.Size(129, 31);
            this.button24.TabIndex = 9;
            this.button24.Text = "ধার্ষকৃত ট্যাক্স";
            this.button24.UseVisualStyleBackColor = true;
            // 
            // button23
            // 
            this.button23.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button23.Location = new System.Drawing.Point(663, 78);
            this.button23.Name = "button23";
            this.button23.Size = new System.Drawing.Size(129, 31);
            this.button23.TabIndex = 8;
            this.button23.Text = "আদায় তারিখ";
            this.button23.UseVisualStyleBackColor = true;
            // 
            // button22
            // 
            this.button22.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button22.Location = new System.Drawing.Point(354, 239);
            this.button22.Name = "button22";
            this.button22.Size = new System.Drawing.Size(129, 31);
            this.button22.TabIndex = 7;
            this.button22.Text = "ব্যবসার নাম";
            this.button22.UseVisualStyleBackColor = true;
            // 
            // button21
            // 
            this.button21.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button21.Location = new System.Drawing.Point(354, 181);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(129, 31);
            this.button21.TabIndex = 6;
            this.button21.Text = "ব্যবসার ধরণ";
            this.button21.UseVisualStyleBackColor = true;
            // 
            // button20
            // 
            this.button20.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button20.Location = new System.Drawing.Point(354, 128);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(129, 31);
            this.button20.TabIndex = 5;
            this.button20.Text = "উপজেলা";
            this.button20.UseVisualStyleBackColor = true;
            // 
            // button19
            // 
            this.button19.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button19.Location = new System.Drawing.Point(354, 78);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(129, 31);
            this.button19.TabIndex = 4;
            this.button19.Text = "ডাকঘর";
            this.button19.UseVisualStyleBackColor = true;
            // 
            // button18
            // 
            this.button18.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button18.Location = new System.Drawing.Point(83, 239);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(129, 31);
            this.button18.TabIndex = 3;
            this.button18.Text = "গ্রাম";
            this.button18.UseVisualStyleBackColor = true;
            // 
            // button17
            // 
            this.button17.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button17.Location = new System.Drawing.Point(83, 181);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(129, 31);
            this.button17.TabIndex = 2;
            this.button17.Text = "পিতা/স্বামী";
            this.button17.UseVisualStyleBackColor = true;
            // 
            // button16
            // 
            this.button16.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button16.Location = new System.Drawing.Point(83, 128);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(129, 31);
            this.button16.TabIndex = 1;
            this.button16.Text = "নাম";
            this.button16.UseVisualStyleBackColor = true;
            // 
            // button15
            // 
            this.button15.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button15.Location = new System.Drawing.Point(83, 78);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(129, 31);
            this.button15.TabIndex = 0;
            this.button15.Text = "লাইসেন্স নং";
            this.button15.UseVisualStyleBackColor = true;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.WindowText;
            this.panel2.Location = new System.Drawing.Point(57, 64);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(921, 225);
            this.panel2.TabIndex = 28;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.tabPage1.Controls.Add(this.button50);
            this.tabPage1.Controls.Add(this.button49);
            this.tabPage1.Controls.Add(this.button48);
            this.tabPage1.Controls.Add(this.button47);
            this.tabPage1.Controls.Add(this.panel3);
            this.tabPage1.Location = new System.Drawing.Point(4, 40);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1065, 416);
            this.tabPage1.TabIndex = 4;
            this.tabPage1.Text = "ট্রেড লাইসেন্স";
            // 
            // button50
            // 
            this.button50.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button50.Location = new System.Drawing.Point(587, 361);
            this.button50.Name = "button50";
            this.button50.Size = new System.Drawing.Size(118, 38);
            this.button50.TabIndex = 35;
            this.button50.Text = "Search";
            this.button50.UseVisualStyleBackColor = true;
            this.button50.Click += new System.EventHandler(this.button50_Click);
            // 
            // button49
            // 
            this.button49.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button49.Location = new System.Drawing.Point(444, 361);
            this.button49.Name = "button49";
            this.button49.Size = new System.Drawing.Size(118, 38);
            this.button49.TabIndex = 34;
            this.button49.Text = "Delete";
            this.button49.UseVisualStyleBackColor = true;
            this.button49.Click += new System.EventHandler(this.button49_Click);
            // 
            // button48
            // 
            this.button48.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button48.Location = new System.Drawing.Point(309, 361);
            this.button48.Name = "button48";
            this.button48.Size = new System.Drawing.Size(118, 38);
            this.button48.TabIndex = 33;
            this.button48.Text = "Update";
            this.button48.UseVisualStyleBackColor = true;
            this.button48.Click += new System.EventHandler(this.button48_Click);
            // 
            // button47
            // 
            this.button47.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button47.Location = new System.Drawing.Point(169, 361);
            this.button47.Name = "button47";
            this.button47.Size = new System.Drawing.Size(118, 38);
            this.button47.TabIndex = 32;
            this.button47.Text = "Submit";
            this.button47.UseVisualStyleBackColor = true;
            this.button47.Click += new System.EventHandler(this.button47_Click);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.SlateGray;
            this.panel3.Controls.Add(this.fathattxt);
            this.panel3.Controls.Add(this.button46);
            this.panel3.Controls.Add(this.txtinwardtxt);
            this.panel3.Controls.Add(this.tadenametxtlien);
            this.panel3.Controls.Add(this.button31);
            this.panel3.Controls.Add(this.liencetxt);
            this.panel3.Controls.Add(this.registationdatetxt);
            this.panel3.Controls.Add(this.button32);
            this.panel3.Controls.Add(this.tradenametxtl);
            this.panel3.Controls.Add(this.propaitortxt);
            this.panel3.Controls.Add(this.button34);
            this.panel3.Controls.Add(this.locationtxt);
            this.panel3.Controls.Add(this.posttxtb);
            this.panel3.Controls.Add(this.button33);
            this.panel3.Controls.Add(this.tradernametxt);
            this.panel3.Controls.Add(this.postmantxt);
            this.panel3.Controls.Add(this.button36);
            this.panel3.Controls.Add(this.upojelatxtman);
            this.panel3.Controls.Add(this.jelatxctxman);
            this.panel3.Controls.Add(this.button35);
            this.panel3.Controls.Add(this.button38);
            this.panel3.Controls.Add(this.businesstypetxt);
            this.panel3.Controls.Add(this.validitytxt);
            this.panel3.Controls.Add(this.button45);
            this.panel3.Controls.Add(this.amounttakatxt);
            this.panel3.Controls.Add(this.button37);
            this.panel3.Controls.Add(this.button43);
            this.panel3.Controls.Add(this.button44);
            this.panel3.Controls.Add(this.button40);
            this.panel3.Controls.Add(this.button39);
            this.panel3.Controls.Add(this.button41);
            this.panel3.Controls.Add(this.button42);
            this.panel3.Location = new System.Drawing.Point(11, 2);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1077, 318);
            this.panel3.TabIndex = 36;
            // 
            // fathattxt
            // 
            this.fathattxt.Font = new System.Drawing.Font("SutonnyMJ", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fathattxt.Location = new System.Drawing.Point(137, 112);
            this.fathattxt.Multiline = true;
            this.fathattxt.Name = "fathattxt";
            this.fathattxt.Size = new System.Drawing.Size(267, 32);
            this.fathattxt.TabIndex = 20;
            // 
            // button46
            // 
            this.button46.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button46.Location = new System.Drawing.Point(13, 271);
            this.button46.Name = "button46";
            this.button46.Size = new System.Drawing.Size(139, 32);
            this.button46.TabIndex = 14;
            this.button46.Text = "কথায়";
            this.button46.UseVisualStyleBackColor = true;
            // 
            // txtinwardtxt
            // 
            this.txtinwardtxt.Font = new System.Drawing.Font("SutonnyMJ", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtinwardtxt.Location = new System.Drawing.Point(157, 271);
            this.txtinwardtxt.Multiline = true;
            this.txtinwardtxt.Name = "txtinwardtxt";
            this.txtinwardtxt.Size = new System.Drawing.Size(296, 32);
            this.txtinwardtxt.TabIndex = 30;
            // 
            // tadenametxtlien
            // 
            this.tadenametxtlien.Font = new System.Drawing.Font("SutonnyMJ", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tadenametxtlien.FormattingEnabled = true;
            this.tadenametxtlien.Location = new System.Drawing.Point(606, 268);
            this.tadenametxtlien.Name = "tadenametxtlien";
            this.tadenametxtlien.Size = new System.Drawing.Size(172, 30);
            this.tadenametxtlien.TabIndex = 31;
            this.tadenametxtlien.SelectedIndexChanged += new System.EventHandler(this.tadenametxtlien_SelectedIndexChanged);
            // 
            // button31
            // 
            this.button31.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button31.Location = new System.Drawing.Point(13, 22);
            this.button31.Name = "button31";
            this.button31.Size = new System.Drawing.Size(140, 32);
            this.button31.TabIndex = 0;
            this.button31.Text = "লাইসেন্স নং";
            this.button31.UseVisualStyleBackColor = true;
            // 
            // liencetxt
            // 
            this.liencetxt.Font = new System.Drawing.Font("SutonnyMJ", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.liencetxt.Location = new System.Drawing.Point(159, 22);
            this.liencetxt.Multiline = true;
            this.liencetxt.Name = "liencetxt";
            this.liencetxt.Size = new System.Drawing.Size(195, 30);
            this.liencetxt.TabIndex = 16;
            // 
            // registationdatetxt
            // 
            this.registationdatetxt.CustomFormat = "";
            this.registationdatetxt.Font = new System.Drawing.Font("SutonnyMJ", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.registationdatetxt.Location = new System.Drawing.Point(889, 22);
            this.registationdatetxt.Name = "registationdatetxt";
            this.registationdatetxt.Size = new System.Drawing.Size(159, 30);
            this.registationdatetxt.TabIndex = 17;
            // 
            // button32
            // 
            this.button32.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button32.Location = new System.Drawing.Point(747, 22);
            this.button32.Name = "button32";
            this.button32.Size = new System.Drawing.Size(136, 32);
            this.button32.TabIndex = 1;
            this.button32.Text = "রেজিষ্টেশন তারিখ";
            this.button32.UseVisualStyleBackColor = true;
            // 
            // tradenametxtl
            // 
            this.tradenametxtl.Font = new System.Drawing.Font("SutonnyMJ", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tradenametxtl.Location = new System.Drawing.Point(185, 70);
            this.tradenametxtl.Multiline = true;
            this.tradenametxtl.Name = "tradenametxtl";
            this.tradenametxtl.Size = new System.Drawing.Size(231, 32);
            this.tradenametxtl.TabIndex = 18;
            // 
            // propaitortxt
            // 
            this.propaitortxt.Font = new System.Drawing.Font("SutonnyMJ", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.propaitortxt.Location = new System.Drawing.Point(576, 67);
            this.propaitortxt.Multiline = true;
            this.propaitortxt.Name = "propaitortxt";
            this.propaitortxt.Size = new System.Drawing.Size(471, 35);
            this.propaitortxt.TabIndex = 19;
            // 
            // button34
            // 
            this.button34.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button34.Location = new System.Drawing.Point(12, 70);
            this.button34.Name = "button34";
            this.button34.Size = new System.Drawing.Size(167, 32);
            this.button34.TabIndex = 2;
            this.button34.Text = "ট্রেড লাইসেন্স এর নাম";
            this.button34.UseVisualStyleBackColor = true;
            // 
            // locationtxt
            // 
            this.locationtxt.Font = new System.Drawing.Font("SutonnyMJ", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.locationtxt.Location = new System.Drawing.Point(558, 115);
            this.locationtxt.Multiline = true;
            this.locationtxt.Name = "locationtxt";
            this.locationtxt.Size = new System.Drawing.Size(171, 32);
            this.locationtxt.TabIndex = 21;
            // 
            // posttxtb
            // 
            this.posttxtb.Font = new System.Drawing.Font("SutonnyMJ", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.posttxtb.Location = new System.Drawing.Point(877, 115);
            this.posttxtb.Multiline = true;
            this.posttxtb.Name = "posttxtb";
            this.posttxtb.Size = new System.Drawing.Size(170, 32);
            this.posttxtb.TabIndex = 22;
            // 
            // button33
            // 
            this.button33.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button33.Location = new System.Drawing.Point(422, 67);
            this.button33.Name = "button33";
            this.button33.Size = new System.Drawing.Size(141, 35);
            this.button33.TabIndex = 3;
            this.button33.Text = "প্রপাইটর এর নাম";
            this.button33.UseVisualStyleBackColor = true;
            // 
            // tradernametxt
            // 
            this.tradernametxt.Font = new System.Drawing.Font("SutonnyMJ", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tradernametxt.Location = new System.Drawing.Point(159, 167);
            this.tradernametxt.Multiline = true;
            this.tradernametxt.Name = "tradernametxt";
            this.tradernametxt.Size = new System.Drawing.Size(171, 32);
            this.tradernametxt.TabIndex = 23;
            // 
            // postmantxt
            // 
            this.postmantxt.Font = new System.Drawing.Font("SutonnyMJ", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.postmantxt.Location = new System.Drawing.Point(509, 167);
            this.postmantxt.Multiline = true;
            this.postmantxt.Name = "postmantxt";
            this.postmantxt.Size = new System.Drawing.Size(173, 32);
            this.postmantxt.TabIndex = 24;
            // 
            // button36
            // 
            this.button36.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button36.Location = new System.Drawing.Point(13, 115);
            this.button36.Name = "button36";
            this.button36.Size = new System.Drawing.Size(108, 32);
            this.button36.TabIndex = 4;
            this.button36.Text = "পিতা/স্বামী";
            this.button36.UseVisualStyleBackColor = true;
            // 
            // upojelatxtman
            // 
            this.upojelatxtman.Font = new System.Drawing.Font("SutonnyMJ", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.upojelatxtman.Location = new System.Drawing.Point(817, 167);
            this.upojelatxtman.Multiline = true;
            this.upojelatxtman.Name = "upojelatxtman";
            this.upojelatxtman.Size = new System.Drawing.Size(230, 32);
            this.upojelatxtman.TabIndex = 25;
            // 
            // jelatxctxman
            // 
            this.jelatxctxman.Font = new System.Drawing.Font("SutonnyMJ", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.jelatxctxman.Location = new System.Drawing.Point(528, 22);
            this.jelatxctxman.Multiline = true;
            this.jelatxctxman.Name = "jelatxctxman";
            this.jelatxctxman.Size = new System.Drawing.Size(213, 32);
            this.jelatxctxman.TabIndex = 26;
            // 
            // button35
            // 
            this.button35.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button35.Location = new System.Drawing.Point(410, 112);
            this.button35.Name = "button35";
            this.button35.Size = new System.Drawing.Size(141, 32);
            this.button35.TabIndex = 5;
            this.button35.Text = "ব্যবসার গ্রাম ";
            this.button35.UseVisualStyleBackColor = true;
            // 
            // button38
            // 
            this.button38.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button38.Location = new System.Drawing.Point(730, 115);
            this.button38.Name = "button38";
            this.button38.Size = new System.Drawing.Size(141, 32);
            this.button38.TabIndex = 6;
            this.button38.Text = "ব্যবসা এর পোষ্ট";
            this.button38.UseVisualStyleBackColor = true;
            // 
            // businesstypetxt
            // 
            this.businesstypetxt.Font = new System.Drawing.Font("SutonnyMJ", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.businesstypetxt.FormattingEnabled = true;
            this.businesstypetxt.Location = new System.Drawing.Point(157, 227);
            this.businesstypetxt.Name = "businesstypetxt";
            this.businesstypetxt.Size = new System.Drawing.Size(173, 30);
            this.businesstypetxt.TabIndex = 28;
            // 
            // validitytxt
            // 
            this.validitytxt.CustomFormat = "";
            this.validitytxt.Font = new System.Drawing.Font("SutonnyMJ", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.validitytxt.Location = new System.Drawing.Point(487, 224);
            this.validitytxt.Name = "validitytxt";
            this.validitytxt.Size = new System.Drawing.Size(173, 30);
            this.validitytxt.TabIndex = 29;
            // 
            // button45
            // 
            this.button45.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button45.Location = new System.Drawing.Point(459, 268);
            this.button45.Name = "button45";
            this.button45.Size = new System.Drawing.Size(141, 35);
            this.button45.TabIndex = 15;
            this.button45.Text = "ব্যবসার নাম";
            this.button45.UseVisualStyleBackColor = true;
            // 
            // amounttakatxt
            // 
            this.amounttakatxt.Font = new System.Drawing.Font("SutonnyMJ", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.amounttakatxt.Location = new System.Drawing.Point(817, 222);
            this.amounttakatxt.Multiline = true;
            this.amounttakatxt.Name = "amounttakatxt";
            this.amounttakatxt.Size = new System.Drawing.Size(234, 32);
            this.amounttakatxt.TabIndex = 27;
            // 
            // button37
            // 
            this.button37.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button37.Location = new System.Drawing.Point(12, 167);
            this.button37.Name = "button37";
            this.button37.Size = new System.Drawing.Size(141, 32);
            this.button37.TabIndex = 7;
            this.button37.Text = "লাইসেন্স ধারির গ্রাম";
            this.button37.UseVisualStyleBackColor = true;
            // 
            // button43
            // 
            this.button43.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button43.Location = new System.Drawing.Point(666, 222);
            this.button43.Name = "button43";
            this.button43.Size = new System.Drawing.Size(141, 32);
            this.button43.TabIndex = 13;
            this.button43.Text = "টাকার পরিমান";
            this.button43.UseVisualStyleBackColor = true;
            // 
            // button44
            // 
            this.button44.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button44.Location = new System.Drawing.Point(336, 224);
            this.button44.Name = "button44";
            this.button44.Size = new System.Drawing.Size(140, 32);
            this.button44.TabIndex = 12;
            this.button44.Text = "মেয়াদ";
            this.button44.UseVisualStyleBackColor = true;
            // 
            // button40
            // 
            this.button40.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button40.Location = new System.Drawing.Point(365, 167);
            this.button40.Name = "button40";
            this.button40.Size = new System.Drawing.Size(138, 32);
            this.button40.TabIndex = 8;
            this.button40.Text = "পোষ্ট";
            this.button40.UseVisualStyleBackColor = true;
            // 
            // button39
            // 
            this.button39.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button39.Location = new System.Drawing.Point(688, 167);
            this.button39.Name = "button39";
            this.button39.Size = new System.Drawing.Size(119, 32);
            this.button39.TabIndex = 9;
            this.button39.Text = "উপজেলা";
            this.button39.UseVisualStyleBackColor = true;
            // 
            // button41
            // 
            this.button41.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button41.Location = new System.Drawing.Point(13, 224);
            this.button41.Name = "button41";
            this.button41.Size = new System.Drawing.Size(139, 32);
            this.button41.TabIndex = 11;
            this.button41.Text = "ব্যবসার ধরণ ";
            this.button41.UseVisualStyleBackColor = true;
            // 
            // button42
            // 
            this.button42.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button42.Location = new System.Drawing.Point(360, 22);
            this.button42.Name = "button42";
            this.button42.Size = new System.Drawing.Size(162, 32);
            this.button42.TabIndex = 10;
            this.button42.Text = "অর্থবছর";
            this.button42.UseVisualStyleBackColor = true;
            // 
            // Form8
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(1071, 449);
            this.Controls.Add(this.tabControl1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "Form8";
            this.Text = "গোমস্তাপুর ইউনিয়ন পরিষদ";
            this.tabControl1.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            this.tabPage1.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.TextBox fixtaxtxt;
        private System.Windows.Forms.TextBox pojytxt;
        private System.Windows.Forms.TextBox tradenametxt;
        private System.Windows.Forms.ComboBox tradetypetxt;
        private System.Windows.Forms.TextBox upjelatxt;
        private System.Windows.Forms.TextBox posttxt;
        private System.Windows.Forms.TextBox villegetxt;
        private System.Windows.Forms.TextBox fathertxt;
        private System.Windows.Forms.TextBox Nametxt;
        private System.Windows.Forms.TextBox liecenceNotxt;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button button30;
        private System.Windows.Forms.Button button29;
        private System.Windows.Forms.Button button28;
        private System.Windows.Forms.Button button27;
        private System.Windows.Forms.DateTimePicker collecttxtdate;
        private System.Windows.Forms.ComboBox tadenametxt;
        private System.Windows.Forms.ComboBox typetxttrade;
        private System.Windows.Forms.TextBox moneyamounttxt;
        private System.Windows.Forms.TextBox financialtxt;
        private System.Windows.Forms.TextBox fixctaxtxtt;
        private System.Windows.Forms.TextBox subdistxt;
        private System.Windows.Forms.TextBox posttxtr;
        private System.Windows.Forms.TextBox villegetxtr;
        private System.Windows.Forms.TextBox fathertxtt;
        private System.Windows.Forms.TextBox txtnametxt;
        private System.Windows.Forms.TextBox leincenotxt;
        private System.Windows.Forms.Button button26;
        private System.Windows.Forms.Button button25;
        private System.Windows.Forms.Button button24;
        private System.Windows.Forms.Button button23;
        private System.Windows.Forms.Button button22;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button button50;
        private System.Windows.Forms.Button button49;
        private System.Windows.Forms.Button button48;
        private System.Windows.Forms.Button button47;
        private System.Windows.Forms.ComboBox tadenametxtlien;
        private System.Windows.Forms.TextBox txtinwardtxt;
        private System.Windows.Forms.DateTimePicker validitytxt;
        private System.Windows.Forms.ComboBox businesstypetxt;
        private System.Windows.Forms.TextBox amounttakatxt;
        private System.Windows.Forms.TextBox jelatxctxman;
        private System.Windows.Forms.TextBox upojelatxtman;
        private System.Windows.Forms.TextBox postmantxt;
        private System.Windows.Forms.TextBox tradernametxt;
        private System.Windows.Forms.TextBox posttxtb;
        private System.Windows.Forms.TextBox locationtxt;
        private System.Windows.Forms.TextBox fathattxt;
        private System.Windows.Forms.TextBox propaitortxt;
        private System.Windows.Forms.TextBox tradenametxtl;
        private System.Windows.Forms.DateTimePicker registationdatetxt;
        private System.Windows.Forms.TextBox liencetxt;
        private System.Windows.Forms.Button button45;
        private System.Windows.Forms.Button button46;
        private System.Windows.Forms.Button button43;
        private System.Windows.Forms.Button button44;
        private System.Windows.Forms.Button button41;
        private System.Windows.Forms.Button button42;
        private System.Windows.Forms.Button button39;
        private System.Windows.Forms.Button button40;
        private System.Windows.Forms.Button button37;
        private System.Windows.Forms.Button button38;
        private System.Windows.Forms.Button button35;
        private System.Windows.Forms.Button button36;
        private System.Windows.Forms.Button button33;
        private System.Windows.Forms.Button button34;
        private System.Windows.Forms.Button button32;
        private System.Windows.Forms.Button button31;
        private System.Windows.Forms.Panel panel3;
    }
}