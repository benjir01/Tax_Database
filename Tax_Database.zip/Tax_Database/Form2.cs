﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace Tax_Database
{
    public partial class Form2 : Form
    {
        SqlConnection mcon = new SqlConnection(@"Data Source=.\SQLEXPRESS;Initial Catalog=Tax_Database;Integrated Security=True");
        SqlCommand mcd;
        string q;
        public Form2()
        {
            InitializeComponent();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            try
            {
                string q = "Insert Into Log_Info (FirstName,LastName,UserName,Password,MobileNo,Email) Values('" + FirstNametxt.Text + "','" + lastnametxt.Text + "','" + usernametxt.Text + "','" + passwordtxtr.Text + "','" + mobiletxt.Text + "','" + emailtxt.Text + "') ";
                ExecuteQuir(q);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }
            finally
            {
 
            }
        }
        public void Opencon()
        {
            if (mcon.State == ConnectionState.Closed)
            {
                mcon.Open();
            }
        }
        public void Closencon()
        {
            if (mcon.State == ConnectionState.Open)
            {
                mcon.Close();
            }
        }

        public void ExecuteQuir(string q)
        {
            try
            {
                mcon.Open();
                mcd = new SqlCommand(q, mcon);
                if (mcd.ExecuteNonQuery() == 1)
                {
                    MessageBox.Show("Quiry SuccessFully Executed");
                }
                else
                {
                    MessageBox.Show("Quiry Not Executed");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                mcon.Close();
            }
        }

        private void lastnametxt_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
             usernametxt.Focus();
        }

        private void FirstNametxt_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
                lastnametxt.Focus();
        }

        private void usernametxt_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
                passwordtxtr.Focus();
        }

        private void passwordtxtr_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
                mobiletxt.Focus();
        }

        private void emailtxt_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
                button1.Focus();
        }

        private void mobiletxt_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
                emailtxt.Focus();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            FirstNametxt.Text = "";
            usernametxt.Text="";
            lastnametxt.Text = "";
            passwordtxtr.Text="";
            mobiletxt.Text = "";
            emailtxt.Text = "";


        }
    }
}
