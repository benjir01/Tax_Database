﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace Tax_Database
{
    public partial class Form5 : Form
    {
        SqlConnection mcon = new SqlConnection(@"Data Source=.\SQLEXPRESS;Initial Catalog=Tax_Database;Integrated Security=True");
        SqlCommand mcd;
        string q;
        public Form5()
        {
            InitializeComponent();
        }

        private void button17_Click(object sender, EventArgs e)
        {
            try
            {
                string q = "Insert Into TaxRegister_Info (HoldingNo,Name,FatherName,Villege,WardNo,BookID,PageNo,Collectiondate,Financialyear,Yearlytax,Deduct,NetCollection,Collectionmoney,Ducmoney,Totalmoney,Comment) Values('" + holdingno.Text + "','" + taxholdername.Text + "','" + fathersname.Text + "','" + villegetxt.Text + "','" + wordtxt.Text + "','" + booknotxt.Text + "','" + pagenotxt.Text + "','" + collectiondatetxt.Text + "','" + financialyeartxt.Text + "','" + fixyearlytax.Text + "', '" + deduchtxtholder.Text + "','" + netcollectiontxt.Text + "','" + collectionmoneytxt.Text + "','" + duetax.Text + "','" + totaltaxcollection.Text + "','" + commenttxt.Text + "' ) ";
                ExecuteQuiry(q);

                holdingno.Text = "";
                taxholdername.Text = "";
                fathersname.Text = "";
                villegetxt.Text = "";
                wordtxt.Text = "";
                booknotxt.Text = "";
                pagenotxt.Text = "";
                collectiondatetxt.Text = "";
                financialyeartxt.Text = "";
                fixyearlytax.Text = "";
                deduchtxtholder.Text = "";
                netcollectiontxt.Text = "";
                collectionmoneytxt.Text = "";
                duetax.Text = "";
                totaltaxcollection.Text = "";
                commenttxt.Text = "";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }
            finally
            {

            }
 

        }
        public void Opencon()
        {
            if (mcon.State == ConnectionState.Closed)
            {
                mcon.Open();
            }
        }
        public void Closencon()
        {
            if (mcon.State == ConnectionState.Open)
            {
                mcon.Close();
            }
        }

        public void ExecuteQuiry(string q)
        {
            try
            {
                mcon.Open();
                mcd = new SqlCommand(q, mcon);
                if (mcd.ExecuteNonQuery() == 1)
                {
                    MessageBox.Show("Quiry SuccessFully Executed");
                }
                else
                {
                    MessageBox.Show("Quiry Not Executed");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                mcon.Close();
            }
        }

        private void duetax_TextChanged(object sender, EventArgs e)
        {
            try
            {

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
 
            }
        }

        private void button19_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Are You Sure You Want To Delete", "Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                string q = "Delete From TaxRegister_Info Where HoldingNo = '" + holdingno.Text + "'";
                ExecuteQuiry(q);
            }
        }

        private void button20_Click(object sender, EventArgs e)
        {
            mcon.Open();
            q = "select * from TaxRegister_Info where HoldingNo ='" + holdingno.Text.Trim() + "'";
            mcd = new SqlCommand(q, mcon);
            SqlDataReader reader = mcd.ExecuteReader();

            if (reader.Read())
            {
                taxholdername.Text = reader["Name"].ToString();
                fathersname.Text = reader["FatherName"].ToString();
                villegetxt.Text = reader["Villege"].ToString();
                wordtxt.Text = reader["WardNo"].ToString();
                booknotxt.Text = reader["BookID"].ToString();
                pagenotxt.Text = reader["PageNo"].ToString();
                collectiondatetxt.Text = reader["Collectiondate"].ToString();
                financialyeartxt.Text = reader["Financialyear"].ToString();
                fixyearlytax.Text = reader["Yearlytax"].ToString();
                deduchtxtholder.Text = reader["Deduct"].ToString();
                netcollectiontxt.Text = reader["NetCollection"].ToString();
                collectionmoneytxt.Text = reader["Collectionmoney"].ToString();
                duetax.Text = reader["Ducmoney"].ToString();
                totaltaxcollection.Text = reader["Totalmoney"].ToString();
                commenttxt.Text = reader["Comment"].ToString();

            }
            else
            {
                MessageBox.Show("Sorry Data Not Finded");
            }

           
            mcon.Close();
            reader.Close();
        }

        private void button18_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Are you Sure you want to Update", "Exit", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                string q = "update  TaxRegister_Info set Name= '" + taxholdername.Text + "', FatherName= '" + fathersname.Text + "', Villege = '" + villegetxt.Text + "',WardNo = '" + wordtxt.Text + "',BookID = '" + booknotxt.Text + "',PageNo = '" + pagenotxt.Text + "', Collectiondate = '" + collectiondatetxt.Text + "', Financialyear = '" + financialyeartxt.Text + "' ,  Yearlytax = '" + fixyearlytax.Text + "' ,  Deduct = '" + deduchtxtholder.Text + "' , NetCollection ='" + netcollectiontxt.Text + "', Collectionmoney ='" + collectionmoneytxt.Text + "', Ducmoney='" + duetax.Text + "', Totalmoney='" + totaltaxcollection.Text + "', Comment='" + commenttxt.Text + "'   Where HoldingNo = '" + holdingno.Text + "'";
                ExecuteQuiry(q);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            mcon.Open();
            q = "select * from People_Info where Holding ='" + holdingno.Text.Trim() + "'";
            mcd = new SqlCommand(q, mcon);
            SqlDataReader reader = mcd.ExecuteReader();

            if (reader.Read())
            {
                taxholdername.Text = reader["Name"].ToString();
                fathersname.Text = reader["Father"].ToString();
                villegetxt.Text = reader["Villege"].ToString();
                wordtxt.Text = reader["WardNo"].ToString();

            }
            else
            {
                MessageBox.Show("Sorry Data Not Finded");
            }


            mcon.Close();
            reader.Close();
        }


           // holdingno.Text = "";
          //  taxholdername.Text ="";
           // fathersname.Text ="";
          //  villegetxt.Text = "";
          //  wordtxt.Text ="";
          //  booknotxt.Text ="";
          //  pagenotxt.Text ="";
          //  collectiondatetxt.Text="";
          //  financialyeartxt.Text ="";
          //  fixyearlytax.Text ="";
          //  deduchtxtholder.Text ="";
           // netcollectiontxt.Text ="";
           // collectionmoneytxt.Text ="";
           // duetax.Text ="";
           // totaltaxcollection.Text ="";
           // commenttxt.Text = "";
        

        private void taxholdername_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
                fathersname.Focus();
        }

        private void holdingno_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            taxholdername.Focus();
        }

        private void fathersname_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
                villegetxt.Focus();
        }

        private void villegetxt_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
                wordtxt.Focus();
        }

        private void wordtxt_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode==Keys.Enter)
             booknotxt.Focus();
        }

        private void booknotxt_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
                pagenotxt.Focus();
        }

        private void pagenotxt_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
                collectiondatetxt.Focus();
        }

        private void collectiondatetxt_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
                financialyeartxt.Focus();
        }

        private void financialyeartxt_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
                fixyearlytax.Focus();
        }

        private void fixyearlytax_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
                deduchtxtholder.Focus();
        }

        private void deduchtxtholder_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
                netcollectiontxt.Focus();
        }

        private void netcollectiontxt_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
                collectionmoneytxt.Focus();
        }

        private void collectionmoneytxt_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
                duetax.Focus();
        }

        private void duetax_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
                totaltaxcollection.Focus();

        }

        private void totaltaxcollection_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
                commenttxt.Focus();
        }
    }
}
