﻿namespace Tax_Database
{
    partial class Form5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.duetax = new System.Windows.Forms.RichTextBox();
            this.richTextBox16 = new System.Windows.Forms.RichTextBox();
            this.button26 = new System.Windows.Forms.Button();
            this.fathersname = new System.Windows.Forms.RichTextBox();
            this.financialyeartxt = new System.Windows.Forms.RichTextBox();
            this.button12 = new System.Windows.Forms.Button();
            this.totaltaxcollection = new System.Windows.Forms.RichTextBox();
            this.button9 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.villegetxt = new System.Windows.Forms.RichTextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.button21 = new System.Windows.Forms.Button();
            this.collectionmoneytxt = new System.Windows.Forms.RichTextBox();
            this.button7 = new System.Windows.Forms.Button();
            this.netcollectiontxt = new System.Windows.Forms.RichTextBox();
            this.button5 = new System.Windows.Forms.Button();
            this.fixyearlytax = new System.Windows.Forms.RichTextBox();
            this.button6 = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.wordtxt = new System.Windows.Forms.ComboBox();
            this.collectiondatetxt = new System.Windows.Forms.RichTextBox();
            this.button15 = new System.Windows.Forms.Button();
            this.pagenotxt = new System.Windows.Forms.RichTextBox();
            this.button14 = new System.Windows.Forms.Button();
            this.booknotxt = new System.Windows.Forms.RichTextBox();
            this.button13 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.taxholdername = new System.Windows.Forms.RichTextBox();
            this.holdingno = new System.Windows.Forms.RichTextBox();
            this.button8 = new System.Windows.Forms.Button();
            this.deduchtxtholder = new System.Windows.Forms.RichTextBox();
            this.button22 = new System.Windows.Forms.Button();
            this.button19 = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.button11 = new System.Windows.Forms.Button();
            this.commenttxt = new System.Windows.Forms.RichTextBox();
            this.button20 = new System.Windows.Forms.Button();
            this.button18 = new System.Windows.Forms.Button();
            this.button16 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.richTextBox17 = new System.Windows.Forms.RichTextBox();
            this.button23 = new System.Windows.Forms.Button();
            this.richTextBox18 = new System.Windows.Forms.RichTextBox();
            this.button24 = new System.Windows.Forms.Button();
            this.yearlytax = new System.Windows.Forms.RichTextBox();
            this.button25 = new System.Windows.Forms.Button();
            this.panel4 = new System.Windows.Forms.Panel();
            this.button17 = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // duetax
            // 
            this.duetax.Font = new System.Drawing.Font("SutonnyMJ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.duetax.Location = new System.Drawing.Point(512, 179);
            this.duetax.Name = "duetax";
            this.duetax.Size = new System.Drawing.Size(117, 30);
            this.duetax.TabIndex = 37;
            this.duetax.Text = "";
            this.duetax.TextChanged += new System.EventHandler(this.duetax_TextChanged);
            this.duetax.KeyDown += new System.Windows.Forms.KeyEventHandler(this.duetax_KeyDown);
            // 
            // richTextBox16
            // 
            this.richTextBox16.Font = new System.Drawing.Font("SutonnyMJ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richTextBox16.Location = new System.Drawing.Point(512, 129);
            this.richTextBox16.Name = "richTextBox16";
            this.richTextBox16.Size = new System.Drawing.Size(117, 30);
            this.richTextBox16.TabIndex = 35;
            this.richTextBox16.Text = "";
            // 
            // button26
            // 
            this.button26.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button26.Location = new System.Drawing.Point(12, 107);
            this.button26.Name = "button26";
            this.button26.Size = new System.Drawing.Size(149, 30);
            this.button26.TabIndex = 26;
            this.button26.Text = "পিতা/স্বামীর নাম";
            this.button26.UseVisualStyleBackColor = true;
            // 
            // fathersname
            // 
            this.fathersname.Font = new System.Drawing.Font("SutonnyMJ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fathersname.Location = new System.Drawing.Point(167, 107);
            this.fathersname.Name = "fathersname";
            this.fathersname.Size = new System.Drawing.Size(171, 30);
            this.fathersname.TabIndex = 27;
            this.fathersname.Text = "";
            this.fathersname.KeyDown += new System.Windows.Forms.KeyEventHandler(this.fathersname_KeyDown);
            // 
            // financialyeartxt
            // 
            this.financialyeartxt.Font = new System.Drawing.Font("SutonnyMJ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.financialyeartxt.Location = new System.Drawing.Point(184, 129);
            this.financialyeartxt.Name = "financialyeartxt";
            this.financialyeartxt.Size = new System.Drawing.Size(115, 30);
            this.financialyeartxt.TabIndex = 41;
            this.financialyeartxt.Text = "";
            this.financialyeartxt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.financialyeartxt_KeyDown);
            // 
            // button12
            // 
            this.button12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button12.Location = new System.Drawing.Point(7, 129);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(149, 30);
            this.button12.TabIndex = 40;
            this.button12.Text = "অর্থবছর";
            this.button12.UseVisualStyleBackColor = true;
            // 
            // totaltaxcollection
            // 
            this.totaltaxcollection.Font = new System.Drawing.Font("SutonnyMJ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.totaltaxcollection.Location = new System.Drawing.Point(512, 235);
            this.totaltaxcollection.Name = "totaltaxcollection";
            this.totaltaxcollection.Size = new System.Drawing.Size(117, 30);
            this.totaltaxcollection.TabIndex = 39;
            this.totaltaxcollection.Text = "";
            this.totaltaxcollection.KeyDown += new System.Windows.Forms.KeyEventHandler(this.totaltaxcollection_KeyDown);
            // 
            // button9
            // 
            this.button9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button9.Location = new System.Drawing.Point(335, 235);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(140, 30);
            this.button9.TabIndex = 38;
            this.button9.Text = "সর্বোমোট টাকা";
            this.button9.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Location = new System.Drawing.Point(12, 143);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(149, 30);
            this.button3.TabIndex = 4;
            this.button3.Text = "গ্রাম";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // villegetxt
            // 
            this.villegetxt.Font = new System.Drawing.Font("SutonnyMJ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.villegetxt.Location = new System.Drawing.Point(167, 143);
            this.villegetxt.Name = "villegetxt";
            this.villegetxt.Size = new System.Drawing.Size(171, 30);
            this.villegetxt.TabIndex = 5;
            this.villegetxt.Text = "";
            this.villegetxt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.villegetxt_KeyDown);
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(12, 69);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(149, 30);
            this.button2.TabIndex = 2;
            this.button2.Text = "কর দাতার নাম";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(12, 28);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(149, 30);
            this.button1.TabIndex = 0;
            this.button1.Text = "হোল্ডিং নং";
            this.button1.UseMnemonic = false;
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button21
            // 
            this.button21.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button21.Location = new System.Drawing.Point(335, 179);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(140, 30);
            this.button21.TabIndex = 36;
            this.button21.Text = "বকেয়া";
            this.button21.UseVisualStyleBackColor = true;
            // 
            // collectionmoneytxt
            // 
            this.collectionmoneytxt.Font = new System.Drawing.Font("SutonnyMJ", 8.249999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.collectionmoneytxt.Location = new System.Drawing.Point(891, 256);
            this.collectionmoneytxt.Name = "collectionmoneytxt";
            this.collectionmoneytxt.Size = new System.Drawing.Size(117, 30);
            this.collectionmoneytxt.TabIndex = 61;
            this.collectionmoneytxt.Text = "";
            this.collectionmoneytxt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.collectionmoneytxt_KeyDown);
            // 
            // button7
            // 
            this.button7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button7.Location = new System.Drawing.Point(714, 256);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(140, 30);
            this.button7.TabIndex = 60;
            this.button7.Text = "আদায় কৃত ট্যাক্স";
            this.button7.UseVisualStyleBackColor = true;
            // 
            // netcollectiontxt
            // 
            this.netcollectiontxt.Font = new System.Drawing.Font("SutonnyMJ", 8.249999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.netcollectiontxt.Location = new System.Drawing.Point(563, 418);
            this.netcollectiontxt.Name = "netcollectiontxt";
            this.netcollectiontxt.Size = new System.Drawing.Size(115, 30);
            this.netcollectiontxt.TabIndex = 59;
            this.netcollectiontxt.Text = "";
            this.netcollectiontxt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.netcollectiontxt_KeyDown);
            // 
            // button5
            // 
            this.button5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.Location = new System.Drawing.Point(386, 361);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(149, 30);
            this.button5.TabIndex = 56;
            this.button5.Text = "ম্ওকুফ";
            this.button5.UseVisualStyleBackColor = true;
            // 
            // fixyearlytax
            // 
            this.fixyearlytax.Font = new System.Drawing.Font("SutonnyMJ", 8.249999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fixyearlytax.Location = new System.Drawing.Point(563, 305);
            this.fixyearlytax.Name = "fixyearlytax";
            this.fixyearlytax.Size = new System.Drawing.Size(115, 30);
            this.fixyearlytax.TabIndex = 55;
            this.fixyearlytax.Text = "";
            this.fixyearlytax.KeyDown += new System.Windows.Forms.KeyEventHandler(this.fixyearlytax_KeyDown);
            // 
            // button6
            // 
            this.button6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button6.Location = new System.Drawing.Point(386, 305);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(149, 30);
            this.button6.TabIndex = 54;
            this.button6.Text = "বাৎসরিক ধা্র্য ট্যাক্স";
            this.button6.UseVisualStyleBackColor = true;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.CornflowerBlue;
            this.panel1.Controls.Add(this.wordtxt);
            this.panel1.Controls.Add(this.button26);
            this.panel1.Controls.Add(this.fathersname);
            this.panel1.Controls.Add(this.collectiondatetxt);
            this.panel1.Controls.Add(this.button15);
            this.panel1.Controls.Add(this.pagenotxt);
            this.panel1.Controls.Add(this.button14);
            this.panel1.Controls.Add(this.booknotxt);
            this.panel1.Controls.Add(this.button13);
            this.panel1.Controls.Add(this.button4);
            this.panel1.Controls.Add(this.button3);
            this.panel1.Controls.Add(this.villegetxt);
            this.panel1.Controls.Add(this.button2);
            this.panel1.Controls.Add(this.taxholdername);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.holdingno);
            this.panel1.Location = new System.Drawing.Point(4, 120);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(358, 489);
            this.panel1.TabIndex = 63;
            // 
            // wordtxt
            // 
            this.wordtxt.Font = new System.Drawing.Font("SutonnyMJ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.wordtxt.FormattingEnabled = true;
            this.wordtxt.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10"});
            this.wordtxt.Location = new System.Drawing.Point(167, 184);
            this.wordtxt.Name = "wordtxt";
            this.wordtxt.Size = new System.Drawing.Size(168, 27);
            this.wordtxt.TabIndex = 28;
            this.wordtxt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.wordtxt_KeyDown);
            // 
            // collectiondatetxt
            // 
            this.collectiondatetxt.Font = new System.Drawing.Font("SutonnyMJ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.collectiondatetxt.Location = new System.Drawing.Point(164, 338);
            this.collectiondatetxt.Name = "collectiondatetxt";
            this.collectiondatetxt.Size = new System.Drawing.Size(171, 30);
            this.collectiondatetxt.TabIndex = 25;
            this.collectiondatetxt.Text = "";
            this.collectiondatetxt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.collectiondatetxt_KeyDown);
            // 
            // button15
            // 
            this.button15.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button15.Location = new System.Drawing.Point(12, 338);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(149, 30);
            this.button15.TabIndex = 24;
            this.button15.Text = "আদায় তারিখ";
            this.button15.UseVisualStyleBackColor = true;
            // 
            // pagenotxt
            // 
            this.pagenotxt.Font = new System.Drawing.Font("SutonnyMJ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pagenotxt.Location = new System.Drawing.Point(164, 283);
            this.pagenotxt.Name = "pagenotxt";
            this.pagenotxt.Size = new System.Drawing.Size(171, 30);
            this.pagenotxt.TabIndex = 23;
            this.pagenotxt.Text = "";
            this.pagenotxt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.pagenotxt_KeyDown);
            // 
            // button14
            // 
            this.button14.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button14.Location = new System.Drawing.Point(12, 286);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(149, 30);
            this.button14.TabIndex = 22;
            this.button14.Text = "পৃষ্ঠা নং";
            this.button14.UseVisualStyleBackColor = true;
            // 
            // booknotxt
            // 
            this.booknotxt.Font = new System.Drawing.Font("SutonnyMJ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.booknotxt.Location = new System.Drawing.Point(164, 234);
            this.booknotxt.Name = "booknotxt";
            this.booknotxt.Size = new System.Drawing.Size(171, 30);
            this.booknotxt.TabIndex = 21;
            this.booknotxt.Text = "";
            this.booknotxt.KeyDown += new System.Windows.Forms.KeyEventHandler(this.booknotxt_KeyDown);
            // 
            // button13
            // 
            this.button13.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button13.Location = new System.Drawing.Point(12, 234);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(149, 30);
            this.button13.TabIndex = 20;
            this.button13.Text = "বহি নং";
            this.button13.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            this.button4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.Location = new System.Drawing.Point(12, 184);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(149, 30);
            this.button4.TabIndex = 6;
            this.button4.Text = "ওয়ার্ড নং";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // taxholdername
            // 
            this.taxholdername.Font = new System.Drawing.Font("SutonnyMJ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.taxholdername.Location = new System.Drawing.Point(167, 69);
            this.taxholdername.Name = "taxholdername";
            this.taxholdername.Size = new System.Drawing.Size(171, 30);
            this.taxholdername.TabIndex = 3;
            this.taxholdername.Text = "";
            this.taxholdername.KeyDown += new System.Windows.Forms.KeyEventHandler(this.taxholdername_KeyDown);
            // 
            // holdingno
            // 
            this.holdingno.Font = new System.Drawing.Font("SutonnyMJ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.holdingno.Location = new System.Drawing.Point(166, 26);
            this.holdingno.Name = "holdingno";
            this.holdingno.Size = new System.Drawing.Size(171, 30);
            this.holdingno.TabIndex = 1;
            this.holdingno.Text = "";
            this.holdingno.KeyDown += new System.Windows.Forms.KeyEventHandler(this.holdingno_KeyDown);
            // 
            // button8
            // 
            this.button8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button8.Location = new System.Drawing.Point(386, 418);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(149, 30);
            this.button8.TabIndex = 58;
            this.button8.Text = "নীট আদায় যোগ্য টাকা";
            this.button8.UseVisualStyleBackColor = true;
            // 
            // deduchtxtholder
            // 
            this.deduchtxtholder.Font = new System.Drawing.Font("SutonnyMJ", 8.249999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.deduchtxtholder.Location = new System.Drawing.Point(563, 361);
            this.deduchtxtholder.Name = "deduchtxtholder";
            this.deduchtxtholder.Size = new System.Drawing.Size(115, 30);
            this.deduchtxtholder.TabIndex = 57;
            this.deduchtxtholder.Text = "";
            this.deduchtxtholder.KeyDown += new System.Windows.Forms.KeyEventHandler(this.deduchtxtholder_KeyDown);
            // 
            // button22
            // 
            this.button22.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button22.Location = new System.Drawing.Point(335, 129);
            this.button22.Name = "button22";
            this.button22.Size = new System.Drawing.Size(140, 30);
            this.button22.TabIndex = 34;
            this.button22.Text = "আদায় কৃত ট্যাক্স";
            this.button22.UseVisualStyleBackColor = true;
            // 
            // button19
            // 
            this.button19.Location = new System.Drawing.Point(701, 570);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(139, 42);
            this.button19.TabIndex = 69;
            this.button19.Text = "Delete";
            this.button19.UseVisualStyleBackColor = true;
            this.button19.Click += new System.EventHandler(this.button19_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.CornflowerBlue;
            this.panel2.Controls.Add(this.button11);
            this.panel2.Controls.Add(this.commenttxt);
            this.panel2.Location = new System.Drawing.Point(1037, 119);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(166, 490);
            this.panel2.TabIndex = 64;
            // 
            // button11
            // 
            this.button11.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button11.Location = new System.Drawing.Point(3, 3);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(160, 45);
            this.button11.TabIndex = 26;
            this.button11.Text = "মন্তব্য";
            this.button11.UseVisualStyleBackColor = true;
            // 
            // commenttxt
            // 
            this.commenttxt.Font = new System.Drawing.Font("SutonnyMJ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.commenttxt.Location = new System.Drawing.Point(3, 54);
            this.commenttxt.Name = "commenttxt";
            this.commenttxt.Size = new System.Drawing.Size(160, 59);
            this.commenttxt.TabIndex = 27;
            this.commenttxt.Text = "";
            // 
            // button20
            // 
            this.button20.Location = new System.Drawing.Point(858, 567);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(139, 42);
            this.button20.TabIndex = 70;
            this.button20.Text = "Search";
            this.button20.UseVisualStyleBackColor = true;
            this.button20.Click += new System.EventHandler(this.button20_Click);
            // 
            // button18
            // 
            this.button18.Location = new System.Drawing.Point(539, 570);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(139, 42);
            this.button18.TabIndex = 68;
            this.button18.Text = "Update";
            this.button18.UseVisualStyleBackColor = true;
            this.button18.Click += new System.EventHandler(this.button18_Click);
            // 
            // button16
            // 
            this.button16.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.button16.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button16.ForeColor = System.Drawing.Color.White;
            this.button16.Location = new System.Drawing.Point(1, 7);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(1202, 113);
            this.button16.TabIndex = 65;
            this.button16.Text = "ট্যাক্স আদায় ডেস্ক";
            this.button16.UseVisualStyleBackColor = false;
            // 
            // button10
            // 
            this.button10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button10.Location = new System.Drawing.Point(714, 306);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(140, 30);
            this.button10.TabIndex = 62;
            this.button10.Text = "বকেয়া";
            this.button10.UseVisualStyleBackColor = true;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Lavender;
            this.panel3.Controls.Add(this.financialyeartxt);
            this.panel3.Controls.Add(this.button12);
            this.panel3.Controls.Add(this.totaltaxcollection);
            this.panel3.Controls.Add(this.button9);
            this.panel3.Controls.Add(this.duetax);
            this.panel3.Controls.Add(this.button21);
            this.panel3.Controls.Add(this.richTextBox16);
            this.panel3.Controls.Add(this.button22);
            this.panel3.Controls.Add(this.richTextBox17);
            this.panel3.Controls.Add(this.button23);
            this.panel3.Controls.Add(this.richTextBox18);
            this.panel3.Controls.Add(this.button24);
            this.panel3.Controls.Add(this.yearlytax);
            this.panel3.Controls.Add(this.button25);
            this.panel3.Controls.Add(this.panel4);
            this.panel3.Location = new System.Drawing.Point(379, 127);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(642, 411);
            this.panel3.TabIndex = 66;
            // 
            // richTextBox17
            // 
            this.richTextBox17.Font = new System.Drawing.Font("SutonnyMJ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richTextBox17.Location = new System.Drawing.Point(184, 291);
            this.richTextBox17.Name = "richTextBox17";
            this.richTextBox17.Size = new System.Drawing.Size(115, 30);
            this.richTextBox17.TabIndex = 33;
            this.richTextBox17.Text = "";
            // 
            // button23
            // 
            this.button23.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button23.Location = new System.Drawing.Point(7, 291);
            this.button23.Name = "button23";
            this.button23.Size = new System.Drawing.Size(149, 30);
            this.button23.TabIndex = 32;
            this.button23.Text = "নীট আদায় যোগ্য টাকা";
            this.button23.UseVisualStyleBackColor = true;
            // 
            // richTextBox18
            // 
            this.richTextBox18.Font = new System.Drawing.Font("SutonnyMJ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richTextBox18.Location = new System.Drawing.Point(184, 234);
            this.richTextBox18.Name = "richTextBox18";
            this.richTextBox18.Size = new System.Drawing.Size(115, 30);
            this.richTextBox18.TabIndex = 31;
            this.richTextBox18.Text = "";
            // 
            // button24
            // 
            this.button24.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button24.Location = new System.Drawing.Point(7, 234);
            this.button24.Name = "button24";
            this.button24.Size = new System.Drawing.Size(149, 30);
            this.button24.TabIndex = 30;
            this.button24.Text = "ম্ওকুফ";
            this.button24.UseVisualStyleBackColor = true;
            // 
            // yearlytax
            // 
            this.yearlytax.Font = new System.Drawing.Font("SutonnyMJ", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.yearlytax.Location = new System.Drawing.Point(184, 178);
            this.yearlytax.Name = "yearlytax";
            this.yearlytax.Size = new System.Drawing.Size(115, 30);
            this.yearlytax.TabIndex = 29;
            this.yearlytax.Text = "";
            // 
            // button25
            // 
            this.button25.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button25.Location = new System.Drawing.Point(7, 178);
            this.button25.Name = "button25";
            this.button25.Size = new System.Drawing.Size(149, 30);
            this.button25.TabIndex = 28;
            this.button25.Text = "বাৎসরিক ধা্র্য ট্যাক্স";
            this.button25.UseVisualStyleBackColor = true;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.DarkOliveGreen;
            this.panel4.Location = new System.Drawing.Point(0, 0);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(642, 411);
            this.panel4.TabIndex = 42;
            // 
            // button17
            // 
            this.button17.Location = new System.Drawing.Point(379, 567);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(139, 42);
            this.button17.TabIndex = 67;
            this.button17.Text = "Submit";
            this.button17.UseVisualStyleBackColor = true;
            this.button17.Click += new System.EventHandler(this.button17_Click);
            // 
            // Form5
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1205, 618);
            this.Controls.Add(this.collectionmoneytxt);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.netcollectiontxt);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.fixyearlytax);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.deduchtxtholder);
            this.Controls.Add(this.button19);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.button20);
            this.Controls.Add(this.button18);
            this.Controls.Add(this.button16);
            this.Controls.Add(this.button10);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.button17);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "Form5";
            this.Text = "Form5";
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RichTextBox duetax;
        private System.Windows.Forms.RichTextBox richTextBox16;
        private System.Windows.Forms.Button button26;
        private System.Windows.Forms.RichTextBox fathersname;
        private System.Windows.Forms.RichTextBox financialyeartxt;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.RichTextBox totaltaxcollection;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.RichTextBox villegetxt;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.RichTextBox collectionmoneytxt;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.RichTextBox netcollectiontxt;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.RichTextBox fixyearlytax;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ComboBox wordtxt;
        private System.Windows.Forms.RichTextBox collectiondatetxt;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.RichTextBox pagenotxt;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.RichTextBox booknotxt;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.RichTextBox taxholdername;
        private System.Windows.Forms.RichTextBox holdingno;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.RichTextBox deduchtxtholder;
        private System.Windows.Forms.Button button22;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.RichTextBox commenttxt;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.RichTextBox richTextBox17;
        private System.Windows.Forms.Button button23;
        private System.Windows.Forms.RichTextBox richTextBox18;
        private System.Windows.Forms.Button button24;
        private System.Windows.Forms.RichTextBox yearlytax;
        private System.Windows.Forms.Button button25;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button button17;
    }
}