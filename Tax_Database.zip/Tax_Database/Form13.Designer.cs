﻿namespace Tax_Database
{
    partial class Form13
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource1 = new Microsoft.Reporting.WinForms.ReportDataSource();
            this.reportViewer1 = new Microsoft.Reporting.WinForms.ReportViewer();
            this.Tax_DatabaseDataSet9 = new Tax_Database.Tax_DatabaseDataSet9();
            this.TradeLiecence_InoBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.TradeLiecence_InoTableAdapter = new Tax_Database.Tax_DatabaseDataSet9TableAdapters.TradeLiecence_InoTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.Tax_DatabaseDataSet9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TradeLiecence_InoBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // reportViewer1
            // 
            reportDataSource1.Name = "DataSet1";
            reportDataSource1.Value = this.TradeLiecence_InoBindingSource;
            this.reportViewer1.LocalReport.DataSources.Add(reportDataSource1);
            this.reportViewer1.LocalReport.ReportEmbeddedResource = "Tax_Database.Report12.rdlc";
            this.reportViewer1.Location = new System.Drawing.Point(12, 45);
            this.reportViewer1.Name = "reportViewer1";
            this.reportViewer1.Size = new System.Drawing.Size(615, 625);
            this.reportViewer1.TabIndex = 0;
            // 
            // Tax_DatabaseDataSet9
            // 
            this.Tax_DatabaseDataSet9.DataSetName = "Tax_DatabaseDataSet9";
            this.Tax_DatabaseDataSet9.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // TradeLiecence_InoBindingSource
            // 
            this.TradeLiecence_InoBindingSource.DataMember = "TradeLiecence_Ino";
            this.TradeLiecence_InoBindingSource.DataSource = this.Tax_DatabaseDataSet9;
            // 
            // TradeLiecence_InoTableAdapter
            // 
            this.TradeLiecence_InoTableAdapter.ClearBeforeFill = true;
            // 
            // Form13
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(657, 683);
            this.Controls.Add(this.reportViewer1);
            this.Name = "Form13";
            this.Text = "Form13";
            this.Load += new System.EventHandler(this.Form13_Load);
            ((System.ComponentModel.ISupportInitialize)(this.Tax_DatabaseDataSet9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TradeLiecence_InoBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Microsoft.Reporting.WinForms.ReportViewer reportViewer1;
        private System.Windows.Forms.BindingSource TradeLiecence_InoBindingSource;
        private Tax_DatabaseDataSet9 Tax_DatabaseDataSet9;
        private Tax_DatabaseDataSet9TableAdapters.TradeLiecence_InoTableAdapter TradeLiecence_InoTableAdapter;
    }
}